#!/usr/bin/env bash
# Management menu for the Telegram leech bot (installed as /usr/local/bin/leechbot)
#   leechbot [status | start | stop | restart | log | update | ytdlp | settings | uninstall]
set -u
INSTALL_DIR="__INSTALL_DIR__"
SVC_USER="__SVC_USER__"
SERVICE="leechbot.service"
ENV_FILE="$INSTALL_DIR/.env"
RE_ID='^[0-9]{1,15}$'
RE_HASH='^[0-9a-fA-F]{32}$'
RE_TOKEN='^[0-9]{5,}:[A-Za-z0-9_-]{30,}$'

if [[ -t 1 ]]; then B=$'\e[1m' G=$'\e[32m' Y=$'\e[33m' R=$'\e[31m' Z=$'\e[0m'; else B="" G="" Y="" R="" Z=""; fi
ok()   { printf '%s✔%s %s\n' "$G" "$Z" "$*"; }
warn() { printf '%s!%s %s\n' "$Y" "$Z" "$*" >&2; }
err()  { printf '%s✘%s %s\n' "$R" "$Z" "$*" >&2; }

if [[ $EUID -ne 0 ]]; then
  command -v sudo >/dev/null 2>&1 || { err "Run as root."; exit 1; }
  exec sudo "$0" "$@"
fi
[[ -d "$INSTALL_DIR" ]] || { err "Not installed (missing $INSTALL_DIR)."; exit 1; }

have_systemd() { [[ -d /run/systemd/system || -n "${LEECHBOT_ASSUME_SYSTEMD:-}" ]]; }
sc() { have_systemd || { warn "systemd isn't running on this machine."; return 1; }; systemctl "$@"; }
is_active() { have_systemd && systemctl is-active --quiet "$SERVICE"; }
confirm() { local a=""; read -rp "$1 [y/N] " a || return 1; [[ "$a" =~ ^[Yy]$ ]]; }

# ---------- .env helpers ----------
env_get() { sed -n "s/^$1=//p" "$ENV_FILE" 2>/dev/null | tail -n1; }
shown() { local v; v="$(env_get "$1")"; printf '%s' "${v:-$2}"; }   # shown KEY FALLBACK
set_env() {  # set_env KEY VALUE; with no value the line is removed
  K="$1" V="${2-}" awk 'BEGIN{FS=OFS="="; k=ENVIRON["K"]; v=ENVIRON["V"]} $1==k {if (v != "") print k "=" v; d=1; next} {print} END {if (!d && v != "") print k "=" v}' \
    "$ENV_FILE" > "$ENV_FILE.tmp" && mv "$ENV_FILE.tmp" "$ENV_FILE"
  chown "$SVC_USER":"$SVC_USER" "$ENV_FILE" 2>/dev/null || true
  chmod 600 "$ENV_FILE"
}
mask() { local v="$1"; if [[ -z "$v" ]]; then printf '(not set)'; elif (( ${#v} > 8 )); then printf '%s…%s' "${v:0:4}" "${v: -3}"; else printf '(set)'; fi; }
missing_settings() {  # required settings still empty (empty output = fully configured)
  local k out=(); for k in API_ID API_HASH BOT_TOKEN OWNER_ID; do [[ -n "$(env_get "$k")" ]] || out+=("$k"); done; printf '%s' "${out[*]}"
}

# ---------- actions ----------
wait_started() {
  local since="$1"
  for _ in $(seq 1 25); do
    journalctl -u leechbot --since "$since" --no-pager 2>/dev/null | grep -q "Bot started" && { ok "Bot is running"; return 0; }
    systemctl is-failed --quiet "$SERVICE" && break
    sleep 1
  done
  err "The bot didn't report 'started'. Last log lines:"; journalctl -u leechbot -n 15 --no-pager 2>&1 | tail -n 15
  return 1
}
# Start/restart; a first install without credentials leaves autostart off (it would crash-loop), so switch it on
# once the bot has started properly.
do_run() {  # do_run start|restart
  local m t; m="$(missing_settings)"
  if [[ -n "$m" ]]; then err "The bot can't start yet. Still to set: $m  (leechbot settings)"; return 1; fi
  t="$(date '+%Y-%m-%d %H:%M:%S')"
  sc "$1" "$SERVICE" && wait_started "$t" || return 1
  if [[ -f "$INSTALL_DIR/.first-run" ]] && sc enable "$SERVICE" >/dev/null 2>&1; then rm -f "$INSTALL_DIR/.first-run"; ok "Autostart enabled"; fi
}

do_status() {
  have_systemd || { warn "systemd isn't running; can't query the service."; return 1; }
  local -A p=(); local k v
  while IFS='=' read -r k v; do p[$k]="$v"; done < <(systemctl show "$SERVICE" -p ActiveState -p SubState -p NRestarts -p MemoryCurrent -p MemoryMax -p ActiveEnterTimestamp 2>/dev/null)
  local col="$R"; [[ "${p[ActiveState]:-}" == active ]] && col="$G"
  printf '  Service   : %s%s/%s%s  (since %s)\n' "$col" "${p[ActiveState]:-unknown}" "${p[SubState]:-?}" "$Z" "${p[ActiveEnterTimestamp]:-n/a}"
  printf '  Autostart : %s\n  Restarts  : %s\n' "$(systemctl is-enabled "$SERVICE" 2>/dev/null || echo disabled)" "${p[NRestarts]:-0}"
  local m; m="$(missing_settings)"; [[ -z "$m" ]] || warn "Not configured yet. Still to set: $m  (leechbot settings)"
  if [[ "${p[MemoryCurrent]:-}" =~ ^[0-9]+$ ]]; then
    printf '  Memory    : %s MB' "$(( p[MemoryCurrent] / 1048576 ))"
    [[ "${p[MemoryMax]:-}" =~ ^[0-9]+$ ]] && printf ' of %s MB cap' "$(( p[MemoryMax] / 1048576 ))"; echo
  fi
  printf '  yt-dlp    : %s\n  Install   : %s\n' "$("$INSTALL_DIR/venv/bin/python" -m yt_dlp --version 2>/dev/null || echo '?')" "$INSTALL_DIR"
}

do_log() { trap ':' INT; journalctl -u leechbot -n 50 -f --no-pager; trap - INT; }  # Ctrl-C leaves the log, not the menu

do_update() { echo "Updating the bot (settings are kept)..."; bash "$INSTALL_DIR/install.sh" --update -y --dir "$INSTALL_DIR" --user "$SVC_USER"; }

do_ytdlp() {
  echo "Updating yt-dlp..."
  runuser -u "$SVC_USER" -- "$INSTALL_DIR/venv/bin/python" "$INSTALL_DIR/deploy/update_ytdlp.py"
  local rc=$?
  if [[ $rc -eq 0 || $rc -eq 3 ]]; then ok "yt-dlp is up to date"; else err "yt-dlp update failed (exit $rc)"; fi
}

do_uninstall() {
  local args=(--uninstall --dir "$INSTALL_DIR" --user "$SVC_USER")
  confirm "Also delete your settings, Telegram session and the service user?" && args+=(--purge -y)
  bash "$INSTALL_DIR/install.sh" "${args[@]}"
}

# ---------- settings ----------
ask_restart() {
  if is_active; then confirm "Restart the bot now to apply this?" && { do_run restart || true; }
  elif [[ -z "$(missing_settings)" ]]; then confirm "All set. Start the bot now?" && { do_run start || true; }
  else echo "  Still to set before the bot can start: $(missing_settings)"; fi
  return 0
}

prompt_value() {  # prompt_value "Label" REGEX [secret]  -> REPLY_VAL ("" = keep current)
  local label="$1" re="$2" secret="${3:-0}" v="" rc
  while true; do
    rc=0
    if [[ "$secret" == 1 ]]; then read -rsp "  $label (Enter = keep current): " v || rc=$?; echo; else read -rp "  $label (Enter = keep current): " v || rc=$?; fi
    v="${v//[[:space:]\"\']/}"; v="${v//$'\e'\[20[01]~/}"   # pasted values may carry spaces, quotes or bracketed-paste markers
    if (( rc != 0 )) || [[ -z "$v" ]]; then REPLY_VAL=""; return 0; fi
    [[ "$re" == "$RE_HASH" ]] && v="${v,,}"
    [[ "$v" =~ $re ]] && { REPLY_VAL="$v"; return 0; }
    warn "That doesn't look right (got ${#v} characters). Try again, or press Enter to keep the current value."
  done
}

clear_session() { rm -f "$INSTALL_DIR"/leechbot*.session*; }  # a Telegram session belongs to one bot/app; a stale one ignores new credentials

set_token() {
  prompt_value "New bot token" "$RE_TOKEN" 1; local t="$REPLY_VAL" code; [[ -z "$t" ]] && return
  code="$(printf 'url = "https://api.telegram.org/bot%s/getMe"\n' "$t" | curl -K - -sS --max-time 15 -o /dev/null -w '%{http_code}' 2>/dev/null)" || code=000
  case "$code" in
    200) ok "Token is valid" ;;
    401|404) err "Telegram rejected that token. Nothing changed."; return ;;
    *) warn "Couldn't reach Telegram to verify the token."; confirm "Save it anyway?" || return ;;
  esac
  set_env BOT_TOKEN "$t"; clear_session; ok "Bot token updated (old Telegram session cleared)."; ask_restart
}

set_api() {
  prompt_value "New API ID" "$RE_ID"; local id="$REPLY_VAL"
  prompt_value "New API hash" "$RE_HASH" 1; local hash="$REPLY_VAL"
  [[ -z "$id$hash" ]] && return
  [[ -n "$id" ]] && set_env API_ID "$id"
  [[ -n "$hash" ]] && set_env API_HASH "$hash"
  clear_session; ok "API credentials updated (old Telegram session cleared)."; ask_restart
}

set_owner() {
  echo "  Current owner ID: $(shown OWNER_ID '(not set)')   (get yours from @userinfobot)"
  prompt_value "New owner user ID" "$RE_ID"; [[ -z "$REPLY_VAL" ]] && return
  set_env OWNER_ID "$REPLY_VAL"; ok "Owner changed to $REPLY_VAL."; ask_restart
}

LIMITS=(
  "MAX_FILE_SIZE_MB|Max size of one Telegram upload part, MB (bigger files are split)|^([5-9][0-9]|[1-9][0-9]{2}|[1-3][0-9]{3}|4000)$"
  "MAX_DOWNLOAD_MB|Max size of a whole download, MB|^([1-9][0-9]{2,5})$"
  "MIN_FREE_RAM_MB|Wait for this much free RAM before heavy jobs, MB|^([0-9]|[1-9][0-9]{1,2}|[1-7][0-9]{3}|8000)$"
  "YTDL_MAX_HEIGHT|Highest video resolution yt-dlp may download, pixels tall|^(144|240|360|480|720|1080|1440|2160|4320)$"
  "MAX_QUEUE|Max jobs waiting in the queue|^([1-9]|[1-9][0-9]|100)$"
  "MAX_PLAYLIST_ITEMS|Most videos taken from one playlist link|^([1-9]|[1-9][0-9]|[1-4][0-9]{2}|500)$"
  "YTDL_TRANSCODE|Re-encode VP9/AV1 video to H.264 so Telegram plays it inline: 1 = yes (CPU heavy), 0 = never|^(0|1)$"
  "YTDL_SORT|Extra yt-dlp format sort, e.g. res:720 (type 'default' to clear)|^([A-Za-z0-9:,+~*._-]+)$"
)

set_limits() {
  local spec key label re changed=0
  for spec in "${LIMITS[@]}"; do
    IFS='|' read -r key label re <<<"$spec"
    echo "  $label"
    prompt_value "$key [current: $(shown "$key" default)]" "$re"
    if [[ "$key" == YTDL_SORT && "$REPLY_VAL" == default ]]; then set_env YTDL_SORT; ok "YTDL_SORT cleared"; changed=1
    elif [[ -n "$REPLY_VAL" ]]; then set_env "$key" "$REPLY_VAL"; ok "$key = $REPLY_VAL"; changed=1; fi
  done
  (( changed )) && ask_restart
  return 0
}

show_settings() {
  echo "  API_ID      : $(shown API_ID '(not set)')"
  echo "  API_HASH    : $(mask "$(env_get API_HASH)")"
  echo "  BOT_TOKEN   : $(mask "$(env_get BOT_TOKEN)")"
  echo "  OWNER_ID    : $(shown OWNER_ID '(not set)')"
  local spec; for spec in "${LIMITS[@]}" DOWNLOAD_DIR; do printf '  %-18s: %s\n' "${spec%%|*}" "$(shown "${spec%%|*}" '(default)')"; done
}

settings_menu() {
  local c
  while true; do
    printf '\n%sSettings%s\n  1. Bot token\n  2. API ID and hash\n  3. Owner user ID\n  4. Limits (upload size, RAM guard, queue)\n  5. Show current settings\n  0. Back\n' "$B" "$Z"
    read -rp "Choose [0-5]: " c || return
    case "$c" in 1) set_token ;; 2) set_api ;; 3) set_owner ;; 4) set_limits ;; 5) show_settings ;; 0|"") return ;; *) warn "Pick a number from the list." ;; esac
  done
}

usage() {
  cat <<EOT
Telegram leech bot management
  leechbot               open the menu
  leechbot status        service state, memory, versions
  leechbot start|stop|restart
  leechbot log           live logs (Ctrl-C to leave)
  leechbot update        update the bot (keeps your settings)
  leechbot ytdlp         update yt-dlp now
  leechbot settings      change token, API credentials, owner, limits
  leechbot uninstall
(Video/audio mode and YouTube cookies are managed in Telegram with /mode and /cookies.)
EOT
}

menu() {
  local c m
  while true; do
    printf '\n%s== Telegram leech bot ==%s\n' "$B" "$Z"
    if is_active; then echo "  Bot is ${G}running${Z}"; else echo "  Bot is ${R}not running${Z}"; fi
    m="$(missing_settings)"; [[ -z "$m" ]] || echo "  ${Y}Not configured yet. Open 6 (Settings) and set: $m${Z}"
    printf '\n   1. Start      2. Stop         3. Restart\n   4. Status     5. Live logs    6. Settings\n   7. Update bot 8. Update yt-dlp 9. Uninstall\n   0. Exit\n'
    read -rp "Choose [0-9]: " c || return 0
    echo
    case "$c" in
      1) do_run start ;; 2) sc stop "$SERVICE" && ok "Stopped" ;; 3) do_run restart ;; 4) do_status ;; 5) do_log ;;
      6) settings_menu ;; 7) do_update ;; 8) do_ytdlp ;; 9) do_uninstall; return 0 ;;
      0|q|"") return 0 ;; *) warn "Pick a number from the list." ;;
    esac
  done
}

case "${1:-}" in
  "")        menu ;;
  status)    do_status ;;
  start)     do_run start ;;
  stop)      sc stop "$SERVICE" && ok "Stopped" ;;
  restart)   do_run restart ;;
  log|logs)  do_log ;;
  update)    do_update ;;
  ytdlp)     do_ytdlp ;;
  settings)  settings_menu ;;
  uninstall) do_uninstall ;;
  -h|--help|help) usage ;;
  *) err "Unknown command: $1"; usage; exit 1 ;;
esac
exit $?
