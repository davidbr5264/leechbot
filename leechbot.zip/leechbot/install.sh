#!/usr/bin/env bash
# =============================================================================
#  Telegram leech bot - one-command installer (Debian/Ubuntu)
#
#    bash <(curl -Ls https://raw.githubusercontent.com/davidbr5264/leechbot/main/install.sh)
#
#  Downloads the bot, installs what it needs and adds a `leechbot` management command. It asks for nothing:
#  set your Telegram credentials afterwards with `leechbot settings` (or pass them as options below).
#
#    sudo bash install.sh -y --api-id 123 --api-hash <hash> --bot-token <token> --owner-id 456   (all optional)
#    sudo bash install.sh --update                  (fetch the newest version, keep settings)
#    sudo bash install.sh --uninstall [--purge]
#  Options: --dir PATH, --user NAME, --swap-size MB, --no-swap, --no-quickjs, --no-systemd, -y/--yes
#  Download source: LEECHBOT_REPO=user/repo  LEECHBOT_REF=main  LEECHBOT_URL=<archive url>  LEECHBOT_SHA256=<hash>
# =============================================================================
set -Eeuo pipefail

ORIG_ARGS=("$@")
FWD_ARGS=(); for _a in "$@"; do [[ "$_a" == --update ]] || FWD_ARGS+=("$_a"); done
SELF="${BASH_SOURCE[0]:-}"
# Only a real file has "files next to it"; a pipe or /dev/fd/N (bash <(curl ...)) must download the bot.
if [[ -f "$SELF" && "$SELF" != /dev/* && "$SELF" != /proc/* ]]; then SRC_DIR="$(cd "$(dirname "$SELF")" && pwd)"; else SRC_DIR=""; fi
REPO="${LEECHBOT_REPO:-davidbr5264/leechbot}" REF="${LEECHBOT_REF:-main}" SOURCE_URL="${LEECHBOT_URL:-}"
BIN_DIR="${LEECHBOT_BIN_DIR:-/usr/local/bin}" UNIT_DIR="${LEECHBOT_UNIT_DIR:-/etc/systemd/system}"
INSTALL_DIR="/opt/leechbot" SVC_USER="leechbot" SWAP_MB=1024
DO_SWAP=1 DO_JS=1 DO_SYSTEMD=1 ASSUME_YES=0 UNINSTALL=0 PURGE=0 FORCE_DOWNLOAD=0
API_ID="${API_ID:-}" API_HASH="${API_HASH:-}" BOT_TOKEN="${BOT_TOKEN:-}" OWNER_ID="${OWNER_ID:-}"
RE_ID='^[0-9]{1,15}$' RE_HASH='^[0-9a-fA-F]{32}$' RE_TOKEN='^[0-9]{5,}:[A-Za-z0-9_-]{30,}$'
# A fresh server is often busy with unattended-upgrades holding the apt lock: wait for it instead of failing.
APT=(apt-get -o DPkg::Lock::Timeout=300 -o Acquire::Retries=3)

if [[ -t 1 ]]; then B=$'\e[1m' G=$'\e[32m' Y=$'\e[33m' R=$'\e[31m' Z=$'\e[0m'; else B="" G="" Y="" R="" Z=""; fi
step() { printf '\n%s==> %s%s\n' "$B" "$*" "$Z"; }
info() { printf '    %s\n' "$*"; }
ok()   { printf '    %s✔%s %s\n' "$G" "$Z" "$*"; }
warn() { printf '    %s!%s %s\n' "$Y" "$Z" "$*" >&2; }
die()  { printf '\n%sERROR:%s %s\n' "$R" "$Z" "$*" >&2; exit 1; }

LOG="$(mktemp /tmp/leechbot-install.XXXXXX.log)"
trap 'printf "\n%sInstall failed at line %s (%s).\nDetails: %s%s\n" "$R" "$LINENO" "$BASH_COMMAND" "$LOG" "$Z" >&2' ERR
run()     { "$@" >>"$LOG" 2>&1 || { tail -n 25 "$LOG" >&2; die "Command failed: $*"; }; }  # quiet; dies with the log tail
run_try() { "$@" >>"$LOG" 2>&1; }                                                         # quiet; returns the status

need_val() { [[ $# -ge 2 && -n "${2:-}" ]] || die "Option $1 needs a value."; }
while [[ $# -gt 0 ]]; do
  case "$1" in
    --api-id)    need_val "$@"; API_ID="$2"; shift 2 ;;
    --api-hash)  need_val "$@"; API_HASH="$2"; shift 2 ;;
    --bot-token) need_val "$@"; BOT_TOKEN="$2"; shift 2 ;;
    --owner-id)  need_val "$@"; OWNER_ID="$2"; shift 2 ;;
    --dir)       need_val "$@"; INSTALL_DIR="$2"; shift 2 ;;
    --user)      need_val "$@"; SVC_USER="$2"; shift 2 ;;
    --swap-size) need_val "$@"; SWAP_MB="$2"; shift 2 ;;
    --no-swap)   DO_SWAP=0; shift ;;
    --no-quickjs) DO_JS=0; shift ;;
    --no-systemd) DO_SYSTEMD=0; shift ;;
    -y|--yes)    ASSUME_YES=1; shift ;;
    --update)    FORCE_DOWNLOAD=1; shift ;;
    --uninstall) UNINSTALL=1; shift ;;
    --purge)     PURGE=1; shift ;;
    -h|--help)   sed -n '2,15p' "$0" 2>/dev/null | sed 's/^# \{0,1\}//'; exit 0 ;;
    *)           die "Unknown option: $1 (see --help)" ;;
  esac
done
[[ "$SWAP_MB" =~ ^[0-9]+$ ]] || die "--swap-size must be a number of MB."
[[ "$INSTALL_DIR" =~ ^/[A-Za-z0-9._/-]+$ ]] || die "--dir must be an absolute path of letters, digits and . _ - /"
case "${INSTALL_DIR%/}" in
  ""|/bin|/boot|/dev|/etc|/home|/lib*|/mnt|/opt|/proc|/root|/run|/sbin|/srv|/sys|/tmp|/usr|/var)
    die "Refusing to use '$INSTALL_DIR' as the install dir. Pick a dedicated folder (e.g. /opt/leechbot)." ;;
esac
[[ "$SVC_USER" =~ ^[a-z_][a-z0-9_-]{0,31}$ && "$SVC_USER" != root ]] || die "Invalid or unsafe --user '$SVC_USER'."
ENV_FILE="$INSTALL_DIR/.env" VENV="$INSTALL_DIR/venv"
have_systemd() { [[ -d /run/systemd/system ]]; }

if [[ $EUID -ne 0 ]]; then
  if [[ -f "$SELF" && "$SELF" != /dev/* && "$SELF" != /proc/* ]] && command -v sudo >/dev/null 2>&1; then
    exec sudo -E bash "$SELF" "${ORIG_ARGS[@]+"${ORIG_ARGS[@]}"}"
  fi
  die "Please run as root, e.g.:  sudo bash <(curl -Ls <install.sh URL>)"
fi
MEM_MB="${LEECHBOT_MEM_MB:-$(awk '/^MemTotal:/{printf "%d", $2/1024}' /proc/meminfo)}"
command -v apt-get >/dev/null 2>&1 || die "This installer supports Debian/Ubuntu (apt) only."

# ---------- uninstall ----------------------------------------------------------------
if (( UNINSTALL )); then
  step "Uninstalling leech bot"
  if have_systemd; then systemctl disable --now leechbot.service leechbot-ytdlp-update.timer >>"$LOG" 2>&1 || true; fi
  rm -f "$UNIT_DIR"/leechbot.service "$UNIT_DIR"/leechbot-ytdlp-update.{service,timer} "$BIN_DIR/leechbot"
  have_systemd && systemctl daemon-reload || true
  ok "Service and timer removed"
  if (( PURGE )); then
    if (( ! ASSUME_YES )); then
      read -rp "    Delete $INSTALL_DIR (config, session, venv) and user '$SVC_USER'? [y/N] " a </dev/tty || a=n
      [[ "$a" =~ ^[Yy]$ ]] || { info "Kept your data."; exit 0; }
    fi
    home="$(getent passwd "$SVC_USER" | cut -d: -f6 || true)"
    rm -rf "$INSTALL_DIR"
    if [[ "$home" == "$INSTALL_DIR" ]]; then userdel "$SVC_USER" || true; fi
    ok "Removed $INSTALL_DIR"
  else
    info "Kept $INSTALL_DIR (config, session). Use --purge to delete it."
  fi
  info "Left in place (shared): system packages, /usr/local/bin/qjs, swap."
  exit 0
fi

# ---------- fetch the bot when run on its own (bash <(curl ...)) or with --update ------
if (( FORCE_DOWNLOAD )) || [[ -z "$SRC_DIR" || ! -f "$SRC_DIR/bot/main.py" ]]; then
  url="$SOURCE_URL"
  if [[ -z "$url" && -f "$INSTALL_DIR/.source" ]]; then url="$(sed -n 's/^LEECHBOT_URL=//p' "$INSTALL_DIR/.source" | tail -n1)"; fi
  [[ -n "$url" ]] || url="https://raw.githubusercontent.com/${REPO}/${REF}/leechbot.zip"
  step "Downloading the leech bot"
  command -v curl >/dev/null 2>&1 || { export DEBIAN_FRONTEND=noninteractive; run "${APT[@]}" update -qq; run "${APT[@]}" install -y -qq curl ca-certificates; }
  TMP="$(mktemp -d /tmp/leechbot-src.XXXXXX)"; trap 'rm -rf "$TMP"' EXIT
  curl -fsSL --retry 3 --connect-timeout 20 -o "$TMP/pkg" "$url" || die "Download failed: $url"
  if [[ -n "${LEECHBOT_SHA256:-}" ]]; then
    [[ "$(sha256sum "$TMP/pkg" | cut -d' ' -f1)" == "${LEECHBOT_SHA256,,}" ]] || die "Checksum mismatch. Refusing to install."
    ok "Checksum verified"
  fi
  # python3 -m zipfile also refuses names that escape the folder ("..", absolute paths); unzip is the fallback
  { python3 -m zipfile -e "$TMP/pkg" "$TMP/src" || unzip -q -o "$TMP/pkg" -d "$TMP/src"; } >>"$LOG" 2>&1 || die "That download isn't a valid zip archive: $url"
  root="$TMP/src"; [[ -f "$root/install.sh" ]] || root="$(dirname "$(find "$root" -mindepth 2 -maxdepth 2 -name install.sh -print -quit)")"
  [[ -f "$root/bot/main.py" ]] || die "That archive doesn't look like the leech bot: $url"
  ok "Downloaded $(du -h "$TMP/pkg" | cut -f1)"
  rc=0; LEECHBOT_URL="$url" bash "$root/install.sh" "${FWD_ARGS[@]+"${FWD_ARGS[@]}"}" || rc=$?
  exit "$rc"
fi

# ---------- configuration: values come from options/env or the existing .env ------------
env_get() {  # env_get KEY: the value in .env, ignoring the placeholders the example file ships with
  local v=""; [[ -f "$ENV_FILE" ]] && v="$(sed -n "s/^$1=//p" "$ENV_FILE" | tail -n1)"
  case "$v" in your_api_hash|*your-bot-token*|*your_bot_token*) v="" ;; esac
  printf '%s' "$v"
}
set_env() {  # set_env KEY VALUE: replace the line in .env (or append it)
  K="$1" V="$2" awk 'BEGIN{FS=OFS="="; k=ENVIRON["K"]; v=ENVIRON["V"]} $1==k {print k "=" v; d=1; next} {print} END {if (!d) print k "=" v}' \
    "$ENV_FILE" > "$ENV_FILE.tmp"
  mv "$ENV_FILE.tmp" "$ENV_FILE"; chmod 600 "$ENV_FILE"  # the file holds the bot token
}
missing_settings() { local k out=(); for k in API_ID API_HASH BOT_TOKEN OWNER_ID; do [[ -n "$(env_get "$k")" ]] || out+=("$k"); done; printf '%s' "${out[*]}"; }
step "Configuration"
for spec in "API_ID:$RE_ID" "API_HASH:$RE_HASH" "BOT_TOKEN:$RE_TOKEN" "OWNER_ID:$RE_ID"; do
  var="${spec%%:*}" re="${spec#*:}" val="${!var//[[:space:]\"\']/}"
  [[ "$var" == API_HASH ]] && val="${val,,}"
  [[ -z "$val" || "$val" =~ $re ]] || die "$var has an invalid format."
  printf -v "$var" '%s' "$val"
done
[[ -n "$API_ID$API_HASH$BOT_TOKEN$OWNER_ID" ]] || info "No credentials given: set them with 'leechbot settings' once the install is done."

# ---------- system setup -----------------------------------------------------------------
step "Installing system packages (this can take a few minutes)"
export DEBIAN_FRONTEND=noninteractive
mkdir -p "$INSTALL_DIR"
free_mb="$(df -Pm "$INSTALL_DIR" | awk 'NR==2{print $4}')"
(( free_mb >= 1200 )) || warn "Only ${free_mb} MB free disk. The install needs ~1 GB plus room for downloads."
run "${APT[@]}" update -qq
run "${APT[@]}" install -y -qq --no-install-recommends python3 python3-venv python3-pip ffmpeg curl ca-certificates unzip
PY="$(command -v python3)"
"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' || die "Python 3.10+ is required (found: $("$PY" -V 2>&1))."
[[ "$(ffmpeg -hide_banner -encoders 2>/dev/null || true)" == *libmp3lame* ]] || warn "This ffmpeg has no MP3 encoder (libmp3lame): audio downloads will fail."
ok "$("$PY" -V 2>&1), ${MEM_MB} MB RAM"

step "Service user and files"
if ! id -u "$SVC_USER" >/dev/null 2>&1; then
  run useradd --system --no-create-home --home-dir "$INSTALL_DIR" --shell "$(command -v nologin || echo /usr/sbin/nologin)" "$SVC_USER"
fi
if [[ "$(realpath "$SRC_DIR")" != "$(realpath "$INSTALL_DIR")" ]]; then
  rm -rf "$INSTALL_DIR/bot" "$INSTALL_DIR/deploy"
  tar -C "$SRC_DIR" --exclude='__pycache__' --exclude='*.pyc' -cf - bot deploy requirements.txt .env.example install.sh | tar -C "$INSTALL_DIR" -xf -
fi
[[ -f "$ENV_FILE" ]] || ( umask 077; cp "$INSTALL_DIR/.env.example" "$ENV_FILE" )
# A Telegram session belongs to one bot/app: a stale one would ignore new credentials.
for k in API_ID API_HASH BOT_TOKEN; do
  old="$(env_get "$k")"; new="${!k}"
  if [[ -n "$old" && -n "$new" && "$old" != "$new" ]]; then rm -f "$INSTALL_DIR"/leechbot*.session*; info "Credentials changed: cleared the old Telegram session"; break; fi
done
[[ -z "$SOURCE_URL" ]] || printf 'LEECHBOT_URL=%s\n' "$SOURCE_URL" > "$INSTALL_DIR/.source"
for k in API_ID API_HASH BOT_TOKEN OWNER_ID; do [[ -z "${!k}" ]] || set_env "$k" "${!k}"; done
mkdir -p "$BIN_DIR"
sed -e "s|__INSTALL_DIR__|$INSTALL_DIR|g" -e "s|__SVC_USER__|$SVC_USER|g" "$INSTALL_DIR/deploy/leechbot.sh" > "$BIN_DIR/leechbot"
chmod 755 "$BIN_DIR/leechbot"
ok "Code in $INSTALL_DIR, settings in $ENV_FILE (mode 600), management command: leechbot"

step "Python environment"
[[ -x "$VENV/bin/python" ]] || run "$PY" -m venv "$VENV"
PIP=("$VENV/bin/python" -m pip install --no-cache-dir -q --default-timeout 60 --retries 5)
run "${PIP[@]}" --upgrade pip wheel
# cryptg is an optional C speed-up; install it separately so a missing wheel isn't fatal.
req="$(mktemp)"; grep -v -i -E '^[[:space:]]*(cryptg|#|$)' "$INSTALL_DIR/requirements.txt" | sed 's/[[:space:]]*#.*//' > "$req"
run "${PIP[@]}" -r "$req"; rm -f "$req"
run_try "${PIP[@]}" cryptg || warn "cryptg isn't available for this platform; transfers work but use a bit more CPU."
run "$VENV/bin/python" -c 'import telethon, yt_dlp'
ok "yt-dlp $("$VENV/bin/python" -m yt_dlp --version)"
# Lazy extractors cut ~17 MB of RAM from every yt-dlp job. Optional: failure = normal mode.
run_try "$VENV/bin/python" "$INSTALL_DIR/deploy/update_ytdlp.py" --no-upgrade && ok "yt-dlp lazy extractors enabled" \
  || warn "Couldn't enable lazy extractors; yt-dlp works but uses ~17 MB more RAM per download."

if (( DO_JS )); then
  step "JavaScript runtime for YouTube (QuickJS-ng, ~10 MB of RAM instead of Deno's ~40 MB)"
  qjs=/usr/local/bin/qjs
  if [[ -x "$qjs" && "$("$qjs" --help 2>&1 || true)" == *[Qq]uick[Jj][Ss]-ng* ]]; then ok "Already installed"
  else
    case "$(uname -m)" in x86_64|amd64) arch=x86_64 ;; aarch64|arm64) arch=aarch64 ;; *) arch="" ;; esac
    tmp="$(mktemp)"
    if [[ -n "$arch" ]] && run_try curl -fsSL --retry 3 -o "$tmp" "https://github.com/quickjs-ng/quickjs/releases/latest/download/qjs-linux-${arch}" \
       && chmod 755 "$tmp" && [[ "$("$tmp" --help 2>&1 || true)" == *[Qq]uick[Jj][Ss]-ng* ]]; then mv "$tmp" "$qjs"; ok "Installed QuickJS-ng"
    else rm -f "$tmp"; warn "Couldn't install QuickJS. YouTube downloads need QuickJS, Deno, Node or Bun."; fi
  fi
fi

if (( DO_SWAP && MEM_MB < 1536 )) && [[ -z "$(swapon --show=NAME --noheadings 2>/dev/null)" && ! -e /swapfile ]]; then
  step "Swap safety net"
  if (( $(df -Pm / | awk 'NR==2{print $4}') < SWAP_MB + 1024 )); then warn "Not enough free disk for a ${SWAP_MB} MB swap file; skipping."
  elif { run_try fallocate -l "${SWAP_MB}M" /swapfile || run_try dd if=/dev/zero of=/swapfile bs=1M count="$SWAP_MB" status=none; } \
       && chmod 600 /swapfile && run_try mkswap /swapfile && run_try swapon /swapfile; then
    grep -qs '^/swapfile ' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
    ok "Created a ${SWAP_MB} MB swap file"
  else rm -f /swapfile; warn "Couldn't enable swap (many containers/VPS plans forbid it). Continuing without."; fi
fi

chown -R "$SVC_USER":"$SVC_USER" "$INSTALL_DIR"

# ---------- systemd ----------------------------------------------------------------------
if (( ! DO_SYSTEMD )); then info "Skipping systemd (--no-systemd)."
elif ! have_systemd; then
  warn "systemd isn't running here, so nothing was started. Run it with: cd $INSTALL_DIR && sudo -u $SVC_USER $VENV/bin/python -m bot.main"
else
  step "systemd service"
  mkdir -p "$UNIT_DIR"
  max=600; (( MEM_MB * 70 / 100 < max )) && max=$(( MEM_MB * 70 / 100 )); high=$(( max * 75 / 100 ))  # cap: 70% of RAM, max 600M
  sed -e "s|^User=.*|User=$SVC_USER|" -e "s|/opt/leechbot|$INSTALL_DIR|g" -e "s|^MemoryHigh=.*|MemoryHigh=${high}M|" \
      -e "s|^MemoryMax=.*|MemoryMax=${max}M|" "$INSTALL_DIR/deploy/leechbot.service" > "$UNIT_DIR/leechbot.service"
  cat > "$UNIT_DIR/leechbot-ytdlp-update.service" <<UNIT
[Unit]
Description=Update yt-dlp for the Telegram leech bot
Wants=network-online.target
After=network-online.target

[Service]
Type=oneshot
User=$SVC_USER
ExecStart=$VENV/bin/python $INSTALL_DIR/deploy/update_ytdlp.py
# exit 3 = upgraded fine, but lazy extractors unavailable (normal mode); not a failure
SuccessExitStatus=3
UNIT
  cat > "$UNIT_DIR/leechbot-ytdlp-update.timer" <<UNIT
[Unit]
Description=Weekly yt-dlp update (YouTube breaks old versions often)

[Timer]
OnCalendar=weekly
RandomizedDelaySec=1h
Persistent=true

[Install]
WantedBy=timers.target
UNIT
  run systemctl daemon-reload
  run systemctl enable --now leechbot-ytdlp-update.timer
  missing="$(missing_settings)"
  if [[ -n "$missing" ]]; then  # not configured: starting would only crash-loop. `leechbot` starts it once settings are complete.
    run_try systemctl disable leechbot.service; : > "$INSTALL_DIR/.first-run"
    info "The bot isn't started yet. Still to set: $missing"
  else
    rm -f "$INSTALL_DIR/.first-run"
    run systemctl enable leechbot.service
    since="$(date '+%Y-%m-%d %H:%M:%S')"; run systemctl restart leechbot.service
    info "Waiting for the bot to connect to Telegram..."
    started=0
    for _ in $(seq 1 40); do
      [[ "$(journalctl -u leechbot --since "$since" --no-pager 2>/dev/null || true)" == *"Bot started"* ]] && { started=1; break; }
      systemctl is-failed --quiet leechbot.service && break
      sleep 1
    done
    if (( started )); then ok "Bot is running"
    else journalctl -u leechbot -n 30 --no-pager >&2 || true; die "The bot didn't start (logs above). Most often it's a wrong API ID/hash or token."; fi
  fi
fi

# ---------- summary ----------------------------------------------------------------------
printf '\n%s✔ Installed!%s\n\n' "$G" "$Z"
missing="$(missing_settings)"
if [[ -n "$missing" ]]; then
  printf '%sOne more step:%s run  leechbot settings  and set: %s\n' "$Y" "$Z" "$missing"
  echo "  (API ID/hash: https://my.telegram.org -> API development tools; token: @BotFather; your ID: @userinfobot)"
  echo "  When everything is set, the menu offers to start the bot."
fi
cat <<EOF
    Use it  : send the bot a link (direct file or video site), no commands needed
    Manage  : leechbot   (menu)    leechbot status | log | update | settings
    Install : $INSTALL_DIR   (config: $ENV_FILE)
    yt-dlp  : auto-updates weekly. YouTube bot check? Send cookies.txt to the bot with the caption /cookies
EOF
rm -f "$LOG"
exit 0
