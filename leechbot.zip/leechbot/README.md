# Telegram leech bot

Lightweight, single-user bot for servers with under 1 GB of RAM. Send it a link; it uploads the file
to Telegram. Direct files, YouTube and the ~1,800 other sites yt-dlp supports.

The bot deletes every message you send it (links, commands, files) once it has handled it, so the chat only
shows its own status messages and your downloads.

## Install

One command, on a fresh Debian/Ubuntu server (as root):

    bash <(curl -Ls https://raw.githubusercontent.com/davidbr5264/leechbot/main/install.sh)

It downloads the bot, installs everything (Python, ffmpeg, QuickJS, swap/zram, earlyoom) and adds a
`leechbot` management command. **The installer asks you nothing.** `curl -Ls ... | sudo bash` works too.

When it finishes, set your Telegram credentials in the menu:

    leechbot settings

| Menu item        | Where to get the value                                                      |
|------------------|-----------------------------------------------------------------------------|
| 2  API ID / hash | https://my.telegram.org -> API development tools                            |
| 1  Bot token     | @BotFather (it's checked against Telegram the moment you paste it)          |
| 3  Owner user ID | @userinfobot (only this user can use the bot)                               |

As soon as all four values are set, the menu offers to start the bot, and from then on it starts at boot.
Until then the service stays stopped (it would only crash-loop). `leechbot status` and the menu show what's missing.

Hands-off (credentials given up front; the bot starts right away), e.g. from a script or a VPS "user data" box (`deploy/cloud-init.yaml`):

    API_ID=123456 API_HASH=... BOT_TOKEN=... OWNER_ID=123456789 \
      bash <(curl -Ls https://raw.githubusercontent.com/davidbr5264/leechbot/main/install.sh) -y

`install.sh --help` lists every option (`--no-zram`, `--no-earlyoom`, `--no-swap`, `--dir`, ...).

### How the one-liner finds the bot (your repository)

The one-liner downloads `install.sh` from the repository, and `install.sh` then downloads **`leechbot.zip`** from
the same place, unpacks it and carries on with the installer *inside* the zip. So the repository root needs
exactly two files (everything else is inside the zip):

    install.sh       the entry point the one-liner fetches
    leechbot.zip     the whole bot

To publish or update: on github.com open the repository, **Add file -> Upload files**, drop in the new
`install.sh` and `leechbot.zip` (same names; GitHub replaces them), and commit to `main`. Servers pick up the new
version with `leechbot update`. GitHub's raw links are cached for up to ~5 minutes, so a fresh upload can take a
moment to appear.

Good to know:

- The copy of `install.sh` **inside the zip** is the one that runs, so a stale `install.sh` at the repository
  root is harmless (it only fetches and unpacks).
- The zip may hold the files directly or inside one folder (`leechbot/...`); `.tar.gz` works too.
- Other repository, branch or tag: `LEECHBOT_REPO=user/repo LEECHBOT_REF=v1.0`. Exact file:
  `LEECHBOT_URL=https://.../leechbot.zip`. Pin the download: `LEECHBOT_SHA256=<hash>`.
- The repository must be **public** (a private one needs `LEECHBOT_URL` with a token).
- Servers without `unzip` are fine: Python's `zipfile` is used instead, and `unzip` is installed only if neither exists.

### Playlists

Send a playlist link (a YouTube playlist, a channel's videos, a SoundCloud set, a Vimeo album, ...). The bot checks it,
shows the title and how many videos it has, and gives you the same buttons: **🎬 Playlist** or **🎵 Playlist**
(video or audio only). The videos are downloaded and uploaded **one at a time**, so only one is on disk at once,
with a progress heading like `📃 3/12: title`. A video that fails (private, deleted, too big) is skipped and listed
in the final message. If something would fail for every remaining video (out of memory or disk, YouTube asking
for a login) the bot stops there instead of failing 50 times. `/cancel` stops the whole playlist.

- A YouTube link that is a video **inside** a playlist (`watch?v=...&list=...`) also gets a **Just this one** button.
- At most `MAX_PLAYLIST_ITEMS` videos are taken per link (default 50, up to 500; change it in `.env` or with
  `leechbot settings` -> Limits). The message tells you when a playlist was cut.
- If you have a fixed `/mode` (always video or always audio), a playlist link still asks one question: whole playlist
  or just this one.
- Playlists are only detected for links that look like one, so ordinary video links stay as fast as before.

## Managing it: `leechbot`

    leechbot              menu (start/stop/restart, status, logs, settings, update, uninstall)
    leechbot status       service state, restarts, memory vs its cap, yt-dlp version
    leechbot log          live logs (Ctrl-C to leave)
    leechbot update       fetch the newest version; your settings are kept
    leechbot settings     change bot token, API credentials, owner, limits (token/API changes reset the
                          stored Telegram session so the new ones really take effect)
    leechbot mode         ask (buttons) / always video / always audio for video-site links (also: /mode in Telegram)
    leechbot ytdlp        update yt-dlp now (it also auto-updates weekly)
    leechbot uninstall

## Using it: just send a link

No commands needed.

- **Direct file link** (`.mp4`, `.zip`, `.pdf`, ..., or any URL the server says is a file): downloaded and
  uploaded straight away. Add `| new_name.ext` after the link to rename it. Files over ~2 GB are split
  into `.001`, `.002`... parts (rejoin with `cat name.* > name`).
- **YouTube / video-site link**: the bot replies with **Video / Audio buttons** (unless you set a fixed mode, below), then downloads the best quality available:
  - **Video**: the best video **up to 1080p** plus the best audio, delivered as an **H.264 + AAC `.mp4`** that
    Telegram plays in its own player (see "Playing inside Telegram" below).
  - **Audio**: the **highest-bitrate** audio stream the site offers, as a `.m4a` / `.mp3` / `.flac` that plays in
    Telegram's music player, with cover art and tags (see "Audio quality" below).
- A web page that embeds a video is detected too. Several links in one message are handled one by one.

### Playing inside Telegram

Telegram's built-in player needs **H.264 video + AAC audio in an `.mp4` whose index is at the start of the file**.
`.webm` / `.mkv` / VP9 / AV1 / Opus are sent as plain files (or don't play on some phones). So:

1. yt-dlp is told to prefer H.264 + AAC streams at the best resolution (SDR before HDR, since HDR looks washed out
   once converted), and to merge into `.mp4`. YouTube has H.264 up to 1080p, so most videos need **no re-encoding**
   at all and arrive bit-for-bit as the site stores them.
2. The bot then checks the file with ffprobe. If it is already right, it is uploaded untouched. If only the
   container, the audio or the index position is wrong (e.g. `.mkv`, Opus audio), only that is fixed: video is
   *copied*, audio re-encoded to AAC 192k. If the video itself is VP9/AV1/HEVC (or 10-bit/4:4:4), it is re-encoded to
   H.264 (`-preset veryfast -crf 20`), which takes roughly real-time on one core. Progress is shown in the chat.
3. If that conversion fails or runs out of memory, you still get the original file (as a document).

Settings (`.env`, or `leechbot settings` -> Limits): `YTDL_TRANSCODE=0` never re-encodes video (such videos go up as a
file), `FFMPEG_THREADS` (default 2) limits the encoder. Only the first audio track and no subtitles are kept in a
converted video. `/ytdl <link> doc` skips all conversion.

### Audio quality

Audio downloads take the **highest-bitrate stream the site serves** (FLAC, then 256k AAC, then Opus ~160k, then
128k AAC, ...), instead of whatever yt-dlp ranks first by codec. The result is then put in a file Telegram's music
player handles, with the **cover art and tags embedded**:

| Source stream | Result | Quality |
|---|---|---|
| AAC | `.m4a` | copied bit-for-bit |
| MP3 | `.mp3` | copied bit-for-bit |
| FLAC | `.flac` | copied bit-for-bit |
| ALAC / WAV / PCM | `.flac` | re-encoded, still lossless |
| Opus / Vorbis (e.g. YouTube) | `.m4a` AAC 256k | one lossy-to-lossy step at a higher bitrate than the source |

Every track gets a **square cover** (centre-cropped from the site's 16:9 thumbnail, embedded in the file and shown
in Telegram's player), the title / artist / album tags (YouTube Music's "Artist - Topic" channel names are cleaned
up to "Artist"), and a caption with the real format of what was sent, e.g. `AAC · 240 kbps · 48 kHz`, so you can
check the quality at a glance.

`AUDIO_FORMAT=original` skips that last conversion and keeps Opus as `.opus` (bit-exact, but it doesn't play on
Telegram for iPhone). `AUDIO_BITRATE_K` (96-320, default 256) sets the AAC bitrate; ffmpeg's built-in AAC encoder tops
out around 270 kbps whatever you ask.

What "maximum quality" can and cannot mean: **the bot can never exceed what the site serves**, it only makes sure it
takes the best stream on offer and doesn't throw quality away. YouTube's normal web streams are Opus ~130-160k and
AAC 128k. Higher-bitrate streams (e.g. 256k AAC) may be offered to a logged-in Premium account: send its cookies
with `/cookies` and, if the site offers such a stream, the bot picks it automatically. SoundCloud, Bandcamp and
similar sites give whatever they host. **Spotify music links don't work with yt-dlp** (the audio is DRM-protected),
and tools that "download Spotify" actually fetch a YouTube match, so the quality is the same as sending the YouTube
Music link directly.

### Video or audio?

By default the bot asks: send a video-site link and it replies with **🎬 Video**, **🎵 Audio** and **✖ Cancel**
buttons. Tap one and the job is queued. Questions expire after 10 minutes (or if the bot restarts); just send the
link again.

Prefer no question? Send **`/mode`** to switch between **ask** (default), **always video** and **always audio**.
The choice is remembered across restarts. `/ytdl <link> audio` or `video` skips the question for one link.
From the server: `leechbot mode [ask|video|audio]`. Direct file links are always downloaded as they are. A job keeps the mode you had when you sent its link, so switching while jobs are queued doesn't change them.

Good to know:

- **The 1080p cap** is `YTDL_MAX_HEIGHT` in `.env` (or `leechbot settings` -> Limits), from 144 to 4320. If a video
  has nothing at or below the cap, the bot says so instead of silently downloading something bigger.
- `YTDL_SORT` is an optional extra yt-dlp format sort that is applied on top of the bot's own defaults (and wins
  over them), e.g. `res:720`. You no longer need it for inline playback.
- Big videos: the bot only picks streams that fit under `MAX_DOWNLOAD_MB` *and* roughly half of the free disk
  (video and audio are on disk twice while merging). Files over ~2 GB are split into `.001`, `.002`...
  parts (rejoin with `cat name.* > name`).
- **Live streams** are refused.

Commands, all optional: `/mode`, `/leech <url>` (force a direct download), `/ytdl <url>` (force yt-dlp), add `doc` after
the link to upload it as a file instead of a video, `/cookies`, `/status`, `/cancel` (`/cancel all` also clears
the queue).

## YouTube says "Sign in to confirm you're not a bot"

Server IPs are often flagged. Give the bot cookies from a logged-in session:

1. Open a **private/incognito window** and log in to YouTube (a throwaway account is safest; yt-dlp warns
   that accounts used with it can be banned).
2. In that same tab open `https://www.youtube.com/robots.txt`.
3. Export `youtube.com` cookies with **Get cookies.txt LOCALLY** (Chrome) or **cookies.txt** (Firefox),
   then close the private window.
4. Send the file to the bot with the caption `/cookies`.

It validates the file, stores it privately (mode 600) and deletes your upload from the chat.
`/cookies clear` removes it. If the error returns later, export a fresh file.

## Memory use and crash protection

Measured on the bot (Python 3.12):

| | RAM |
|---|---|
| Bot idle (Telethon client built, handlers registered) | ~51 MB |
| `import telethon` alone | 48 MB (`import pyrogram`, used before: 66 MB) |
| yt-dlp subprocess, YouTube extraction | ~43 MB with lazy extractors, 60 MB without (measured) |
| QuickJS-ng (YouTube JS challenges) | ~10 MB (Deno: 38-47 MB) |
| ffmpeg (thumbnail / merge), transient | ~55 MB |

The bot process is almost entirely the Telegram library: the code you can change is a rounding error next to it.
The savings are in what the bot imports and in everything that runs *around* it.

**Saving RAM**

- **Telethon instead of Pyrogram**: -18 MB for the whole life of the bot. No compiler is needed any more either
  (`cryptg` ships pre-built wheels and is optional).
- **QuickJS-ng instead of Deno** as yt-dlp's JavaScript runtime for YouTube: about -30 MB while a YouTube download
  is being extracted. The bot uses it automatically when a quickjs-ng `qjs` is on the PATH (the installer puts one
  in `/usr/local/bin`); otherwise yt-dlp falls back to its own defaults (Deno/Node/Bun if installed).
- downloads use only the standard library (no aiohttp: -13 MB)
- yt-dlp runs as a subprocess with lazy extractors; the weekly updater regenerates them (-17 MB per download, measured)
- **plain `yt-dlp`, not `yt-dlp[default]`**: skips requests/urllib3/websockets/brotli/mutagen/certifi/pycryptodomex,
  about -10 MB in every yt-dlp process and -22 MB of disk
- **links are classified with one tiny request** (file extension, then the server's content type), instead of
  starting a throwaway process that loads all of yt-dlp's extractors for every link (~48 MB and ~0.3 s each).
  Playlists are recognised from the URL shape (`list=`, `/playlist`, `/@channel`, `/sets/`, `/album/`, ...)
- **oversized files are uploaded in place**: each `.001`, `.002`... part is read straight from the original file
  through a small window object, so there is no copy, no second file on disk and no extra I/O
- one transfer at a time, a 4-thread executor, `MALLOC_ARENA_MAX=2`
- **page-cache hygiene** (`keep_clean` in `bot/utils.py`): the kernel caches every byte it reads or writes, and on a
  small server that cache is what makes the memory cap throttle everything. The bot flushes and drops it twice a
  second while yt-dlp downloads and merges, while a file is read for upload, and while direct downloads are written.
  Measured on the real yt-dlp path (300 MB at 20 MB/s): without it the cache grows by +325 MB and stays; with it the
  peak is about +35 MB and the download's cache is gone at the end
- **`malloc_trim` after every job** (`trim_memory` in `bot/utils.py`): returns freed heap to the OS. On a fragmented
  heap this releases far more than `MALLOC_TRIM_THRESHOLD_` does (a synthetic test: 221 MB -> 42 MB, versus no change)
- compressed swap in RAM (**zram**, installer) and a disk swap file as a last resort

**Cleaning up after every task**

Each job works inside its own folder, `DOWNLOAD_DIR/job_<n>/`, and that folder is deleted however the job ends
(done, failed, cancelled, bot restarting). Everything a task creates is in it:

- the download, converted files, cover art and thumbnails
- yt-dlp's cache and every temp file of yt-dlp (`TMPDIR` and `XDG_CACHE_HOME` point at `job_<n>/.scratch`; before,
  yt-dlp's cache lived in the service user's home and was never cleaned)
- in a playlist, each video's own sub-folder is deleted before the next one starts (one video on disk at a time)

Right after the folder is deleted the worker runs `gc` and `malloc_trim`, so the heap goes back to the OS too. The
page cache of the files goes with the files. At startup the bot also sweeps whatever a crash left behind
(`job_*`, `cookies_upload_*`, `*.cookies`), touching only its own names.

`DOWNLOAD_DIR` must be a real disk. If it sits on tmpfs/ramfs (RAM) the bot logs a warning at startup and `/status`
shows one, because every downloaded byte would then eat memory.

**Installer tuning for small servers** (skip with `--no-tune`)

- a small write-back window (`vm.dirty_background_bytes=16 MB`, `vm.dirty_bytes=64 MB`, only below 3 GB RAM) so a
  big download can't pile up gigabytes of unwritten pages in RAM, and `vm.vfs_cache_pressure=200`
- the systemd journal is capped at 50 MB, and the package manager's download cache is cleared
- yt-dlp and ffmpeg also run at the lowest I/O priority (`ionice`, where the system allows it)

Tried and rejected (measured, no gain): `PYTHONMALLOC=malloc` (+3 MB), `MALLOC_ARENA_MAX` at import time (0),
`PYTHONDONTWRITEBYTECODE` (0), `python -OO` (not worth the risk).

**Not crashing**

- yt-dlp/ffmpeg children are marked first-to-be-killed (`oom_score_adj=500`) and the bot is protected
  (`-100`, `OOMPolicy=continue`): if memory runs out, a download fails with a clear message and the bot lives
- jobs run strictly one at a time, and each yt-dlp/ffmpeg start waits until `MIN_FREE_RAM_MB` (default 150) is
  actually free; playlist probes are serialised too
- **earlyoom** (installer) kills the right process *before* the server starts thrashing; skip with `--no-earlyoom`
- the queue is bounded, a failing job never stops the worker, `Restart=always`
- if the bot is killed or restarted mid-job it tells you which link was interrupted

`/status` shows live numbers: system RAM and swap, the bot (with peak), and the service against its memory cap.

## Operate

Everything above is in the `leechbot` menu. Under the hood it's a normal systemd service:
`journalctl -u leechbot -f` for logs, and the settings live in `/opt/leechbot/.env`.
