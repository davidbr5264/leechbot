# Telegram leech bot

Lightweight, single-user bot for servers with under 1 GB of RAM. Send it a link; it uploads the file
to Telegram. Direct files, YouTube and the ~1,800 other sites yt-dlp supports.

## Install

One command, on a fresh Debian/Ubuntu server (as root):

    bash <(curl -Ls https://raw.githubusercontent.com/davidbr5264/leechbot/main/install.sh)

It downloads the bot, installs everything (Python, ffmpeg, Deno, swap/zram, earlyoom), asks for your
Telegram credentials, starts the service, and adds a `leechbot` management command.
`curl -Ls ... | sudo bash` works too.

You'll be asked for three things, and can skip the fourth:

| Value      | Where to get it                                                         |
|------------|-------------------------------------------------------------------------|
| API ID     | https://my.telegram.org -> API development tools                        |
| API hash   | same page                                                               |
| Bot token  | @BotFather (it's checked against Telegram the moment you paste it)      |
| Your user ID | **press Enter to skip**: the installer prints a link, you tap START in Telegram, and your ID is detected (a one-time code makes sure only you can claim the bot) |

There is no way around the first three: Telegram only issues them through a web login and a chat.

Unattended (nothing to answer), e.g. from a script or a VPS "user data" box (`deploy/cloud-init.yaml`):

    API_ID=123456 API_HASH=... BOT_TOKEN=... OWNER_ID=123456789 \
      bash <(curl -Ls https://raw.githubusercontent.com/davidbr5264/leechbot/main/install.sh) -y

`install.sh --help` lists every option (`--no-zram`, `--no-earlyoom`, `--no-swap`, `--dir`, ...).

### How the one-liner finds the bot (your repository)

The one-liner downloads `install.sh` from the repository, and `install.sh` then downloads **`leechbot.zip`** from
the same place, unpacks it and carries on with the installer *inside* the zip. So the repository root needs
exactly two files (everything else is inside the zip):

    install.sh       the entry point the one-liner fetches
    leechbot.zip     the whole bot

To publish or update: on github.com open the repository, **Add file -> Upload files**, drop in the new
`install.sh` and `leechbot.zip` (same names; GitHub replaces them), and commit to `main`. Servers pick up the new
version with `leechbot update`. GitHub's raw links are cached for up to ~5 minutes, so a fresh upload can take a
moment to appear.

Good to know:

- The copy of `install.sh` **inside the zip** is the one that runs, so a stale `install.sh` at the repository
  root is harmless (it only fetches and unpacks).
- The zip may hold the files directly or inside one folder (`leechbot/...`); `.tar.gz` works too.
- Other repository, branch or tag: `LEECHBOT_REPO=user/repo LEECHBOT_REF=v1.0`. Exact file:
  `LEECHBOT_URL=https://.../leechbot.zip`. Pin the download: `LEECHBOT_SHA256=<hash>`.
- The repository must be **public** (a private one needs `LEECHBOT_URL` with a token).
- Servers without `unzip` are fine: Python's `zipfile` is used instead, and `unzip` is installed only if neither exists.

### Playlists

Send a playlist link (a YouTube playlist, a channel's videos, a SoundCloud set, a Vimeo album, ...). The bot checks it,
shows the title and how many videos it has, and gives you the same buttons: **🎬 Playlist** or **🎵 Playlist**
(video or audio only). The videos are downloaded and uploaded **one at a time**, so only one is on disk at once,
with a progress heading like `📃 3/12: title`. A video that fails (private, deleted, too big) is skipped and listed
in the final message. If something would fail for every remaining video (out of memory or disk, YouTube asking
for a login) the bot stops there instead of failing 50 times. `/cancel` stops the whole playlist.

- A YouTube link that is a video **inside** a playlist (`watch?v=...&list=...`) also gets a **Just this one** button.
- At most `MAX_PLAYLIST_ITEMS` videos are taken per link (default 50, up to 500; change it in `.env` or with
  `leechbot settings` -> Limits). The message tells you when a playlist was cut.
- If you have a fixed `/mode` (always video or always audio), a playlist link still asks one question: whole playlist
  or just this one.
- Playlists are only detected for links that look like one, so ordinary video links stay as fast as before.

## Managing it: `leechbot`

    leechbot              menu (start/stop/restart, status, logs, settings, update, uninstall)
    leechbot status       service state, restarts, memory vs its cap, yt-dlp version
    leechbot log          live logs (Ctrl-C to leave)
    leechbot update       fetch the newest version; your settings are kept
    leechbot settings     change bot token, API credentials, owner, limits (token/API changes reset the
                          stored Telegram session so the new ones really take effect)
    leechbot mode         ask (buttons) / always video / always audio for video-site links (also: /mode in Telegram)
    leechbot ytdlp        update yt-dlp now (it also auto-updates weekly)
    leechbot uninstall

## Using it: just send a link

No commands needed.

- **Direct file link** (`.mp4`, `.zip`, `.pdf`, ..., or any URL the server says is a file): downloaded and
  uploaded straight away. Add `| new_name.ext` after the link to rename it. Files over ~2 GB are split
  into `.001`, `.002`... parts (rejoin with `cat name.* > name`).
- **YouTube / video-site link**: the bot replies with **Video / Audio buttons** (unless you set a fixed mode, below), then downloads the best quality available:
  - **Video**: the best video **up to 1080p** plus the best audio, merged without re-encoding.
  - **Audio**: the best audio only, exactly as the source has it. It is copied, not converted (a stream
    copy: identical audio data, no quality loss), into a file Telegram plays: `.m4a`, `.opus`, `.flac`...
- A web page that embeds a video is detected too. Several links in one message are handled one by one.

### Video or audio?

By default the bot asks: send a video-site link and it replies with **🎬 Video**, **🎵 Audio** and **✖ Cancel**
buttons. Tap one and the job is queued. Questions expire after 10 minutes (or if the bot restarts); just send the
link again.

Prefer no question? Send **`/mode`** to switch between **ask** (default), **always video** and **always audio**.
The choice is remembered across restarts. `/ytdl <link> audio` or `video` skips the question for one link.
From the server: `leechbot mode [ask|video|audio]`. Direct file links are always downloaded as they are. A job keeps the mode you had when you sent its link, so switching while jobs are queued doesn't change them.

Good to know:

- **The 1080p cap** is `YTDL_MAX_HEIGHT` in `.env` (or `leechbot settings` -> Limits), from 144 to 4320. If a video
  has nothing at or below the cap, the bot says so instead of silently downloading something bigger.
- The best stream is often VP9/AV1 in `.webm`/`.mkv`, which Telegram shows as a file rather than an inline
  video (H.264 `.mp4` plays inline). For inline playback set `YTDL_SORT=vcodec:h264` (then `leechbot restart`).
- Big videos: the bot only picks streams that fit under `MAX_DOWNLOAD_MB` *and* roughly half of the free disk
  (video and audio are on disk twice while merging). Files over ~2 GB are split into `.001`, `.002`...
  parts (rejoin with `cat name.* > name`).
- **Live streams** are refused.

Commands, all optional: `/mode`, `/leech <url>` (force a direct download), `/ytdl <url>` (force yt-dlp), add `doc` after
the link to upload it as a file instead of a video, `/cookies`, `/status`, `/cancel` (`/cancel all` also clears
the queue).

## YouTube says "Sign in to confirm you're not a bot"

Server IPs are often flagged. Give the bot cookies from a logged-in session:

1. Open a **private/incognito window** and log in to YouTube (a throwaway account is safest; yt-dlp warns
   that accounts used with it can be banned).
2. In that same tab open `https://www.youtube.com/robots.txt`.
3. Export `youtube.com` cookies with **Get cookies.txt LOCALLY** (Chrome) or **cookies.txt** (Firefox),
   then close the private window.
4. Send the file to the bot with the caption `/cookies`.

It validates the file, stores it privately (mode 600) and deletes your upload from the chat.
`/cookies clear` removes it. If the error returns later, export a fresh file.

## Memory use and crash protection

Measured on the bot (Python 3.12):

| | RAM |
|---|---|
| Bot idle | ~67 MB (65.6 MB of it is just `import pyrogram`) |
| Bot during a 300 MB download + split + upload | ~72 MB (files are streamed to disk) |
| yt-dlp subprocess, one download | ~44 MB with plain yt-dlp, ~55 MB with `yt-dlp[default]` (local-file test; freed when it exits) |
| ffmpeg (thumbnail / merge), transient | ~55 MB |

The bot process is almost entirely the Telegram library: the code you can change is a rounding error next to it.
The savings are in everything that runs *around* it.

**Saving RAM**

- downloads use only the standard library (no aiohttp: -13 MB)
- yt-dlp runs as a subprocess with lazy extractors; the weekly updater regenerates them. (The original notes claim
  -17 MB per download; a local-file test shows almost no difference, so the gain may only appear on site extractors.)
- **plain `yt-dlp`, not `yt-dlp[default]`**: skips requests/urllib3/websockets/brotli/mutagen/certifi/pycryptodomex,
  about -10 MB in every yt-dlp process and -22 MB of disk
- **links are classified with one tiny request** (file extension, then the server's content type), instead of
  starting a throwaway process that loads all of yt-dlp's extractors for every link (~48 MB and ~0.3 s each).
  Playlists are recognised from the URL shape (`list=`, `/playlist`, `/@channel`, `/sets/`, `/album/`, ...)
- **oversized files are uploaded in place**: each `.001`, `.002`... part is read straight from the original file
  through a small window object, so there is no copy, no second file on disk and no extra I/O
- Pyrogram's in-RAM caches cut from 1000 to 50, one transfer at a time, `MALLOC_ARENA_MAX=2`
- **page-cache hygiene** (`keep_clean` in `bot/utils.py`): the kernel caches every byte it reads or writes, and on a
  small server that cache is what makes the memory cap throttle everything. The bot flushes and drops it twice a
  second while yt-dlp downloads and merges, while a file is read for upload, and while direct downloads are written.
  Measured on the real yt-dlp path (300 MB at 20 MB/s): without it the cache grows by +325 MB and stays; with it the
  peak is about +35 MB and the download's cache is gone at the end
- **`malloc_trim` after every job** (`trim_memory` in `bot/utils.py`): returns freed heap to the OS. On a fragmented
  heap this releases far more than `MALLOC_TRIM_THRESHOLD_` does (a synthetic test: 221 MB -> 42 MB, versus no change)
- compressed swap in RAM (**zram**, installer) and a disk swap file as a last resort

**Not crashing**

- yt-dlp/ffmpeg children are marked first-to-be-killed (`oom_score_adj=500`) and the bot is protected
  (`-100`, `OOMPolicy=continue`): if memory runs out, a download fails with a clear message and the bot lives
- jobs run strictly one at a time, and each yt-dlp/ffmpeg start waits until `MIN_FREE_RAM_MB` (default 150) is
  actually free; playlist probes are serialised too
- **earlyoom** (installer) kills the right process *before* the server starts thrashing; skip with `--no-earlyoom`
- the queue is bounded, a failing job never stops the worker, `Restart=always`
- if the bot is killed or restarted mid-job it tells you which link was interrupted

`/status` shows live numbers: system RAM and swap, the bot (with peak), and the service against its memory cap.

Don't run the bot with `python -OO`: it saves no measurable RAM here (66 vs 65 MB) and makes every Telegram API
error (including FloodWait) crash, because Pyrogram builds error messages from docstrings.

## Operate

Everything above is in the `leechbot` menu. Under the hood it's a normal systemd service:
`journalctl -u leechbot -f` for logs, and the settings live in `/opt/leechbot/.env`.
