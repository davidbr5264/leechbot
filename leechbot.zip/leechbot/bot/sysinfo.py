"""Memory numbers for /status and the pre-job admission check. Linux only; anything unreadable is skipped."""
import os
from pathlib import Path

from .utils import human_size

_UNLIMITED = 1 << 60


def _read(path) -> str:
    try:
        return Path(path).read_text()
    except OSError:
        return ""


def meminfo() -> dict[str, int]:
    """/proc/meminfo as {key: bytes}."""
    out = {}
    for line in _read("/proc/meminfo").splitlines():
        key, _, rest = line.partition(":")
        if rest.split():
            out[key] = int(rest.split()[0]) * 1024
    return out


def own_rss() -> tuple[int, int]:
    """(current, peak) RSS of this process in bytes."""
    vals = {}
    for line in _read("/proc/self/status").splitlines():
        if line.startswith(("VmRSS:", "VmHWM:")):
            vals[line[:5]] = int(line.split()[1]) * 1024
    return vals.get("VmRSS", 0), vals.get("VmHWM", 0)


def cgroup() -> tuple[int, int | None, int] | None:
    """(used, limit or None, reclaimable cache) of the systemd service this process runs in (cgroup v2)."""
    rel = next((ln[3:] for ln in _read("/proc/self/cgroup").splitlines() if ln.startswith("0::")), None)
    if rel is None:
        return None
    base = Path("/sys/fs/cgroup") / rel.lstrip("/")
    used = _read(base / "memory.current").strip()
    if not used.isdigit():
        return None
    limit = _read(base / "memory.max").strip()
    stat = dict(ln.split() for ln in _read(base / "memory.stat").splitlines() if len(ln.split()) == 2)
    return (int(used), int(limit) if limit.isdigit() and int(limit) < _UNLIMITED else None,
            int(stat.get("file", 0)))


def headroom() -> int:
    """Bytes still allocatable: system MemAvailable, capped by the service's limit (cache excluded: reclaimable)."""
    mi = meminfo()
    avail = mi.get("MemAvailable", mi.get("MemFree", 0))
    cg = cgroup()
    if cg and cg[1]:
        avail = min(avail, max(cg[1] - (cg[0] - cg[2]), 0))
    return avail


def ram_backed(path) -> bool:
    """True when `path` lives on tmpfs/ramfs: every downloaded byte would then be held in RAM."""
    target = os.path.realpath(path)
    best, fstype = "", ""
    for line in _read("/proc/self/mountinfo").splitlines():
        left, _, right = line.partition(" - ")
        fields = left.split()
        if len(fields) < 5 or not right:
            continue
        mount = fields[4].replace("\\040", " ")
        if (target == mount or target.startswith(mount.rstrip("/") + "/")) and len(mount) > len(best):
            best, fstype = mount, right.split()[0]
    return fstype in ("tmpfs", "ramfs")


def render() -> str:
    mi = meminfo()
    total, avail = mi.get("MemTotal", 0), mi.get("MemAvailable", mi.get("MemFree", 0))
    rss, peak = own_rss()
    lines = [
        "🧠 Memory",
        f"System: {human_size(total - avail)} used of {human_size(total)} ({human_size(avail)} available)",
        f"Swap: {human_size(mi['SwapTotal'] - mi.get('SwapFree', 0))} used of {human_size(mi['SwapTotal'])}"
        if mi.get("SwapTotal") else "Swap: none",
        f"Bot process: {human_size(rss)} (peak {human_size(peak)})",
    ]
    cg = cgroup()
    tight = bool(total) and avail < 0.10 * total
    if cg:
        used, limit, cache = cg
        lines.append(f"Service: {human_size(used)}" + (f" of {human_size(limit)} cap" if limit else "")
                     + f" (cache {human_size(cache)})")
        tight = tight or bool(limit) and used - cache > 0.85 * limit
    if tight:
        lines.append("⚠️ Memory is tight: new jobs may be slow, or get killed.")
    return "\n".join(lines)
