"""Hygiene for heavy child processes (yt-dlp, ffmpeg) so low-RAM servers don't crash.

1. OOM priority: children get oom_score_adj=+500, so if memory runs out the kernel (and earlyoom) kill THEM
   first and the bot survives. They also run at nice 10 to keep the bot responsive.
2. Admission control: before starting one, wait until enough RAM is actually free.

Jobs run one at a time (see jobs.py), so there is no extra "one heavy process" lock to maintain."""
import asyncio

from . import config, sysinfo
from .utils import JobError

_WRAP = (
    "echo 500 > /proc/self/oom_score_adj 2>/dev/null; "
    'if command -v nice >/dev/null 2>&1; then exec nice -n 10 "$@"; fi; exec "$@"'
)
OOM_MESSAGE = (
    "💥 The server ran out of memory and the process was killed. "
    "Try a lower resolution or audio only (see /status)."
)


async def spawn(cmd: list[str], *, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT):
    """exec the command through a tiny shell that lowers its priority (same PID afterwards)."""
    # limit: a pathological very long output line can't blow up the StreamReader
    return await asyncio.create_subprocess_exec("/bin/sh", "-c", _WRAP, "sh", *cmd,
                                                stdout=stdout, stderr=stderr, limit=1 << 20)


def oom_killed(returncode: int | None) -> bool:
    return returncode in (-9, 137)


async def wait_for_memory(need_mb: int | None = None, timeout: float = 120, on_wait=None, poll: float = 3.0) -> None:
    need = (need_mb or config.MIN_FREE_RAM_MB) * 2**20
    waited = 0.0
    while (free := sysinfo.headroom()) < need:
        if waited >= timeout:
            raise JobError(
                f"Not enough free memory ({free // 2**20} MB free, need {need // 2**20} MB). "
                "Try again in a moment (see /status)."
            )
        if waited == 0 and on_wait:
            await on_wait(f"⏳ Low memory ({free // 2**20} MB free). Waiting for it to free up…")
        await asyncio.sleep(poll)
        waited += poll
