"""yt-dlp wrapper. yt-dlp always runs as a subprocess, so its memory goes back to the OS when it exits.

Video: the best H.264 + AAC streams up to YTDL_MAX_HEIGHT, merged into an .mp4 that Telegram plays inline
(anything else is converted afterwards, see media.prepare_video).
Audio: the highest-bitrate audio stream the site offers, sent exactly as downloaded (no re-encoding), with
its tags embedded and the cover as the chat preview."""
import asyncio
import contextlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from . import config, media, system
from .utils import JobError, assert_safe_url, free_space, keep_clean, pretty_filename


def _js_args() -> list[str]:
    """QuickJS-ng (~10 MB) solves YouTube's JS challenges instead of yt-dlp's default Deno (~40 MB).
    Used only when a quickjs-ng `qjs` is installed (distro packages are too old for yt-dlp); otherwise
    yt-dlp keeps its own defaults."""
    if qjs := shutil.which("qjs"):
        try:
            out = subprocess.run([qjs, "--help"], capture_output=True, text=True, timeout=5)
            if "quickjs-ng" in (out.stdout + out.stderr).lower():
                return ["--no-js-runtimes", "--js-runtimes", f"quickjs:{qjs}"]
        except (OSError, subprocess.SubprocessError):
            pass
    return []


YTDLP = [sys.executable, "-m", "yt_dlp", "--ignore-config", "--no-warnings", *_js_args()]
DISK_CHECK_EVERY = 5  # seconds
_probe_lock = asyncio.Lock()  # at most one playlist probe at a time (each is a ~60 MB process)


@dataclass
class Downloaded:
    path: Path
    was_playlist: bool  # the link was a playlist; only its first item was downloaded


@dataclass
class PlaylistInfo:
    title: str
    entries: list[tuple[str, str]]  # (title, url) of the videos that will be downloaded, in order
    total: int  # how many videos the playlist has, when the site says (0 = unknown)
    truncated: bool
    mixed: bool  # a video inside a playlist (watch?v=...&list=...), so "just this one" is possible


# ---------- playlists ----------------------------------------------------------------

# URL shapes that mean "a collection": /playlist/, /channel/, /@name, /@name/videos, /sets/, /album/, ...
_LIST_PATH = re.compile(
    r"/(playlists?|sets|albums?|series|shows?|seasons?|collections?|courses?|channels?|c|user|feed)(/|$)"
    r"|/@[^/]+(/(videos|shorts|streams|live|playlists|releases|podcasts))?/?$",
    re.IGNORECASE,
)


def may_be_playlist(url: str) -> bool:
    """Cheap URL check deciding whether the (slower) playlist probe is worth it; plain video links skip it."""
    parts = urlsplit(url)
    return "list" in parse_qs(parts.query) or bool(_LIST_PATH.search(parts.path))


def _is_mixed(url: str) -> bool:
    parts = urlsplit(url)
    q = parse_qs(parts.query)
    return ("list" in q and ("v" in q or (parts.hostname or "").endswith("youtu.be"))
            and not parts.path.startswith("/playlist"))


def _entry_url(e: dict) -> str | None:
    u = e.get("url") or e.get("webpage_url") or ""
    if isinstance(u, str) and u.lower().startswith(("http://", "https://")):
        return u
    if (e.get("ie_key") or "").lower() == "youtube" and e.get("id"):
        return f"https://www.youtube.com/watch?v={e['id']}"
    return None


@contextmanager
def _cookie_copy():
    """yt-dlp rewrites its cookie file on exit, so side jobs get a throwaway copy and never race a download.
    Yields yt-dlp arguments (empty when there are no cookies)."""
    name, args = None, []
    if config.COOKIES_FILE.is_file():
        try:
            config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
            fd, name = tempfile.mkstemp(dir=config.DOWNLOAD_DIR, suffix=".cookies")  # created mode 0600
            os.close(fd)
            shutil.copyfile(config.COOKIES_FILE, name)
            args = ["--cookies", name]
        except OSError:
            pass
    try:
        yield args
    finally:
        if name:
            Path(name).unlink(missing_ok=True)


async def probe_playlist(url: str) -> PlaylistInfo | None:
    """List what a playlist link contains, without downloading anything. None = a single video, or the probe
    failed (the real download then reports the problem)."""
    try:
        await assert_safe_url(url)
    except JobError:
        return None
    cap = config.MAX_PLAYLIST_ITEMS
    async with _probe_lock:
        await system.wait_for_memory()
        with _cookie_copy() as cookies:
            # one extra entry tells us the list was cut
            cmd = [*YTDLP, "--no-cache-dir", "--flat-playlist", "-J", "--playlist-end", str(cap + 1), *cookies, url]
            try:
                _, out = await system.capture(cmd, timeout=90)
            except asyncio.TimeoutError:
                return None
    try:
        data = json.loads(out)
    except ValueError:
        return None
    if not isinstance(data, dict) or data.get("_type") != "playlist":
        return None

    entries = []
    for e in data.get("entries") or []:
        key = (e.get("ie_key") or "").lower() if isinstance(e, dict) else "playlist"
        if "tab" in key or "playlist" in key:  # nested playlist (a channel's Videos/Shorts tabs), not a video
            continue
        if u := _entry_url(e):
            entries.append((str(e.get("title") or e.get("id") or "video"), u))
    if len(entries) < 2:
        return None
    declared = data.get("playlist_count")
    total = declared if isinstance(declared, int) and declared >= len(entries) else 0
    return PlaylistInfo(str(data.get("title") or "Playlist"), entries[:cap], total,
                        len(entries) > cap or total > cap, _is_mixed(url))


# ---------- downloading --------------------------------------------------------------

def _login_wall(err: str) -> bool:
    return "not a bot" in err or "Sign in to confirm" in err


def explain(err: str, has_cookies: bool) -> str:
    """Turn yt-dlp's errors into something actionable."""
    if "Requested format is not available" in err:
        return (f"No stream at or below {config.YTDL_MAX_HEIGHT}p (and small enough for the size limit) exists for that link. "
                "Raise YTDL_MAX_HEIGHT or MAX_DOWNLOAD_MB with `leechbot settings`.")
    msg = err[:250]
    if _login_wall(err):
        msg += ("\n\n🍪 YouTube is asking for a login. "
                + ("Your cookies look expired or rotated: export a fresh file and send it with /cookies."
                   if has_cookies else
                   "Send your YouTube cookies.txt to this chat with the caption /cookies (see /help)."))
    return msg


def size_cap(dest_dir: Path) -> int:
    """Largest single stream we can afford. Video and audio are downloaded separately and then merged,
    so peak disk use is about twice the final size."""
    return min(config.MAX_DOWNLOAD, (free_space(dest_dir) - config.MIN_FREE_SPACE) // 2)


# `lang` first keeps yt-dlp's "original language" choice for multi-language YouTube audio. Later -S flags win, so
# the user's YTDL_SORT (added last) overrides these.
AUDIO_SORT = "lang,quality,br,asr,acodec"  # bitrate before codec: a 256k AAC beats a 130k Opus; FLAC beats both
VIDEO_SORT = "lang,res,fps,hdr:sdr,vcodec:h264,acodec:aac"  # same resolution: H.264 + AAC (plays in Telegram), SDR


# File names: just the title. Music with an artist tag becomes "Artist - Title". Every download has its own folder,
# so no video id is needed to keep names apart.
VIDEO_NAME = "%(title).100B.%(ext)s"
AUDIO_NAME = "%(artist&{} - |).60B%(title).100B.%(ext)s"


def format_args(cap: int, audio: bool = False) -> list[str]:
    """What to download. Streams of unknown size or height are allowed through the filters.

    video: best video no taller than YTDL_MAX_HEIGHT + best audio, merged into .mp4. At equal resolution H.264 and
           AAC win, so the usual result plays inline in Telegram without re-encoding.
    audio: the highest-bitrate audio stream, never re-encoded. -x --audio-format best only takes the audio out
           of a combined video when a site has no audio-only stream, and puts a webm's Opus into a plain .opus
           (a stream copy: the sound data is identical)."""
    fits = f"[filesize<?{cap}][filesize_approx<?{cap}]"
    if audio:
        args = ["-f", f"ba{fits}/b{fits}", "-S", AUDIO_SORT, "-x", "--audio-format", "best",
                "--embed-metadata", "--write-thumbnail",
                # YouTube Music's auto-generated channels are called "Artist - Topic"; the tag should say "Artist"
                "--replace-in-metadata", "uploader", r"\s+-\s+Topic$", ""]
    else:
        tall = f"[height<=?{config.YTDL_MAX_HEIGHT}]"
        args = ["-f", f"bv*{fits}{tall}+ba{fits}/b{fits}{tall}", "-S", VIDEO_SORT, "--merge-output-format", "mp4"]
    if config.YTDL_SORT:
        args += ["-S", config.YTDL_SORT]
    return args


def _find_thumb(media_path: Path) -> Path | None:
    """The thumbnail yt-dlp wrote next to the download (same name, image extension)."""
    for ext in (".jpg", ".jpeg", ".png", ".webp"):
        if (p := media_path.with_suffix(ext)).is_file():
            return p
    return None


def _num(s: str) -> int:
    try:
        return int(float(s))
    except ValueError:  # "NA"
        return 0


async def download(url: str, dest_dir: Path, on_progress, on_wait=None, audio: bool = False,
                   convert: bool = True, on_convert=None, scratch: Path | None = None) -> Downloaded:
    """convert=False hands back the file exactly as downloaded (used for the 'doc' flag).

    scratch: where yt-dlp's temp files and cache go (default: inside dest_dir). The caller deletes it with
    the job's folder, so no cache outlives the task."""
    await assert_safe_url(url)
    cap = size_cap(dest_dir)
    if cap < 50 * config.MiB:
        raise JobError("Not enough free disk space.", fatal=True)

    has_cookies = config.COOKIES_FILE.is_file()
    cmd = [
        *YTDLP, "--no-playlist", "--playlist-items", "1",  # a playlist link must not download the whole playlist
        "--match-filter", "!is_live",                      # live streams never end
        "--progress", "--newline",
        "--progress-template",
        "download:PROG %(progress.downloaded_bytes)s %(progress.total_bytes)s %(progress.total_bytes_estimate)s",
        # a bare word would be read as a field name, so each marker carries a real field
        "--print", "playlist:PLAYLIST %(id)s",       # printed once when the link is a playlist
        "--print", "after_filter:PASSED %(id)s",     # printed only for videos that pass --match-filter
        "--print", "after_move:FILE %(filepath)s",
        "--max-filesize", str(cap),
        "-o", str(dest_dir).replace("%", "%%") + "/" + (AUDIO_NAME if audio else VIDEO_NAME),  # a % in the path is not a field
        *format_args(cap, audio),
        *(["--cookies", str(config.COOKIES_FILE)] if has_cookies else []),
        url,
    ]

    filepath = last_err = ""
    passed = playlist = disk_full = False
    next_check = time.monotonic() + DISK_CHECK_EVERY
    await system.wait_for_memory(on_wait=on_wait)
    async with keep_clean(dest_dir), system.running(cmd, scratch=scratch or dest_dir / ".scratch") as proc:
        async for raw in proc.stdout:
            line = raw.decode(errors="replace").strip()
            if line.startswith("PROG "):
                parts = line.split()[1:]
                if len(parts) >= 3:
                    await on_progress(_num(parts[0]), _num(parts[1]) or _num(parts[2]))
            elif line.startswith("FILE "):
                filepath = line[5:]
            elif line.startswith("PLAYLIST "):
                playlist = True
            elif line.startswith("PASSED "):
                passed = True
            elif line.startswith("ERROR"):
                last_err = line
            if time.monotonic() >= next_check:  # sizes of HLS/DASH streams are unknown: watch the disk instead
                next_check = time.monotonic() + DISK_CHECK_EVERY
                if free_space(dest_dir) < config.MIN_FREE_SPACE // 2:
                    disk_full = True
                    proc.kill()
                    break
        rc = await proc.wait()

    if disk_full:
        raise JobError("The disk is almost full, so the download was stopped. Free some space or lower MAX_DOWNLOAD_MB.",
                       fatal=True)
    if system.oom_killed(rc):
        raise JobError(system.OOM_MESSAGE, fatal=True)
    if rc == 0 and not passed and not filepath:  # the only filter we set is "not live"
        raise JobError("Nothing was downloaded. Live streams aren't supported (they never end), and the link may have no media.")
    if rc != 0 or not filepath or not Path(filepath).exists():
        err = last_err or "Nothing was downloaded (maybe larger than the allowed size)."
        raise JobError(explain(err, has_cookies), fatal=_login_wall(err))
    path, cover = Path(filepath), _find_thumb(Path(filepath))
    tidy = path.with_name(pretty_filename(path.name))
    if tidy != path and not tidy.exists():
        with contextlib.suppress(OSError):
            path = path.rename(tidy)
    if convert:  # make videos play in Telegram (on any failure the file is returned untouched); audio stays as is
        if audio:
            await media.cover_thumb(path, cover)
        else:
            path = await media.prepare_video(path, on_convert)
    return Downloaded(path, playlist)
