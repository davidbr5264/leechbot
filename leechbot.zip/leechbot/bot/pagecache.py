"""Keep the kernel's page cache from filling a small server's RAM while big files are written or read.

Linux caches every file it writes or reads. On a 512 MB server a 2 GB download would push that cache against
the service's memory cap and make everything slow. Flushing a file and telling the kernel to forget its pages
(posix_fadvise DONTNEED) is safe: nothing is lost, the data is already on disk.

Measured with the real yt-dlp path, a 300 MB download at 20 MB/s: without this the cache grows by +325 MB and stays;
with it the peak is about +35 MB (0.5 s interval) and the download's cache is gone at the end. On a loopback
download of 150 MB/s the peak is higher (the cleaner can only run so often) but the end result is the same."""
import asyncio
import contextlib
import os
from contextlib import asynccontextmanager
from pathlib import Path


def drop(path: Path, sync: bool = True) -> None:
    """Flush `path` and drop it from the page cache. Safe on files another process is still writing."""
    try:
        fd = os.open(path, os.O_RDONLY)
    except OSError:
        return  # vanished or unreadable: nothing to clean
    try:
        if sync:
            os.fdatasync(fd)  # dirty pages can't be dropped until they are on disk
        os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
    except (OSError, AttributeError):
        pass  # filesystem or platform without support: harmless
    finally:
        os.close(fd)


def drop_target(target: Path) -> None:
    """Drop one file, or every file directly inside a directory."""
    try:
        if target.is_dir():
            with os.scandir(target) as entries:
                for entry in entries:
                    if entry.is_file(follow_symlinks=False):
                        drop(Path(entry.path))
        else:
            drop(target)
    except OSError:
        pass


@asynccontextmanager
async def keep_clean(target: Path, interval: float = 0.5):
    """While the block runs, flush and drop `target`'s cached pages every `interval` seconds (and once at the end)."""

    async def loop() -> None:
        while True:
            await asyncio.sleep(interval)
            await asyncio.to_thread(drop_target, target)

    task = asyncio.create_task(loop())
    try:
        yield
    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        await asyncio.to_thread(drop_target, target)
