import asyncio
import itertools
import json
import logging
import os
import secrets
import shutil
import time
from dataclasses import dataclass
from pathlib import Path

from pyrogram import Client, enums, filters, idle
from pyrogram.handlers import CallbackQueryHandler, MessageHandler
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from . import config, cookies, detect, memory, prefs, procs, sysinfo, uploader
from .downloaders import direct, ytdlp
from .progress import Progress
from .utils import JobError, free_space, human_size, human_time

log = logging.getLogger("leechbot")

HELP = (
    "Just send me a link, no command needed:\n"
    "- a direct file link: I download it and upload it here\n"
    "- a YouTube or other video-site link: I ask whether you want the video or just the audio, then download "
    f"the best quality available (video is capped at {config.YTDL_MAX_HEIGHT}p)\n"
    f"- a playlist link: I show how many videos it has and download them one by one (up to {config.MAX_PLAYLIST_ITEMS})\n\n"
    "Rename a direct download:  link | new_name.ext\n\n"
    "Commands:\n"
    "/mode  - ask every time (default), or always video, or always audio (/mode ask, /mode video, /mode audio)\n"
    "/leech <url>  - force a direct download\n"
    "/ytdl <url> [audio|video]  - force yt-dlp; audio or video skips the question for this link\n"
    "/cookies  - YouTube cookies (fixes the 'not a bot' error)\n"
    "/status  - queue, memory, disk\n"
    "/cancel  - cancel the running job  (/cancel all also clears the queue)\n\n"
    "Add 'doc' after a link in /leech or /ytdl to upload it as a file instead of a video."
)


@dataclass
class Job:
    id: int
    kind: str  # "leech" | "ytdl"
    url: str
    chat_id: int
    msg: Message  # the status message we keep editing
    name: str | None = None
    as_document: bool = False
    audio: bool = False  # ytdl only: best audio instead of video
    playlist: ytdlp.PlaylistInfo | None = None  # ytdl only: download all of these, one at a time


@dataclass
class Pending:
    """A video-site link waiting for you to tap Video or Audio."""
    url: str
    chat_id: int
    msg: Message  # the status message that carries the buttons
    name: str | None
    as_document: bool
    created: float
    info: ytdlp.PlaylistInfo | None = None  # set when the link is a playlist
    audio: bool | None = None  # set when video/audio is already decided (flag or fixed /mode)


PENDING_TTL = 10 * 60  # seconds a Video/Audio question stays valid
PENDING_MAX = 50
pending: dict[str, Pending] = {}

queue: asyncio.Queue = asyncio.Queue()
state: dict = {"job": None, "task": None, "worker": None}
job_ids = itertools.count(1)
shutting_down = False
_tasks: set[asyncio.Task] = set()


def bg(coro) -> None:
    """Run a coroutine in the background so message handlers return immediately."""
    t = asyncio.create_task(coro)
    _tasks.add(t)

    def done(task: asyncio.Task) -> None:
        _tasks.discard(task)
        if not task.cancelled() and task.exception():
            log.error("background task failed", exc_info=task.exception())

    t.add_done_callback(done)


async def _edit(msg, text: str, **kw) -> None:
    try:
        await msg.edit_text(text, **kw)
    except Exception:
        pass  # not-modified, flood wait, deleted message: never fail over a status edit


def parse_args(message: Message):
    parts = (message.text or "").split(None, 1)
    if len(parts) < 2:
        return None
    left, _, right = parts[1].partition("|")
    tokens = left.split()
    if not tokens:
        return None
    return tokens[0], {t.lower() for t in tokens[1:]}, (right.strip() or None)


def queue_text() -> str:
    ahead = queue.qsize() + (1 if state["job"] else 0)
    return f"🕐 Queued (position {ahead + 1})" if ahead else "🚀 Starting…"


def queue_full() -> bool:
    return queue.qsize() >= config.MAX_QUEUE


# ---------- automatic handling of links ----------------------------------------------

def _prune_pending() -> None:
    now = time.time()
    for token in [t for t, p in pending.items() if now - p.created > PENDING_TTL]:
        pending.pop(token, None)
    while len(pending) > PENDING_MAX:  # dicts keep insertion order: drop the oldest
        pending.pop(next(iter(pending)), None)


def _choice_keyboard(token: str, info: ytdlp.PlaylistInfo | None, audio: bool | None) -> InlineKeyboardMarkup:
    """Buttons carry pick:<token>:<scope><kind>. scope: s = this video, p = whole playlist. kind: v = video, a = audio."""
    kinds = [("v", "🎬"), ("a", "🎵")] if audio is None else [("a", "🎵")] if audio else [("v", "🎬")]
    rows = []
    if info is None:
        names = {"v": "Video", "a": "Audio"}
        rows.append([InlineKeyboardButton(f"{emoji} {names[k]}", callback_data=f"pick:{token}:s{k}") for k, emoji in kinds])
    else:
        count = f"{len(info.entries)}{'+' if info.truncated else ''}"
        scopes = [("p", f"Playlist ({count})")] + ([("s", "Just this one")] if info.mixed else [])
        for scope, text in scopes:
            rows.append([InlineKeyboardButton(f"{emoji} {text}", callback_data=f"pick:{token}:{scope}{k}") for k, emoji in kinds])
    rows.append([InlineKeyboardButton("✖ Cancel", callback_data=f"pick:{token}:x")])
    return InlineKeyboardMarkup(rows)


def _question_text(url: str, info: ytdlp.PlaylistInfo | None, audio: bool | None) -> str:
    if info is None:
        return f"What do you want from this link?\n{url[:120]}"
    n = len(info.entries)
    more = f"of {info.total}" if info.total > n else "(there are more)"
    size = f"{n} videos" if not info.truncated else f"The first {n} {more} will be taken (limit: MAX_PLAYLIST_ITEMS)"
    text = f"📃 Playlist: {info.title[:80]}\n{size}\nThey are downloaded and uploaded one by one."
    if audio is None:
        text += "\n🎬 = video, 🎵 = audio only"
    if info.mixed:
        text += "\nThis link also points at a single video."
    return text


def _kind_label(want_audio: bool, info: ytdlp.PlaylistInfo | None = None) -> str:
    kind = "🎵 Best audio" if want_audio else f"🎬 Best video (up to {config.YTDL_MAX_HEIGHT}p)"
    if info:
        return f"📃 Playlist: {info.title[:60]} ({len(info.entries)} videos)\n{kind}\n"
    return kind + "\n"


async def _enqueue_ytdl(status: Message, url: str, chat_id: int, name: str | None, as_document: bool,
                        want_audio: bool, playlist: ytdlp.PlaylistInfo | None = None) -> None:
    await _edit(status, _kind_label(want_audio, playlist) + queue_text())
    await queue.put(Job(next(job_ids), "ytdl", url, chat_id, status, name=name,
                        as_document=as_document, audio=want_audio, playlist=playlist))


async def handle_url(message: Message, url: str, name: str | None = None, force: str | None = None,
                     as_document: bool = False, audio: bool | None = None) -> None:
    if queue_full():
        await message.reply_text(f"The queue is full ({config.MAX_QUEUE} waiting). Try again in a bit.")
        return
    status = await message.reply_text("🔎 Checking link…")
    try:
        verdict = detect.Verdict(force) if force else await detect.classify(url)
        if verdict.kind == "direct":
            head = verdict.head
            label = ""
            if head and (head.filename or head.size):
                label = f"📎 {name or head.filename or 'file'}" + (f" ({human_size(head.size)})" if head.size else "") + "\n"
            await _edit(status, label + queue_text())
            await queue.put(Job(next(job_ids), "leech", url, message.chat.id, status, name=name,
                                as_document=as_document))
            return

        # A video-site link. Is it a playlist? Plain video links skip this check, so they stay fast.
        extractor = verdict.extractor or (await ytdlp.match_extractor(url) if force else None)
        info = await ytdlp.probe_playlist(url) if ytdlp.may_be_playlist(url, extractor) else None

        # Video or audio: an explicit flag wins, then a fixed /mode, else ask.
        mode = prefs.get_mode()
        known = audio if audio is not None else (mode == "audio" if mode != "ask" else None)
        if info is None and known is not None:
            await _enqueue_ytdl(status, url, message.chat.id, name, as_document, known)
            return
        _prune_pending()
        token = secrets.token_hex(4)
        pending[token] = Pending(url, message.chat.id, status, name, as_document, time.time(), info, known)
        await _edit(status, _question_text(url, info, known), reply_markup=_choice_keyboard(token, info, known))
    except JobError as e:
        await _edit(status, f"❌ {e}")
    except Exception as e:  # never let one bad link kill the handler task silently
        log.exception("handle_url failed")
        await _edit(status, f"❌ {type(e).__name__}: {str(e)[:200]}")


async def cb_pick(client, query: CallbackQuery):
    data = query.data.decode() if isinstance(query.data, bytes) else query.data
    _, _, rest = data.partition(":")
    token, _, choice = rest.partition(":")
    item = pending.get(token)
    if item is None or time.time() - item.created > PENDING_TTL:
        pending.pop(token, None)
        await query.answer("This choice expired. Send the link again.", show_alert=True)
        await _edit(query.message, "⌛ Expired. Send the link again.")
        return
    if choice == "x":
        pending.pop(token, None)
        await query.answer("Cancelled")
        await _edit(item.msg, "❌ Cancelled")
        return
    scope, kind = choice[:1], choice[1:]
    valid = (
        scope in ("s", "p") and kind in ("v", "a")
        and (scope == "s" or item.info is not None)
        and (scope == "p" or item.info is None or item.info.mixed)
        and (item.audio is None or (kind == "a") == item.audio)
    )
    if not valid:
        await query.answer()
        return
    if queue_full():  # keep the question so you can tap again in a moment
        await query.answer(f"The queue is full ({config.MAX_QUEUE} waiting). Try again in a bit.", show_alert=True)
        return
    pending.pop(token, None)  # first tap wins: a double tap can't queue the link twice
    await query.answer("Audio" if kind == "a" else "Video")
    await _enqueue_ytdl(item.msg, item.url, item.chat_id, item.name, item.as_document, kind == "a",
                        item.info if scope == "p" else None)


async def handle_urls(message: Message, urls: list) -> None:
    for url, name in urls:  # one at a time: classifying may spawn a subprocess
        await handle_url(message, url, name)


async def on_text(client, message):
    urls = detect.extract_urls(message.text or "", message.entities)
    if not urls:
        await message.reply_text("Send me a link (a direct file or a video site), or /help.")
        return
    bg(handle_urls(message, urls))


async def cmd_start(client, message):
    await message.reply_text(HELP)


async def _command(message: Message, force: str) -> None:
    parsed = parse_args(message)
    if not parsed:
        await message.reply_text(HELP)
        return
    url, flags, name = parsed
    audio = True if "audio" in flags else False if "video" in flags else None  # per-link override: skips the question and /mode
    bg(handle_url(message, url, name if force == "direct" else None, force=force,
                  as_document="doc" in flags, audio=audio))


def mode_message() -> tuple[str, InlineKeyboardMarkup]:
    mode = prefs.get_mode()
    descriptions = {
        "ask": "❓ Ask: every video-site link gets Video / Audio buttons",
        "video": f"🎬 Video: always the best video up to {config.YTDL_MAX_HEIGHT}p plus the best audio (no question)",
        "audio": "🎵 Audio: always the best audio only, original quality, copied not converted (no question)",
    }
    labels = {"ask": "❓ Ask", "video": "🎬 Video", "audio": "🎵 Audio"}
    text = (f"What happens with video-site links:\n{descriptions[mode]}\n\n"
            "Direct file links are always downloaded exactly as they are.")
    buttons = [InlineKeyboardButton(f"Switch to {labels[m]}", callback_data=f"mode:{m}") for m in prefs.MODES if m != mode]
    return text, InlineKeyboardMarkup([buttons])


async def cmd_mode(client, message):
    words = (message.text or "").lower().split()[1:]
    if words and words[0] in prefs.MODES:
        prefs.set_mode(words[0])
    elif words:
        await message.reply_text("Use /mode to see and switch, or /mode ask, /mode video, /mode audio.")
        return
    text, keyboard = mode_message()
    await message.reply_text(text, reply_markup=keyboard)


async def cb_mode(client, query: CallbackQuery):
    data = query.data.decode() if isinstance(query.data, bytes) else query.data
    wanted = data.partition(":")[2]
    if wanted in prefs.MODES:
        prefs.set_mode(wanted)
    text, keyboard = mode_message()
    await _edit(query.message, text, reply_markup=keyboard)
    await query.answer(f"Mode: {prefs.get_mode()}")


async def cmd_leech(client, message):
    await _command(message, "direct")


async def cmd_ytdl(client, message):
    await _command(message, "ytdl")


COOKIE_HELP = (
    "To fix YouTube's bot check, send me a cookies.txt FILE with the caption /cookies "
    "(or reply to the file with /cookies).\n\n"
    "How to export it (YouTube rotates cookies on open tabs, so do it exactly like this):\n"
    "1. Open a private/incognito window and log in to YouTube (a throwaway account is safest).\n"
    "2. In that same tab, open https://www.youtube.com/robots.txt\n"
    "3. Export youtube.com cookies with the 'Get cookies.txt LOCALLY' (Chrome) or "
    "'cookies.txt' (Firefox) extension.\n"
    "4. Close the private window, then send me the file.\n\n"
    "/cookies clear  - delete the stored cookies"
)


def cookie_status() -> str:
    f = config.COOKIES_FILE
    if not f.is_file():
        return "🍪 No cookies installed."
    return f"🍪 Cookies installed (last updated {human_time(time.time() - f.stat().st_mtime)} ago)."


async def cmd_cookies(client, message):
    parts = (message.text or message.caption or "").split(None, 1)
    arg = parts[1].strip().lower() if len(parts) > 1 else ""

    if arg == "clear":
        config.COOKIES_FILE.unlink(missing_ok=True)
        await message.reply_text("🗑 Cookies removed.")
        return

    src = message if message.document else (
        message.reply_to_message if message.reply_to_message and message.reply_to_message.document else None
    )
    if src is None:
        await message.reply_text(f"{cookie_status()}\n\n{COOKIE_HELP}")
        return

    job = state["job"]
    if job and job.kind == "ytdl":  # yt-dlp rewrites the file on exit and would clobber ours
        await message.reply_text("A yt-dlp job is running. Send the cookies again when it finishes.")
        return
    if src.document.file_size and src.document.file_size > cookies.MAX_BYTES:
        await message.reply_text("❌ That file is too big to be a cookies file (limit 1 MB).")
        return

    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    tmp = config.DOWNLOAD_DIR / f"cookies_upload_{secrets.token_hex(4)}"
    try:
        path = await client.download_media(src, file_name=str(tmp))
        if not path:
            raise JobError("Couldn't download that file from Telegram.")
        info = cookies.parse(Path(path).read_bytes())
    except JobError as e:
        await message.reply_text(f"❌ {e}")
        return
    finally:
        tmp.unlink(missing_ok=True)

    dest = config.COOKIES_FILE
    part = dest.with_name(dest.name + ".tmp")
    fd = os.open(part, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)  # never world-readable
    with os.fdopen(fd, "w") as f:
        f.write(info.text)
    os.replace(part, dest)

    summary = f"✅ Cookies installed: {info.total} cookies ({info.google} for YouTube/Google)."
    summary += (
        "\nLogged-in session detected."
        if info.logged_in else
        "\n⚠️ No login cookies found. This looks like a logged-out session, so YouTube may still ask you to sign in."
    )
    reply = await message.reply_text(summary)
    try:  # don't leave your session cookies sitting in the chat history
        await message.delete()
    except Exception:
        if reply:
            await reply.edit_text(summary + "\n⚠️ I couldn't delete your upload. Please delete it yourself.")


async def cmd_cancel(client, message):
    words = (message.text or "").lower().split()[1:]
    dropped = 0
    if "all" in words:
        while not queue.empty():
            job = queue.get_nowait()
            queue.task_done()
            dropped += 1
            await _edit(job.msg, "❌ Cancelled")
    task = state["task"]
    running = bool(task and not task.done())
    if running:
        task.cancel()
    if not running and not dropped:
        await message.reply_text("Nothing to cancel.")
    elif dropped:
        await message.reply_text(f"Cancelled{' the running job and' if running else ''} {dropped} queued job(s).")


async def cmd_status(client, message):
    job = state["job"]
    active = f"{job.kind}: {job.url[:60]}" if job else "idle"
    await message.reply_text(
        f"📊 Active: {active}\n"
        f"Queued: {queue.qsize()}\n"
        f"Video-site links: {prefs.get_mode()}\n"
        f"💾 Disk free: {human_size(free_space(config.DOWNLOAD_DIR))}\n\n"
        f"{sysinfo.render(sysinfo.snapshot())}"
    )


def _fatal_for_playlist(msg: str) -> bool:
    """Errors that would just repeat for every remaining video: stop instead of failing 50 times."""
    return msg == procs.OOM_MESSAGE or "disk" in msg.lower() or "🍪" in msg


async def process_playlist(client: Client, job: Job, workdir: Path, prog: Progress) -> str:
    """Download and upload the videos one at a time (one item on disk at once), skipping any that fail."""
    info = job.playlist
    assert info is not None
    n = len(info.entries)
    sent, failed, stopped = 0, [], ""
    for i, (title, url) in enumerate(info.entries, 1):
        prog.begin_item(f"📃 {i}/{n}: {title[:60]}\n")
        item_dir = workdir / f"{i:03d}"
        item_dir.mkdir(parents=True, exist_ok=True)
        try:
            got = await ytdlp.download(url, item_dir, prog.download, on_wait=lambda t: prog.edit(prog.prefix + t),
                                       audio=job.audio)
            if got.path.stat().st_size > config.MAX_FILE_SIZE:
                await uploader.upload_split(client, job.chat_id, got.path, prog)
            else:
                await uploader.upload(client, job.chat_id, got.path, prog.upload, job.as_document)
            sent += 1
        except JobError as e:
            failed.append((title, str(e)))
            if _fatal_for_playlist(str(e)):
                stopped = f"\nStopped after video {i} of {n}, because the next ones would fail the same way."
                break
        finally:
            shutil.rmtree(item_dir, ignore_errors=True)  # free the disk before the next video
    prog.begin_item("")
    text = f"✅ Playlist done: {sent} of {n} sent ({info.title[:60]})" if sent else f"❌ Playlist failed: nothing was sent ({info.title[:60]})"
    if info.truncated:
        text += f"\nThe playlist has more videos; only the first {n} were taken (MAX_PLAYLIST_ITEMS)."
    if failed:
        text += f"\n\n{len(failed)} failed:\n" + "\n".join(f"- {t[:50]}: {e.splitlines()[0][:100]}" for t, e in failed[:5])
        if len(failed) > 5:
            text += f"\n…and {len(failed) - 5} more"
    return (text + stopped)[:4000]


async def process(client: Client, job: Job):
    workdir = config.DOWNLOAD_DIR / f"job_{job.id}"
    workdir.mkdir(parents=True, exist_ok=True)
    prog = Progress(job.msg)
    try:
        if job.playlist:
            await prog.edit(await process_playlist(client, job, workdir, prog))
            return
        note = ""
        if job.kind == "ytdl":
            got = await ytdlp.download(job.url, workdir, prog.download, on_wait=prog.edit, audio=job.audio)
            path = got.path
            if got.was_playlist:
                note = "\n(That link is a playlist: only its first video was downloaded.)"
        else:
            path = await direct.download(job.url, workdir, job.name, prog.download)

        if path.stat().st_size > config.MAX_FILE_SIZE:
            await uploader.upload_split(client, job.chat_id, path, prog)
        else:
            await uploader.upload(client, job.chat_id, path, prog.upload, job.as_document)
        await prog.edit(f"✅ Done: {path.name}{note}")
    except asyncio.CancelledError:
        await prog.edit("♻️ The bot is restarting. Send the link again." if shutting_down else "❌ Cancelled")
    except JobError as e:
        await prog.edit(f"❌ {e}")
    except MemoryError:
        await prog.edit(procs.OOM_MESSAGE)
    except Exception as e:
        log.exception("job %s failed", job.id)
        await prog.edit(f"❌ {type(e).__name__}: {str(e)[:300]}")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)  # always free the disk


def write_marker(job: Job) -> None:
    try:
        config.STATE_FILE.write_text(json.dumps({"kind": job.kind, "url": job.url, "t": time.time()}))
    except OSError:
        pass


def clear_marker() -> None:
    try:
        config.STATE_FILE.unlink(missing_ok=True)
    except OSError:
        pass


async def notify_interrupted(app: Client) -> None:
    """If the last run died mid-job (crash, OOM kill, reboot), say so instead of failing silently."""
    try:
        data = json.loads(config.STATE_FILE.read_text())
    except (OSError, ValueError):
        return
    clear_marker()
    text = (
        "♻️ I was restarted while working on:\n"
        f"{str(data.get('url', '?'))[:200]}\n"
        "If it didn't finish, send the link again. If this keeps happening, check /status for memory."
    )
    try:
        await app.send_message(config.OWNER_ID, text)
    except Exception:
        log.warning("couldn't notify the owner about the interrupted job")


async def worker(client: Client):
    while True:
        job = await queue.get()
        state["job"] = job
        write_marker(job)
        state["task"] = asyncio.create_task(process(client, job))
        try:
            await state["task"]
        except Exception:
            log.exception("worker error")
        finally:
            state["job"] = state["task"] = None
            clear_marker()
            queue.task_done()
            memory.trim()  # give freed heap back to the OS


def start_worker(client: Client) -> None:
    """Supervised: if the worker ever dies unexpectedly it is restarted, so the queue can't get stuck."""
    t = asyncio.create_task(worker(client))
    state["worker"] = t

    def on_done(task: asyncio.Task) -> None:
        if shutting_down or task.cancelled():
            return
        log.error("worker died, restarting", exc_info=task.exception())
        start_worker(client)

    t.add_done_callback(on_done)


def sweep_orphans():
    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    for p in config.DOWNLOAD_DIR.iterdir():
        shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True)


async def main():
    global shutting_down
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    sweep_orphans()
    slots = procs.init()
    log.info("heavy-process slots: %s, min free RAM: %s MB", slots, config.MIN_FREE_RAM_MB)

    # Created inside the running loop so it works on any Python 3.11+.
    app = Client(
        "leechbot",
        api_id=config.API_ID,
        api_hash=config.API_HASH,
        bot_token=config.BOT_TOKEN,
        workers=2,
        sleep_threshold=120,  # ride out Telegram flood waits up to 2 min instead of failing a finished download
        parse_mode=enums.ParseMode.DISABLED,  # titles/filenames contain _ * < > that would be mangled
        max_concurrent_transmissions=1,  # one upload/download stream at a time
        max_message_cache_size=50,       # default 1000 message objects kept in RAM
        max_topic_cache_size=20,         # default 1000
    )
    owner = filters.user(config.OWNER_ID) & filters.private
    for handler, cmds in (
        (cmd_start, ["start", "help"]),
        (cmd_leech, ["leech"]),
        (cmd_ytdl, ["ytdl"]),
        (cmd_cookies, ["cookies"]),
        (cmd_mode, ["mode"]),
        (cmd_cancel, ["cancel"]),
        (cmd_status, ["status"]),
    ):
        app.add_handler(MessageHandler(handler, owner & filters.command(cmds)))
    app.add_handler(MessageHandler(on_text, owner & filters.text & ~filters.command(["start", "help", "leech", "ytdl", "cookies", "cancel", "status", "mode"])))
    app.add_handler(CallbackQueryHandler(cb_mode, filters.regex(r"^mode:") & filters.user(config.OWNER_ID)))
    app.add_handler(CallbackQueryHandler(cb_pick, filters.regex(r"^pick:") & filters.user(config.OWNER_ID)))

    await app.start()
    await notify_interrupted(app)
    start_worker(app)
    log.info("Bot started")
    await idle()
    shutting_down = True
    state["worker"].cancel()
    await asyncio.sleep(0.5)  # let the running job report "restarting" and clean up
    await app.stop()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
