import asyncio
import logging
import secrets
import time
from dataclasses import dataclass
from pathlib import Path

from pyrogram import Client, enums, filters, idle
from pyrogram.handlers import CallbackQueryHandler, MessageHandler
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from . import config, cookies, detect, jobs, prefs, sysinfo
from .downloaders import ytdlp
from .progress import safe_edit
from .utils import JobError, atomic_write, free_space, human_size, human_time

log = logging.getLogger("leechbot")

HELP = (
    "Just send me a link, no command needed:\n"
    "- a direct file link: I download it and upload it here\n"
    "- a YouTube or other video-site link: I ask whether you want the video or just the audio, then download "
    f"the best quality available (video is capped at {config.YTDL_MAX_HEIGHT}p)\n"
    f"- a playlist link: I show how many videos it has and download them one by one (up to {config.MAX_PLAYLIST_ITEMS})\n\n"
    "Rename a direct download:  link | new_name.ext\n\n"
    "Commands:\n"
    "/mode  - ask every time (default), or always video, or always audio (/mode ask, /mode video, /mode audio)\n"
    "/leech <url>  - force a direct download\n"
    "/ytdl <url> [audio|video]  - force yt-dlp; audio or video skips the question for this link\n"
    "/cookies  - YouTube cookies (fixes the 'not a bot' error)\n"
    "/status  - queue, memory, disk\n"
    "/cancel  - cancel the running job  (/cancel all also clears the queue)\n\n"
    "Add 'doc' after a link in /leech or /ytdl to upload it as a file instead of a video."
)

_background: set[asyncio.Task] = set()


def bg(coro) -> None:
    """Run a coroutine in the background so message handlers return immediately."""
    t = asyncio.create_task(coro)
    _background.add(t)

    def done(task: asyncio.Task) -> None:
        _background.discard(task)
        if not task.cancelled() and task.exception():
            log.error("background task failed", exc_info=task.exception())

    t.add_done_callback(done)


def _callback_data(query: CallbackQuery) -> str:
    return query.data.decode() if isinstance(query.data, bytes) else query.data


def parse_args(message: Message):
    """`/cmd url [flags] [| new_name]` -> (url, {flags}, name) or None."""
    parts = (message.text or "").split(None, 1)
    if len(parts) < 2:
        return None
    left, _, right = parts[1].partition("|")
    tokens = left.split()
    if not tokens:
        return None
    return tokens[0], {t.lower() for t in tokens[1:]}, (right.strip() or None)


# ---------- links --------------------------------------------------------------------

@dataclass
class Pending:
    """A video-site link waiting for you to tap Video or Audio."""
    url: str
    chat_id: int
    msg: Message  # the status message that carries the buttons
    name: str | None
    as_document: bool
    created: float
    info: ytdlp.PlaylistInfo | None = None  # set when the link is a playlist
    audio: bool | None = None  # set when video/audio is already decided (flag or fixed /mode)


PENDING_TTL = 10 * 60  # seconds a Video/Audio question stays valid
PENDING_MAX = 50
pending: dict[str, Pending] = {}


def _prune_pending() -> None:
    now = time.time()
    for token in [t for t, p in pending.items() if now - p.created > PENDING_TTL]:
        del pending[token]
    while len(pending) > PENDING_MAX:  # dicts keep insertion order: drop the oldest
        del pending[next(iter(pending))]


def _rows(p: Pending) -> list[list[tuple[str, str]]]:
    """Button rows as (answer code, label). A code is <scope><kind>: scope s = this video, p = whole playlist;
    kind v = video, a = audio. The same codes are the only answers accepted back."""
    kinds = [(k, e) for k, e in (("v", "🎬"), ("a", "🎵")) if p.audio is None or (k == "a") == p.audio]
    if p.info is None:
        names = {"v": "Video", "a": "Audio"}
        return [[("s" + k, f"{e} {names[k]}") for k, e in kinds]]
    count = f"{len(p.info.entries)}{'+' if p.info.truncated else ''}"
    scopes = [("p", f"Playlist ({count})")] + ([("s", "Just this one")] if p.info.mixed else [])
    return [[(scope + k, f"{e} {text}") for k, e in kinds] for scope, text in scopes]


def _keyboard(token: str, p: Pending) -> InlineKeyboardMarkup:
    rows = _rows(p) + [[("x", "✖ Cancel")]]
    return InlineKeyboardMarkup([[InlineKeyboardButton(label, callback_data=f"pick:{token}:{code}")
                                  for code, label in row] for row in rows])


def _question_text(p: Pending) -> str:
    if p.info is None:
        return f"What do you want from this link?\n{p.url[:120]}"
    info, n = p.info, len(p.info.entries)
    more = f"of {info.total}" if info.total > n else "(there are more)"
    size = f"{n} videos" if not info.truncated else f"The first {n} {more} will be taken (limit: MAX_PLAYLIST_ITEMS)"
    text = f"📃 Playlist: {info.title[:80]}\n{size}\nThey are downloaded and uploaded one by one."
    if p.audio is None:
        text += "\n🎬 = video, 🎵 = audio only"
    if info.mixed:
        text += "\nThis link also points at a single video."
    return text


def _kind_label(want_audio: bool, info: ytdlp.PlaylistInfo | None) -> str:
    kind = "🎵 Best audio" if want_audio else f"🎬 Best video (up to {config.YTDL_MAX_HEIGHT}p)"
    if info:
        return f"📃 Playlist: {info.title[:60]} ({len(info.entries)} videos)\n{kind}\n"
    return kind + "\n"


async def _queue_ytdl(status: Message, url: str, chat_id: int, name: str | None, as_document: bool,
                      want_audio: bool, playlist: ytdlp.PlaylistInfo | None = None) -> None:
    await safe_edit(status, _kind_label(want_audio, playlist) + jobs.queue_text())
    jobs.submit("ytdl", url, chat_id, status, name=name, as_document=as_document, audio=want_audio,
                playlist=playlist)


async def handle_url(message: Message, url: str, name: str | None = None, force: str | None = None,
                     as_document: bool = False, audio: bool | None = None) -> None:
    if jobs.is_full():
        await message.reply_text(f"The queue is full ({config.MAX_QUEUE} waiting). Try again in a bit.")
        return
    status = await message.reply_text("🔎 Checking link…")
    try:
        verdict = detect.Verdict(force) if force else await detect.classify(url)
        if verdict.kind == "direct":
            head, label = verdict.head, ""
            if head and (head.filename or head.size):
                label = f"📎 {name or head.filename or 'file'}" + (f" ({human_size(head.size)})" if head.size else "") + "\n"
            await safe_edit(status, label + jobs.queue_text())
            jobs.submit("leech", url, message.chat.id, status, name=name, as_document=as_document)
            return

        # A video-site link. Is it a playlist? Plain video links skip this check, so they stay fast.
        info = await ytdlp.probe_playlist(url) if ytdlp.may_be_playlist(url) else None

        # Video or audio: an explicit flag wins, then a fixed /mode, else ask.
        mode = prefs.get_mode()
        known = audio if audio is not None else (mode == "audio" if mode != "ask" else None)
        if info is None and known is not None:
            await _queue_ytdl(status, url, message.chat.id, name, as_document, known)
            return
        _prune_pending()
        token = secrets.token_hex(4)
        item = pending[token] = Pending(url, message.chat.id, status, name, as_document, time.time(), info, known)
        await safe_edit(status, _question_text(item), reply_markup=_keyboard(token, item))
    except JobError as e:
        await safe_edit(status, f"❌ {e}")
    except Exception as e:  # never let one bad link kill the handler task silently
        log.exception("handle_url failed")
        await safe_edit(status, f"❌ {type(e).__name__}: {str(e)[:200]}")


async def cb_pick(client, query: CallbackQuery) -> None:
    _, token, choice = _callback_data(query).split(":", 2)
    item = pending.get(token)
    if item is None or time.time() - item.created > PENDING_TTL:
        pending.pop(token, None)
        await query.answer("This choice expired. Send the link again.", show_alert=True)
        if query.message.reply_markup:  # only a message still showing buttons; never a running job's status
            await safe_edit(query.message, "⌛ Expired. Send the link again.")
        return
    if choice == "x":
        del pending[token]
        await query.answer("Cancelled")
        await safe_edit(item.msg, "❌ Cancelled")
        return
    if choice not in {code for row in _rows(item) for code, _ in row}:
        await query.answer()
        return
    if jobs.is_full():  # keep the question so you can tap again in a moment
        await query.answer(f"The queue is full ({config.MAX_QUEUE} waiting). Try again in a bit.", show_alert=True)
        return
    del pending[token]  # first tap wins: a double tap can't queue the link twice
    scope, kind = choice
    await query.answer("Audio" if kind == "a" else "Video")
    await _queue_ytdl(item.msg, item.url, item.chat_id, item.name, item.as_document, kind == "a",
                      item.info if scope == "p" else None)


async def on_text(client, message: Message) -> None:
    urls = detect.extract_urls(message.text or "", message.entities)
    if not urls:
        await message.reply_text("Send me a link (a direct file or a video site), or /help.")
        return

    async def run() -> None:
        for url, name in urls:  # one at a time: classifying makes network requests
            await handle_url(message, url, name)

    bg(run())


# ---------- commands -----------------------------------------------------------------

async def cmd_start(client, message: Message) -> None:
    await message.reply_text(HELP)


async def _forced(message: Message, force: str) -> None:
    parsed = parse_args(message)
    if not parsed:
        await message.reply_text(HELP)
        return
    url, flags, name = parsed
    audio = True if "audio" in flags else False if "video" in flags else None  # per-link: skips the question and /mode
    bg(handle_url(message, url, name if force == "direct" else None, force=force,
                  as_document="doc" in flags, audio=audio))


async def cmd_leech(client, message: Message) -> None:
    await _forced(message, "direct")


async def cmd_ytdl(client, message: Message) -> None:
    await _forced(message, "ytdl")


def _mode_message() -> tuple[str, InlineKeyboardMarkup]:
    mode = prefs.get_mode()
    descriptions = {
        "ask": "❓ Ask: every video-site link gets Video / Audio buttons",
        "video": f"🎬 Video: always the best video up to {config.YTDL_MAX_HEIGHT}p plus the best audio (no question)",
        "audio": "🎵 Audio: always the best audio only, original quality, copied not converted (no question)",
    }
    labels = {"ask": "❓ Ask", "video": "🎬 Video", "audio": "🎵 Audio"}
    text = (f"What happens with video-site links:\n{descriptions[mode]}\n\n"
            "Direct file links are always downloaded exactly as they are.")
    buttons = [InlineKeyboardButton(f"Switch to {labels[m]}", callback_data=f"mode:{m}") for m in prefs.MODES if m != mode]
    return text, InlineKeyboardMarkup([buttons])


async def cmd_mode(client, message: Message) -> None:
    words = (message.text or "").lower().split()[1:]
    if words and words[0] not in prefs.MODES:
        await message.reply_text("Use /mode to see and switch, or /mode ask, /mode video, /mode audio.")
        return
    if words:
        prefs.set_mode(words[0])
    text, keyboard = _mode_message()
    await message.reply_text(text, reply_markup=keyboard)


async def cb_mode(client, query: CallbackQuery) -> None:
    wanted = _callback_data(query).partition(":")[2]
    if wanted in prefs.MODES:
        prefs.set_mode(wanted)
    text, keyboard = _mode_message()
    await safe_edit(query.message, text, reply_markup=keyboard)
    await query.answer(f"Mode: {prefs.get_mode()}")


COOKIE_HELP = (
    "To fix YouTube's bot check, send me a cookies.txt FILE with the caption /cookies "
    "(or reply to the file with /cookies).\n\n"
    "How to export it (YouTube rotates cookies on open tabs, so do it exactly like this):\n"
    "1. Open a private/incognito window and log in to YouTube (a throwaway account is safest).\n"
    "2. In that same tab, open https://www.youtube.com/robots.txt\n"
    "3. Export youtube.com cookies with the 'Get cookies.txt LOCALLY' (Chrome) or "
    "'cookies.txt' (Firefox) extension.\n"
    "4. Close the private window, then send me the file.\n\n"
    "/cookies clear  - delete the stored cookies"
)


async def cmd_cookies(client, message: Message) -> None:
    parts = (message.text or message.caption or "").split(None, 1)
    arg = parts[1].strip().lower() if len(parts) > 1 else ""

    if arg == "clear":
        config.COOKIES_FILE.unlink(missing_ok=True)
        await message.reply_text("🗑 Cookies removed.")
        return

    reply = message.reply_to_message
    src = message if message.document else reply if reply and reply.document else None
    if src is None:
        f = config.COOKIES_FILE
        status = (f"🍪 Cookies installed (last updated {human_time(time.time() - f.stat().st_mtime)} ago)."
                  if f.is_file() else "🍪 No cookies installed.")
        await message.reply_text(f"{status}\n\n{COOKIE_HELP}")
        return

    if jobs.active and jobs.active.kind == "ytdl":  # yt-dlp rewrites the file on exit and would clobber ours
        await message.reply_text("A yt-dlp job is running. Send the cookies again when it finishes.")
        return
    if src.document.file_size and src.document.file_size > cookies.MAX_BYTES:
        await message.reply_text("❌ That file is too big to be a cookies file (limit 1 MB).")
        return

    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    tmp = config.DOWNLOAD_DIR / f"cookies_upload_{secrets.token_hex(4)}"
    path = None
    try:
        path = await client.download_media(src, file_name=str(tmp))
        if not path:
            raise JobError("Couldn't download that file from Telegram.")
        info = cookies.parse(Path(path).read_bytes())
    except JobError as e:
        await message.reply_text(f"❌ {e}")
        return
    finally:
        tmp.unlink(missing_ok=True)
        if path:
            Path(path).unlink(missing_ok=True)

    atomic_write(config.COOKIES_FILE, info.text, 0o600)  # never world-readable
    summary = f"✅ Cookies installed: {info.total} cookies ({info.google} for YouTube/Google)."
    summary += (
        "\nLogged-in session detected." if info.logged_in else
        "\n⚠️ No login cookies found. This looks like a logged-out session, so YouTube may still ask you to sign in."
    )
    sent = await message.reply_text(summary)
    try:  # don't leave your session cookies sitting in the chat history
        await message.delete()
    except Exception:
        await safe_edit(sent, summary + "\n⚠️ I couldn't delete your upload. Please delete it yourself.")


async def cmd_cancel(client, message: Message) -> None:
    running, dropped = await jobs.cancel("all" in (message.text or "").lower().split()[1:])
    if not running and not dropped:
        await message.reply_text("Nothing to cancel.")
    elif dropped:
        await message.reply_text(f"Cancelled{' the running job and' if running else ''} {dropped} queued job(s).")


async def cmd_status(client, message: Message) -> None:
    job = jobs.active
    await message.reply_text(
        f"📊 Active: {f'{job.kind}: {job.url[:60]}' if job else 'idle'}\n"
        f"Queued: {jobs.queue.qsize()}\n"
        f"Video-site links: {prefs.get_mode()}\n"
        f"💾 Disk free: {human_size(free_space(config.DOWNLOAD_DIR))}\n\n"
        f"{sysinfo.render()}"
    )


# ---------- startup ------------------------------------------------------------------

COMMANDS = (
    (["start", "help"], cmd_start),
    (["leech"], cmd_leech),
    (["ytdl"], cmd_ytdl),
    (["cookies"], cmd_cookies),
    (["mode"], cmd_mode),
    (["cancel"], cmd_cancel),
    (["status"], cmd_status),
)


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("pyrogram").setLevel(logging.WARNING)  # its INFO chatter is just journal noise
    jobs.sweep_orphans()

    app = Client(
        "leechbot",
        api_id=config.API_ID,
        api_hash=config.API_HASH,
        bot_token=config.BOT_TOKEN,
        workers=2,
        sleep_threshold=120,  # ride out Telegram flood waits up to 2 min instead of failing a finished download
        parse_mode=enums.ParseMode.DISABLED,  # titles/filenames contain _ * < > that would be mangled
        max_concurrent_transmissions=1,  # one upload/download stream at a time
        max_message_cache_size=50,       # default 1000 message objects kept in RAM
        max_topic_cache_size=20,         # default 1000
    )
    owner = filters.user(config.OWNER_ID) & filters.private
    for names, handler in COMMANDS:
        app.add_handler(MessageHandler(handler, owner & filters.command(names)))
    all_commands = [name for names, _ in COMMANDS for name in names]
    app.add_handler(MessageHandler(on_text, owner & filters.text & ~filters.command(all_commands)))
    app.add_handler(CallbackQueryHandler(cb_mode, filters.regex(r"^mode:") & filters.user(config.OWNER_ID)))
    app.add_handler(CallbackQueryHandler(cb_pick, filters.regex(r"^pick:") & filters.user(config.OWNER_ID)))

    await app.start()
    await jobs.notify_interrupted(app)
    jobs.start(app)
    log.info("Bot started")
    await idle()
    await jobs.stop()
    await app.stop()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
