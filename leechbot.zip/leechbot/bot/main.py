import asyncio
import contextlib
import json
import logging
import re
import secrets
import signal
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path

from telethon import Button, TelegramClient, events

from . import config, jobs, net, system, ytdlp
from .utils import JobError, atomic_write, free_space, human_size, human_time, safe_edit

log = logging.getLogger("leechbot")

HELP = (
    "Just send me a link, no command needed:\n"
    "- a direct file link: I download it and upload it here\n"
    "- a YouTube or other video-site link: I ask whether you want the video or just the audio, then download "
    f"the best quality available (video is capped at {config.YTDL_MAX_HEIGHT}p). Videos arrive as H.264/AAC .mp4 and "
    "audio as 320 kbps MP3 made from the best stream, so both play in Telegram's own player\n"
    f"- a playlist link: I show how many videos it has and download them one by one (up to {config.MAX_PLAYLIST_ITEMS})\n\n"
    "Rename a direct download:  link | new_name.ext\n\n"
    "Commands:\n"
    "/mode  - ask every time (default), or always video, or always audio (/mode ask, /mode video, /mode audio)\n"
    "/leech <url>  - force a direct download\n"
    "/ytdl <url> [audio|video]  - force yt-dlp; audio or video skips the question for this link\n"
    "/cookies  - YouTube cookies (fixes the 'not a bot' error)\n"
    "/status  - queue, memory, disk\n"
    "/cancel  - cancel the running job  (/cancel all also clears the queue)\n\n"
    "Add 'doc' after a link in /leech or /ytdl to upload the untouched download as a file (no conversion)."
)

_background: set[asyncio.Task] = set()


def bg(coro) -> None:
    """Run a coroutine in the background so message handlers return immediately."""
    t = asyncio.create_task(coro)
    _background.add(t)

    def done(task: asyncio.Task) -> None:
        _background.discard(task)
        if not task.cancelled() and task.exception():
            log.error("background task failed", exc_info=task.exception())

    t.add_done_callback(done)


# ---------- preferences ---------------------------------------------------------------

MODES = ("ask", "video", "audio")  # what video-site links do: ask with buttons, or always video / always audio
MODE_TEXT = {
    "ask": "❓ Ask: every video-site link gets Video / Audio buttons",
    "video": f"🎬 Video: always the best video up to {config.YTDL_MAX_HEIGHT}p plus the best audio (no question)",
    "audio": "🎵 Audio: always MP3 (320 kbps, from the best source stream), no question",
}


MODE_LABEL = {"ask": "❓ Ask", "video": "🎬 Video", "audio": "🎵 Audio"}


def get_mode() -> str:
    try:
        mode = json.loads(config.PREFS_FILE.read_text()).get("mode")
    except (OSError, ValueError, AttributeError):
        return MODES[0]
    return mode if mode in MODES else MODES[0]


def _mode_message() -> tuple[str, list[list[Button]]]:
    mode = get_mode()
    text = f"What happens with video-site links:\n{MODE_TEXT[mode]}\n\nDirect file links are always downloaded exactly as they are."
    return text, [[Button.inline(f"Switch to {MODE_LABEL[m]}", data=f"mode:{m}") for m in MODES if m != mode]]


# ---------- cookies -------------------------------------------------------------------

COOKIES_MAX_BYTES = 1_000_000
# Cookies that only exist when logged in to a Google/YouTube account.
_LOGIN_COOKIES = {"SID", "__Secure-1PSID", "__Secure-3PSID", "SAPISID", "LOGIN_INFO"}


def parse_cookies(raw: bytes) -> tuple[str, int, int, bool]:
    """Validate an uploaded Netscape-format cookies.txt. Returns (normalised text, cookies, google cookies, logged in)."""
    if len(raw) > COOKIES_MAX_BYTES:
        raise JobError("That file is too big to be a cookies file (limit 1 MB).")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise JobError("That isn't a text file. I need a cookies.txt export.") from None
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")  # CRLF makes yt-dlp fail with HTTP 400
    while lines and not lines[0].strip():
        lines.pop(0)
    if not lines or not re.match(r"^#( Netscape)? HTTP Cookie File", lines[0]):
        raise JobError("This isn't a Netscape-format cookies file: the first line must be '# Netscape HTTP Cookie File'. "
                       "Use the 'Get cookies.txt LOCALLY' (Chrome) or 'cookies.txt' (Firefox) extension.")
    total = google = 0
    logged_in = False
    for n, line in enumerate(lines[1:], start=2):
        if not line.strip() or (line.startswith("#") and not line.startswith("#HttpOnly_")):
            continue
        parts = line.split("\t")
        if len(parts) != 7:
            raise JobError(f"Line {n} is malformed (expected 7 tab-separated fields, got {len(parts)}). "
                           "Re-export the file; don't edit it in a program that converts tabs to spaces.")
        total += 1
        if parts[0].removeprefix("#HttpOnly_").lstrip(".").lower().endswith(("youtube.com", "google.com")):
            google += 1
            logged_in = logged_in or parts[5] in _LOGIN_COOKIES
    if not total:
        raise JobError("The file has the right header but contains no cookies.")
    return "\n".join(lines).rstrip("\n") + "\n", total, google, logged_in


COOKIE_HELP = (
    "To fix YouTube's bot check, send me a cookies.txt FILE with the caption /cookies "
    "(or reply to the file with /cookies).\n\n"
    "How to export it (YouTube rotates cookies on open tabs, so do it exactly like this):\n"
    "1. Open a private/incognito window and log in to YouTube (a throwaway account is safest).\n"
    "2. In that same tab, open https://www.youtube.com/robots.txt\n"
    "3. Export youtube.com cookies with the 'Get cookies.txt LOCALLY' (Chrome) or "
    "'cookies.txt' (Firefox) extension.\n"
    "4. Close the private window, then send me the file.\n\n"
    "/cookies clear  - delete the stored cookies"
)


async def cmd_cookies(m) -> None:
    arg = m.raw_text.partition(" ")[2].strip().lower()
    if arg == "clear":
        config.COOKIES_FILE.unlink(missing_ok=True)
        return await m.respond("🗑 Cookies removed.")
    reply = await m.get_reply_message() if m.is_reply else None
    src = m.message if m.document else reply if reply and reply.document else None
    if src is None:
        f = config.COOKIES_FILE
        status = (f"🍪 Cookies installed (last updated {human_time(time.time() - f.stat().st_mtime)} ago)."
                  if f.is_file() else "🍪 No cookies installed.")
        return await m.respond(f"{status}\n\n{COOKIE_HELP}")
    if jobs.active and jobs.active.kind == "ytdl":  # yt-dlp rewrites the file on exit and would clobber ours
        return await m.respond("A yt-dlp job is running. Send the cookies again when it finishes.")
    if src.document.size > COOKIES_MAX_BYTES:
        return await m.respond("❌ That file is too big to be a cookies file (limit 1 MB).")

    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    tmp, path = config.DOWNLOAD_DIR / f"cookies_upload_{secrets.token_hex(4)}", None
    try:
        path = await src.download_media(file=str(tmp))
        if not path:
            raise JobError("Couldn't download that file from Telegram.")
        text, total, google, logged_in = parse_cookies(Path(path).read_bytes())
    except JobError as e:
        return await m.respond(f"❌ {e}")
    finally:
        tmp.unlink(missing_ok=True)
        if path:
            Path(path).unlink(missing_ok=True)
    atomic_write(config.COOKIES_FILE, text, 0o600)  # never world-readable
    summary = (f"✅ Cookies installed: {total} cookies ({google} for YouTube/Google).\n"
               + ("Logged-in session detected." if logged_in else "⚠️ No login cookies found. This looks like a "
                  "logged-out session, so YouTube may still ask you to sign in."))
    sent = await m.respond(summary)
    try:  # don't leave your session cookies sitting in the chat history
        await m.delete()
    except Exception:
        await safe_edit(sent, summary + "\n⚠️ I couldn't delete your upload. Please delete it yourself.")
    if src is reply:  # the file was sent earlier and only replied to
        with contextlib.suppress(Exception):
            await reply.delete()


# ---------- links ---------------------------------------------------------------------

@dataclass
class Pending:
    """A video-site link waiting for you to tap Video or Audio."""
    url: str
    msg: object  # the status message that carries the buttons
    name: str | None
    as_document: bool
    created: float
    info: ytdlp.PlaylistInfo | None = None  # set when the link is a playlist
    audio: bool | None = None  # set when video/audio is already decided (flag or fixed /mode)


PENDING_TTL = 10 * 60  # seconds a Video/Audio question stays valid
pending: dict[str, Pending] = {}


def _rows(p: Pending) -> list[list[tuple[str, str]]]:
    """Button rows as (answer code, label). Code = <scope><kind>: scope s = this video, p = whole playlist; kind v =
    video, a = audio. These codes are the only answers accepted back."""
    kinds = [k for k in "va" if p.audio is None or (k == "a") == p.audio]
    emoji = {"v": "🎬", "a": "🎵"}
    if p.info is None:
        return [[("s" + k, f"{emoji[k]} {'Video' if k == 'v' else 'Audio'}") for k in kinds]]
    count = f"{len(p.info.entries)}{'+' if p.info.truncated else ''}"
    scopes = [("p", f"Playlist ({count})")] + ([("s", "Just this one")] if p.info.mixed else [])
    return [[(scope + k, f"{emoji[k]} {text}") for k in kinds] for scope, text in scopes]


def _question_text(p: Pending) -> str:
    if p.info is None:
        return f"What do you want from this link?\n{p.url[:120]}"
    info, n = p.info, len(p.info.entries)
    more = f"of {info.total}" if info.total > n else "(there are more)"
    size = f"{n} videos" if not info.truncated else f"The first {n} {more} will be taken (limit: MAX_PLAYLIST_ITEMS)"
    return (f"📃 Playlist: {info.title[:80]}\n{size}\nThey are downloaded and uploaded one by one."
            + ("\n🎬 = video, 🎵 = audio only" if p.audio is None else "")
            + ("\nThis link also points at a single video." if info.mixed else ""))


async def _queue_ytdl(status, url: str, chat_id: int, name, as_document: bool, audio: bool, playlist=None) -> None:
    kind = "🎵 Best audio (MP3)" if audio else f"🎬 Best video (up to {config.YTDL_MAX_HEIGHT}p)"
    head = f"📃 Playlist: {playlist.title[:60]} ({len(playlist.entries)} videos)\n{kind}\n" if playlist else kind + "\n"
    await safe_edit(status, head + jobs.queue_text())
    jobs.submit("ytdl", url, chat_id, status, name=name, as_document=as_document, audio=audio, playlist=playlist)


def _queue_full_text() -> str:
    return f"The queue is full ({config.MAX_QUEUE} waiting). Try again in a bit."


async def handle_url(m, url: str, name: str | None = None, force: str | None = None,
                     as_document: bool = False, audio: bool | None = None) -> None:
    if jobs.is_full():
        return await m.respond(_queue_full_text())
    status = await m.respond("🔎 Checking link…")
    try:
        kind, head = (force, None) if force else await net.classify(url)
        if kind == "direct":
            label = ""
            if head and (head.filename or head.size):
                label = f"📎 {name or head.filename or 'file'}" + (f" ({human_size(head.size)})" if head.size else "") + "\n"
            await safe_edit(status, label + jobs.queue_text())
            return jobs.submit("leech", url, m.chat_id, status, name=name, as_document=as_document)

        # A video-site link. Is it a playlist? Plain video links skip this check, so they stay fast.
        info = await ytdlp.probe_playlist(url) if ytdlp.may_be_playlist(url) else None
        # Video or audio: an explicit flag wins, then a fixed /mode, else ask.
        mode = get_mode()
        known = audio if audio is not None else (mode == "audio" if mode != "ask" else None)
        if info is None and known is not None:
            return await _queue_ytdl(status, url, m.chat_id, name, as_document, known)
        now = time.time()
        for token in [t for t, p in pending.items() if now - p.created > PENDING_TTL]:
            del pending[token]
        while len(pending) >= 20:  # dicts keep insertion order: drop the oldest
            del pending[next(iter(pending))]
        token = secrets.token_hex(4)
        item = pending[token] = Pending(url, status, name, as_document, now, info, known)
        keys = [[Button.inline(label, data=f"pick:{token}:{code}") for code, label in row]
                for row in _rows(item) + [[("x", "✖ Cancel")]]]
        await safe_edit(status, _question_text(item), buttons=keys)
    except JobError as e:
        await safe_edit(status, f"❌ {e}")
    except Exception as e:  # never let one bad link kill the handler task silently
        log.exception("handle_url failed")
        await safe_edit(status, f"❌ {type(e).__name__}: {str(e)[:200]}")


async def cb_pick(q) -> None:
    _, token, choice = q.data.decode().split(":", 2)
    item = pending.get(token)
    if item is None or time.time() - item.created > PENDING_TTL:
        pending.pop(token, None)
        await q.answer("This choice expired. Send the link again.", alert=True)
        return await safe_edit(q, "⌛ Expired. Send the link again.")
    if choice == "x":
        del pending[token]
        await q.answer("Cancelled")
        return await safe_edit(item.msg, "❌ Cancelled")
    if choice not in {code for row in _rows(item) for code, _ in row}:
        return await q.answer()
    if jobs.is_full():  # keep the question so you can tap again in a moment
        return await q.answer(_queue_full_text(), alert=True)
    del pending[token]  # first tap wins: a double tap can't queue the link twice
    scope, kind = choice
    await q.answer("Audio" if kind == "a" else "Video")
    await _queue_ytdl(item.msg, item.url, q.chat_id, item.name, item.as_document, kind == "a",
                      item.info if scope == "p" else None)


# ---------- commands ------------------------------------------------------------------

async def cmd_text(m) -> None:
    """A message with links, or nothing usable: queue each link, one at a time (classifying makes network requests)."""
    urls = net.extract_urls(m.raw_text, m.message.entities)
    if not urls:
        return await m.respond("Send me a link (a direct file or a video site), or /help.")

    async def run() -> None:
        for url, name in urls:
            await handle_url(m, url, name)

    bg(run())


async def _forced(m, force: str) -> None:
    """`/leech|/ytdl url [flags] [| new_name]`"""
    left, _, right = m.raw_text.partition(" ")[2].partition("|")
    tokens = left.split()
    if not tokens:
        return await m.respond(HELP)
    flags = {t.lower() for t in tokens[1:]}
    audio = True if "audio" in flags else False if "video" in flags else None  # per-link: skips the question and /mode
    name = right.strip() or None
    bg(handle_url(m, tokens[0], name if force == "direct" else None, force=force, as_document="doc" in flags, audio=audio))


async def cmd_mode(m) -> None:
    words = m.raw_text.lower().split()[1:]
    if words and words[0] not in MODES:
        return await m.respond("Use /mode to see and switch, or /mode ask, /mode video, /mode audio.")
    if words:
        atomic_write(config.PREFS_FILE, json.dumps({"mode": words[0]}))
    text, keyboard = _mode_message()
    await m.respond(text, buttons=keyboard)


async def cb_mode(q) -> None:
    wanted = q.data.decode().partition(":")[2]
    if wanted in MODES:
        atomic_write(config.PREFS_FILE, json.dumps({"mode": wanted}))
    text, keyboard = _mode_message()
    await safe_edit(q, text, buttons=keyboard)
    await q.answer(f"Mode: {get_mode()}")


async def cmd_cancel(m) -> None:
    running, dropped = await jobs.cancel("all" in m.raw_text.lower().split()[1:])
    what = [*(["the running job"] if running else []), *([f"{dropped} queued job(s)"] if dropped else [])]
    await m.respond(f"Cancelled {' and '.join(what)}." if what else "Nothing to cancel.")


async def cmd_status(m) -> None:
    job = jobs.active
    await m.respond(
        f"📊 Active: {f'{job.kind}: {job.url[:60]}' if job else 'idle'}\n"
        f"Queued: {jobs.queue.qsize()}\n"
        f"Video-site links: {get_mode()}\n"
        f"💾 Disk free: {human_size(free_space(config.DOWNLOAD_DIR))}\n"
        + ("⚠️ DOWNLOAD_DIR is RAM-backed (tmpfs): downloads eat memory. Point it at a disk path.\n"
           if system.ram_backed(config.DOWNLOAD_DIR) else "")
        + f"\n{system.render()}")


# ---------- startup -------------------------------------------------------------------

COMMANDS = {
    "start": lambda m: m.respond(HELP), "help": lambda m: m.respond(HELP), "cookies": cmd_cookies,
    "leech": lambda m: _forced(m, "direct"), "ytdl": lambda m: _forced(m, "ytdl"),
    "mode": cmd_mode, "cancel": cmd_cancel, "status": cmd_status,
}
_COMMAND = re.compile(r"/(\w+)(?:@\w+)?(?:\s|$)")


async def on_message(event) -> None:
    """Route one message from the owner (/command, or text with links), then delete it. Telethon puts a file's
    caption in raw_text."""
    try:
        m = _COMMAND.match(event.raw_text)
        handler = COMMANDS.get(m.group(1).lower()) if m else None
        if handler:
            await handler(event)
        elif event.raw_text and not (event.document or event.photo):
            await cmd_text(event)
    finally:  # keep the chat clean: whatever the owner sent is removed once it has been handled
        with contextlib.suppress(Exception):
            await event.delete()


async def on_callback(event) -> None:
    data = event.data.decode()
    if data.startswith("pick:"):
        await cb_pick(event)
    elif data.startswith("mode:"):
        await cb_mode(event)


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("telethon").setLevel(logging.WARNING)  # its INFO chatter is just journal noise
    loop = asyncio.get_running_loop()
    loop.set_default_executor(ThreadPoolExecutor(4))  # the default pool may grow to 32 threads; we never need them
    jobs.sweep_orphans()
    if system.ram_backed(config.DOWNLOAD_DIR):
        log.warning("DOWNLOAD_DIR %s is on tmpfs (RAM): every download will use memory. Set DOWNLOAD_DIR to a disk path.",
                    config.DOWNLOAD_DIR)
    client = TelegramClient(str(config.SESSION), config.API_ID, config.API_HASH,
                            flood_sleep_threshold=120)  # ride out flood waits up to 2 min instead of failing a finished download
    client.parse_mode = None  # titles/filenames contain _ * < > that would be mangled
    client.add_event_handler(on_message, events.NewMessage(incoming=True, from_users=config.OWNER_ID, func=lambda e: e.is_private))
    client.add_event_handler(on_callback, events.CallbackQuery(func=lambda e: e.sender_id == config.OWNER_ID))
    await client.start(bot_token=config.BOT_TOKEN)
    await jobs.notify_interrupted(client)
    jobs.start(client)
    log.info("Bot started")
    stop = asyncio.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)
    await stop.wait()
    await jobs.stop()
    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
