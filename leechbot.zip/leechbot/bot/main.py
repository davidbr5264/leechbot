import asyncio
import contextlib
import json
import logging
import re
import secrets
import signal
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path

from telethon import Button, TelegramClient, events

from . import config, jobs, net, system, ytdlp
from .jobs import safe_edit
from .utils import JobError, atomic_write, free_space, human_size, human_time

log = logging.getLogger("leechbot")

Message = events.NewMessage.Event  # handlers receive the event; it has reply(), raw_text, delete()...
CallbackQuery = events.CallbackQuery.Event

HELP = (
    "Just send me a link, no command needed:\n"
    "- a direct file link: I download it and upload it here\n"
    "- a YouTube or other video-site link: I ask whether you want the video or just the audio, then download "
    f"the best quality available (video is capped at {config.YTDL_MAX_HEIGHT}p). Videos arrive as H.264/AAC .mp4 and "
    "audio as a 320 kbps MP3 (from the highest-bitrate stream) with cover art, so both play in Telegram's own player\n"
    f"- a playlist link: I show how many videos it has and download them one by one (up to {config.MAX_PLAYLIST_ITEMS})\n\n"
    "Rename a direct download:  link | new_name.ext\n\n"
    "Commands:\n"
    "/mode  - ask every time (default), or always video, or always audio (/mode ask, /mode video, /mode audio)\n"
    "/leech <url>  - force a direct download\n"
    "/ytdl <url> [audio|video]  - force yt-dlp; audio or video skips the question for this link\n"
    "/cookies  - YouTube cookies (fixes the 'not a bot' error)\n"
    "/status  - queue, memory, disk\n"
    "/cancel  - cancel the running job  (/cancel all also clears the queue)\n\n"
    "Add 'doc' after a link in /leech or /ytdl to upload the download as a file (no video conversion; audio is still MP3)."
)

_background: set[asyncio.Task] = set()


def bg(coro) -> None:
    """Run a coroutine in the background so message handlers return immediately."""
    t = asyncio.create_task(coro)
    _background.add(t)

    def done(task: asyncio.Task) -> None:
        _background.discard(task)
        if not task.cancelled() and task.exception():
            log.error("background task failed", exc_info=task.exception())

    t.add_done_callback(done)


def parse_args(message: Message):
    """`/cmd url [flags] [| new_name]` -> (url, {flags}, name) or None."""
    parts = message.raw_text.split(None, 1)
    if len(parts) < 2:
        return None
    left, _, right = parts[1].partition("|")
    tokens = left.split()
    if not tokens:
        return None
    return tokens[0], {t.lower() for t in tokens[1:]}, (right.strip() or None)


# ---------- preferences and cookie files ---------------------------------------------

MODES = ("ask", "video", "audio")  # what video-site links do: ask with buttons, or always video / always audio


def get_mode() -> str:
    try:
        mode = json.loads(config.PREFS_FILE.read_text()).get("mode")
    except (OSError, ValueError, AttributeError):
        return MODES[0]
    return mode if mode in MODES else MODES[0]


def set_mode(mode: str) -> None:
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}")
    atomic_write(config.PREFS_FILE, json.dumps({"mode": mode}))


COOKIES_MAX_BYTES = 1_000_000
_COOKIE_HEADER = re.compile(r"^#( Netscape)? HTTP Cookie File")
# Cookies that only exist when logged in to a Google/YouTube account.
_LOGIN_COOKIES = {"SID", "__Secure-1PSID", "__Secure-3PSID", "SAPISID", "LOGIN_INFO"}


@dataclass
class CookieInfo:
    text: str  # normalised (LF newlines, starts at the header line)
    total: int
    google: int  # cookies for youtube.com / google.com
    logged_in: bool


def parse_cookies(raw: bytes) -> CookieInfo:
    """Validate an uploaded Netscape-format cookies.txt (used by yt-dlp)."""
    if len(raw) > COOKIES_MAX_BYTES:
        raise JobError("That file is too big to be a cookies file (limit 1 MB).")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise JobError("That isn't a text file. I need a cookies.txt export.") from None

    # Windows (CRLF) newlines make yt-dlp fail with HTTP 400, so normalise to LF.
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    while lines and not lines[0].strip():
        lines.pop(0)
    if not lines or not _COOKIE_HEADER.match(lines[0]):
        raise JobError(
            "This isn't a Netscape-format cookies file: the first line must be "
            "'# Netscape HTTP Cookie File'. Use the 'Get cookies.txt LOCALLY' "
            "(Chrome) or 'cookies.txt' (Firefox) extension."
        )

    total = google = 0
    logged_in = False
    for n, line in enumerate(lines[1:], start=2):
        if not line.strip() or (line.startswith("#") and not line.startswith("#HttpOnly_")):
            continue  # blank or comment
        parts = line.split("\t")
        if len(parts) != 7:
            raise JobError(
                f"Line {n} is malformed (expected 7 tab-separated fields, got {len(parts)}). "
                "Re-export the file; don't edit it in a program that converts tabs to spaces."
            )
        domain = parts[0].removeprefix("#HttpOnly_").lstrip(".").lower()
        total += 1
        if domain.endswith(("youtube.com", "google.com")):
            google += 1
            logged_in = logged_in or parts[5] in _LOGIN_COOKIES

    if total == 0:
        raise JobError("The file has the right header but contains no cookies.")
    return CookieInfo("\n".join(lines).rstrip("\n") + "\n", total, google, logged_in)


# ---------- links --------------------------------------------------------------------

@dataclass
class Pending:
    """A video-site link waiting for you to tap Video or Audio."""
    url: str
    chat_id: int
    msg: Message  # the status message that carries the buttons
    name: str | None
    as_document: bool
    created: float
    info: ytdlp.PlaylistInfo | None = None  # set when the link is a playlist
    audio: bool | None = None  # set when video/audio is already decided (flag or fixed /mode)


PENDING_TTL = 10 * 60  # seconds a Video/Audio question stays valid
PENDING_MAX = 20
pending: dict[str, Pending] = {}


def _prune_pending() -> None:
    now = time.time()
    for token in [t for t, p in pending.items() if now - p.created > PENDING_TTL]:
        del pending[token]
    while len(pending) > PENDING_MAX:  # dicts keep insertion order: drop the oldest
        del pending[next(iter(pending))]


def _rows(p: Pending) -> list[list[tuple[str, str]]]:
    """Button rows as (answer code, label). A code is <scope><kind>: scope s = this video, p = whole playlist;
    kind v = video, a = audio. The same codes are the only answers accepted back."""
    kinds = [(k, e) for k, e in (("v", "🎬"), ("a", "🎵")) if p.audio is None or (k == "a") == p.audio]
    if p.info is None:
        names = {"v": "Video", "a": "Audio"}
        return [[("s" + k, f"{e} {names[k]}") for k, e in kinds]]
    count = f"{len(p.info.entries)}{'+' if p.info.truncated else ''}"
    scopes = [("p", f"Playlist ({count})")] + ([("s", "Just this one")] if p.info.mixed else [])
    return [[(scope + k, f"{e} {text}") for k, e in kinds] for scope, text in scopes]


def _keyboard(token: str, p: Pending) -> list[list[Button]]:
    rows = _rows(p) + [[("x", "✖ Cancel")]]
    return [[Button.inline(label, data=f"pick:{token}:{code}") for code, label in row] for row in rows]


def _question_text(p: Pending) -> str:
    if p.info is None:
        return f"What do you want from this link?\n{p.url[:120]}"
    info, n = p.info, len(p.info.entries)
    more = f"of {info.total}" if info.total > n else "(there are more)"
    size = f"{n} videos" if not info.truncated else f"The first {n} {more} will be taken (limit: MAX_PLAYLIST_ITEMS)"
    text = f"📃 Playlist: {info.title[:80]}\n{size}\nThey are downloaded and uploaded one by one."
    if p.audio is None:
        text += "\n🎬 = video, 🎵 = audio only"
    if info.mixed:
        text += "\nThis link also points at a single video."
    return text


def _kind_label(want_audio: bool, info: ytdlp.PlaylistInfo | None) -> str:
    kind = "🎵 Best audio" if want_audio else f"🎬 Best video (up to {config.YTDL_MAX_HEIGHT}p)"
    if info:
        return f"📃 Playlist: {info.title[:60]} ({len(info.entries)} videos)\n{kind}\n"
    return kind + "\n"


async def _queue_ytdl(status: Message, url: str, chat_id: int, name: str | None, as_document: bool,
                      want_audio: bool, playlist: ytdlp.PlaylistInfo | None = None) -> None:
    await safe_edit(status, _kind_label(want_audio, playlist) + jobs.queue_text())
    jobs.submit("ytdl", url, chat_id, status, name=name, as_document=as_document, audio=want_audio,
                playlist=playlist)


async def handle_url(message: Message, url: str, name: str | None = None, force: str | None = None,
                     as_document: bool = False, audio: bool | None = None) -> None:
    if jobs.is_full():
        await message.respond(f"The queue is full ({config.MAX_QUEUE} waiting). Try again in a bit.")
        return
    status = await message.respond("🔎 Checking link…")
    try:
        verdict = net.Verdict(force) if force else await net.classify(url)
        if verdict.kind == "direct":
            head, label = verdict.head, ""
            if head and (head.filename or head.size):
                label = f"📎 {name or head.filename or 'file'}" + (f" ({human_size(head.size)})" if head.size else "") + "\n"
            await safe_edit(status, label + jobs.queue_text())
            jobs.submit("leech", url, message.chat_id, status, name=name, as_document=as_document)
            return

        # A video-site link. Is it a playlist? Plain video links skip this check, so they stay fast.
        info = await ytdlp.probe_playlist(url) if ytdlp.may_be_playlist(url) else None

        # Video or audio: an explicit flag wins, then a fixed /mode, else ask.
        mode = get_mode()
        known = audio if audio is not None else (mode == "audio" if mode != "ask" else None)
        if info is None and known is not None:
            await _queue_ytdl(status, url, message.chat_id, name, as_document, known)
            return
        _prune_pending()
        token = secrets.token_hex(4)
        item = pending[token] = Pending(url, message.chat_id, status, name, as_document, time.time(), info, known)
        await safe_edit(status, _question_text(item), buttons=_keyboard(token, item))
    except JobError as e:
        await safe_edit(status, f"❌ {e}")
    except Exception as e:  # never let one bad link kill the handler task silently
        log.exception("handle_url failed")
        await safe_edit(status, f"❌ {type(e).__name__}: {str(e)[:200]}")


async def cb_pick(query: CallbackQuery) -> None:
    _, token, choice = query.data.decode().split(":", 2)
    item = pending.get(token)
    if item is None or time.time() - item.created > PENDING_TTL:
        pending.pop(token, None)
        await query.answer("This choice expired. Send the link again.", alert=True)
        await safe_edit(query, "⌛ Expired. Send the link again.")  # only messages still showing buttons get tapped
        return
    if choice == "x":
        del pending[token]
        await query.answer("Cancelled")
        await safe_edit(item.msg, "❌ Cancelled")
        return
    if choice not in {code for row in _rows(item) for code, _ in row}:
        await query.answer()
        return
    if jobs.is_full():  # keep the question so you can tap again in a moment
        await query.answer(f"The queue is full ({config.MAX_QUEUE} waiting). Try again in a bit.", alert=True)
        return
    del pending[token]  # first tap wins: a double tap can't queue the link twice
    scope, kind = choice
    await query.answer("Audio" if kind == "a" else "Video")
    await _queue_ytdl(item.msg, item.url, item.chat_id, item.name, item.as_document, kind == "a",
                      item.info if scope == "p" else None)


async def on_text(message: Message) -> None:
    urls = net.extract_urls(message.raw_text, message.message.entities)
    if not urls:
        await message.respond("Send me a link (a direct file or a video site), or /help.")
        return

    async def run() -> None:
        for url, name in urls:  # one at a time: classifying makes network requests
            await handle_url(message, url, name)

    bg(run())


# ---------- commands -----------------------------------------------------------------

async def cmd_start(message: Message) -> None:
    await message.respond(HELP)


async def _forced(message: Message, force: str) -> None:
    parsed = parse_args(message)
    if not parsed:
        await message.respond(HELP)
        return
    url, flags, name = parsed
    audio = True if "audio" in flags else False if "video" in flags else None  # per-link: skips the question and /mode
    bg(handle_url(message, url, name if force == "direct" else None, force=force,
                  as_document="doc" in flags, audio=audio))


def _mode_message() -> tuple[str, list[list[Button]]]:
    mode = get_mode()
    descriptions = {
        "ask": "❓ Ask: every video-site link gets Video / Audio buttons",
        "video": f"🎬 Video: always the best video up to {config.YTDL_MAX_HEIGHT}p plus the best audio (no question)",
        "audio": "🎵 Audio: always a 320 kbps MP3 made from the highest-bitrate audio stream (no question)",
    }
    labels = {"ask": "❓ Ask", "video": "🎬 Video", "audio": "🎵 Audio"}
    text = (f"What happens with video-site links:\n{descriptions[mode]}\n\n"
            "Direct file links are always downloaded exactly as they are.")
    return text, [[Button.inline(f"Switch to {labels[m]}", data=f"mode:{m}") for m in MODES if m != mode]]


async def cmd_mode(message: Message) -> None:
    words = message.raw_text.lower().split()[1:]
    if words and words[0] not in MODES:
        await message.respond("Use /mode to see and switch, or /mode ask, /mode video, /mode audio.")
        return
    if words:
        set_mode(words[0])
    text, keyboard = _mode_message()
    await message.respond(text, buttons=keyboard)


async def cb_mode(query: CallbackQuery) -> None:
    wanted = query.data.decode().partition(":")[2]
    if wanted in MODES:
        set_mode(wanted)
    text, keyboard = _mode_message()
    await safe_edit(query, text, buttons=keyboard)
    await query.answer(f"Mode: {get_mode()}")


COOKIE_HELP = (
    "To fix YouTube's bot check, send me a cookies.txt FILE with the caption /cookies "
    "(or reply to the file with /cookies).\n\n"
    "How to export it (YouTube rotates cookies on open tabs, so do it exactly like this):\n"
    "1. Open a private/incognito window and log in to YouTube (a throwaway account is safest).\n"
    "2. In that same tab, open https://www.youtube.com/robots.txt\n"
    "3. Export youtube.com cookies with the 'Get cookies.txt LOCALLY' (Chrome) or "
    "'cookies.txt' (Firefox) extension.\n"
    "4. Close the private window, then send me the file.\n\n"
    "/cookies clear  - delete the stored cookies"
)


async def cmd_cookies(message: Message) -> None:
    parts = message.raw_text.split(None, 1)
    arg = parts[1].strip().lower() if len(parts) > 1 else ""

    if arg == "clear":
        config.COOKIES_FILE.unlink(missing_ok=True)
        await message.respond("🗑 Cookies removed.")
        return

    reply = await message.get_reply_message() if message.is_reply else None
    src = message.message if message.document else reply if reply and reply.document else None
    if src is None:
        f = config.COOKIES_FILE
        status = (f"🍪 Cookies installed (last updated {human_time(time.time() - f.stat().st_mtime)} ago)."
                  if f.is_file() else "🍪 No cookies installed.")
        await message.respond(f"{status}\n\n{COOKIE_HELP}")
        return

    if jobs.active and jobs.active.kind == "ytdl":  # yt-dlp rewrites the file on exit and would clobber ours
        await message.respond("A yt-dlp job is running. Send the cookies again when it finishes.")
        return
    if src.document.size > COOKIES_MAX_BYTES:
        await message.respond("❌ That file is too big to be a cookies file (limit 1 MB).")
        return

    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    tmp = config.DOWNLOAD_DIR / f"cookies_upload_{secrets.token_hex(4)}"
    path = None
    try:
        path = await src.download_media(file=str(tmp))
        if not path:
            raise JobError("Couldn't download that file from Telegram.")
        info = parse_cookies(Path(path).read_bytes())
    except JobError as e:
        await message.respond(f"❌ {e}")
        return
    finally:
        tmp.unlink(missing_ok=True)
        if path:
            Path(path).unlink(missing_ok=True)

    atomic_write(config.COOKIES_FILE, info.text, 0o600)  # never world-readable
    summary = f"✅ Cookies installed: {info.total} cookies ({info.google} for YouTube/Google)."
    summary += (
        "\nLogged-in session detected." if info.logged_in else
        "\n⚠️ No login cookies found. This looks like a logged-out session, so YouTube may still ask you to sign in."
    )
    sent = await message.respond(summary)
    try:  # don't leave your session cookies sitting in the chat history
        await message.delete()
    except Exception:
        await safe_edit(sent, summary + "\n⚠️ I couldn't delete your upload. Please delete it yourself.")
    if src is reply:  # the file was sent earlier and only replied to
        with contextlib.suppress(Exception):
            await reply.delete()


async def cmd_cancel(message: Message) -> None:
    running, dropped = await jobs.cancel("all" in message.raw_text.lower().split()[1:])
    what = [*(["the running job"] if running else []), *([f"{dropped} queued job(s)"] if dropped else [])]
    await message.respond(f"Cancelled {' and '.join(what)}." if what else "Nothing to cancel.")


async def cmd_status(message: Message) -> None:
    job, ram_disk = jobs.active, system.ram_backed(config.DOWNLOAD_DIR)
    await message.respond(
        f"📊 Active: {f'{job.kind}: {job.url[:60]}' if job else 'idle'}\n"
        f"Queued: {jobs.queue.qsize()}\n"
        f"Video-site links: {get_mode()}\n"
        f"💾 Disk free: {human_size(free_space(config.DOWNLOAD_DIR))}\n"
        + ("⚠️ DOWNLOAD_DIR is RAM-backed (tmpfs): downloads eat memory. Point it at a disk path.\n" if ram_disk else "")
        + f"\n{system.render()}"
    )


# ---------- startup ------------------------------------------------------------------

COMMANDS = {
    "start": cmd_start, "help": cmd_start, "cookies": cmd_cookies,
    "leech": lambda m: _forced(m, "direct"), "ytdl": lambda m: _forced(m, "ytdl"),
    "mode": cmd_mode, "cancel": cmd_cancel, "status": cmd_status,
}
_COMMAND = re.compile(r"/(\w+)(?:@\w+)?(?:\s|$)")


async def on_message(event: Message) -> None:
    """Route one message from the owner: /command, or a text with links, then delete it. (Telethon puts a file's caption in raw_text.)"""
    try:
        m = _COMMAND.match(event.raw_text)
        handler = COMMANDS.get(m.group(1).lower()) if m else None
        if handler:
            await handler(event)
        elif event.raw_text and not (event.document or event.photo):
            await on_text(event)
    finally:  # keep the chat clean: whatever the owner sent is removed once it has been handled
        with contextlib.suppress(Exception):
            await event.delete()


async def on_callback(event: CallbackQuery) -> None:
    data = event.data.decode()
    if data.startswith("pick:"):
        await cb_pick(event)
    elif data.startswith("mode:"):
        await cb_mode(event)


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("telethon").setLevel(logging.WARNING)  # its INFO chatter is just journal noise
    loop = asyncio.get_running_loop()
    loop.set_default_executor(ThreadPoolExecutor(4))  # the default pool may grow to 32 threads; we never need them
    jobs.sweep_orphans()
    if system.ram_backed(config.DOWNLOAD_DIR):
        log.warning("DOWNLOAD_DIR %s is on tmpfs (RAM): every download will use memory. Set DOWNLOAD_DIR to a disk path.",
                    config.DOWNLOAD_DIR)

    client = TelegramClient(
        str(config.SESSION), config.API_ID, config.API_HASH,
        flood_sleep_threshold=120,  # ride out Telegram flood waits up to 2 min instead of failing a finished download
    )
    client.parse_mode = None  # titles/filenames contain _ * < > that would be mangled
    owner = {"from_users": config.OWNER_ID, "func": lambda e: e.is_private}
    client.add_event_handler(on_message, events.NewMessage(incoming=True, **owner))
    client.add_event_handler(on_callback, events.CallbackQuery(func=lambda e: e.sender_id == config.OWNER_ID))

    await client.start(bot_token=config.BOT_TOKEN)
    await jobs.notify_interrupted(client)
    jobs.start(client)
    log.info("Bot started")

    stop = asyncio.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)
    await stop.wait()
    await jobs.stop()
    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
