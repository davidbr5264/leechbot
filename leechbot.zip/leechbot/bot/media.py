"""ffprobe / ffmpeg helpers for upload metadata, thumbnails, and making videos play inside Telegram.

Every call is optional: failure just means plainer uploads, and the original file is returned untouched.
Telegram's player needs H.264 (8-bit yuv420p) + AAC in .mp4 with the index (moov) at the start of the file.
prepare_video copies streams that already fit (no quality loss, very fast) and re-encodes only what doesn't."""
import asyncio
import collections
import contextlib
import json
import logging
import os
import re
from pathlib import Path

from . import config, system
from .utils import JobError, keep_clean

log = logging.getLogger("leechbot")
VIDEO_OK_EXT = {".mp4", ".m4v", ".mov"}
_PROGRESS_LINE = re.compile(r"^(frame|fps|stream_\d+_\d+_q|bitrate|total_size|out_time\w*|dup_frames|drop_frames|speed|progress)=")


async def probe(path: Path) -> dict:
    """One ffprobe call for everything the bot needs. Empty/zero values if ffprobe is missing or fails.
    Keys: duration (s), video / audio (first real stream of each kind or None; cover art is not a video), width,
    height, title, artist."""
    info = {"duration": 0.0, "video": None, "audio": None, "width": 0, "height": 0, "title": "", "artist": ""}
    try:
        await system.wait_for_memory(80)
        rc, out = await system.capture([
            "ffprobe", "-v", "error", "-of", "json", "-show_entries",
            "stream=codec_type,codec_name,pix_fmt,width,height:stream_disposition=attached_pic"
            ":format=duration:format_tags=title,artist", str(path)])
        data = json.loads(out or b"{}") if rc == 0 else {}
    except (JobError, ValueError):  # no RAM to spare or unreadable output: a plain upload, not a failed job
        return info
    fmt = data.get("format") or {}
    with contextlib.suppress(ValueError):  # "N/A"
        info["duration"] = float(fmt.get("duration") or 0)
    tags = {k.lower(): str(v)[:200] for k, v in (fmt.get("tags") or {}).items()}  # TITLE vs title
    info["title"], info["artist"] = tags.get("title", ""), tags.get("artist", "")
    for st in data.get("streams") or []:
        kind = st.get("codec_type")
        if kind in ("video", "audio") and info[kind] is None and not (st.get("disposition") or {}).get("attached_pic"):
            info[kind] = st
    if info["video"]:
        info["width"], info["height"] = int(info["video"].get("width") or 0), int(info["video"].get("height") or 0)
    return info


async def _ffmpeg(cmd: list[str], total: float = 0.0, on_progress=None, need_mb: int = 120) -> bool:
    """Run one ffmpeg job (low-priority/OOM wrapper). True on success. Cancelling kills it."""
    try:
        await system.wait_for_memory(need_mb)
    except JobError as e:
        log.warning("skipping conversion: %s", e)
        return False
    tail: collections.deque[str] = collections.deque(maxlen=6)
    async with system.running(cmd) as proc:
        async for raw in proc.stdout:
            line = raw.decode(errors="replace").strip()
            if line.startswith(("out_time_us=", "out_time_ms=")):  # both are microseconds
                with contextlib.suppress(ValueError):
                    if on_progress and total > 0:
                        await on_progress(min(max(int(line.split("=", 1)[1]) / 1e6, 0.0), total), total)
            elif line and not _PROGRESS_LINE.match(line):
                tail.append(line[:300])
        rc = await proc.wait()
    if rc != 0:
        log.warning("ffmpeg failed (exit %s): %s", rc, " | ".join(tail))
    return rc == 0


async def thumb(src: Path, dst: Path, seek: int = 0, square: bool = False, side: int = 320) -> str | None:
    """One frame of `src` (video, image or cover art) as a JPEG no larger than side x side; returns dst or None.
    square=True crops the centre square first: album art is square, a site's thumbnail is usually 16:9 (for YouTube
    Music the square art sits in the middle of it)."""
    vf = (f"crop='min(iw,ih)':'min(iw,ih)',scale='min({side},iw)':-1" if square
          else f"scale={side}:{side}:force_original_aspect_ratio=decrease")
    ok = await _ffmpeg(["ffmpeg", "-nostdin", "-y", "-v", "error", "-threads", "1", *(["-ss", str(seek)] if seek else []),
                        "-i", str(src), "-frames:v", "1", "-vf", vf, "-q:v", "2", str(dst)], need_mb=80)
    return str(dst) if ok and dst.exists() else None


def _moov_first(path: Path) -> bool:
    """True when the MP4 index ('moov') comes before the media data, so playback starts before the download ends."""
    try:
        size = path.stat().st_size
        with open(path, "rb") as f:
            pos = 0
            while pos + 8 <= size:
                f.seek(pos)
                head = f.read(16)
                length, kind = int.from_bytes(head[:4], "big"), head[4:8]
                if length == 1:  # 64-bit size follows the type
                    length = int.from_bytes(head[8:16], "big")
                elif length == 0:  # runs to the end of the file
                    length = size - pos
                if kind == b"moov":
                    return True
                if kind == b"mdat" or length < 8:
                    return False
                pos += length
    except OSError:
        pass
    return False


async def prepare_video(path: Path, info: dict, on_progress=None) -> tuple[Path, dict]:
    """Return (an .mp4 Telegram plays inline: H.264 + AAC, index first, and its probe info). Streams that already
    fit are copied; the original is returned untouched when no conversion is needed, allowed or possible."""
    video, audio = info["video"], info["audio"]
    v_ok = video.get("codec_name") == "h264" and video.get("pix_fmt") == "yuv420p"
    a_ok = audio is None or audio.get("codec_name") in ("aac", "mp3")
    if v_ok and a_ok and path.suffix.lower() in VIDEO_OK_EXT and await asyncio.to_thread(_moov_first, path):
        return path, info
    if not v_ok and not config.YTDL_TRANSCODE:
        return path, info  # re-encoding video is switched off: it goes up as a file

    tmp, threads = path.with_name(path.stem + ".tg.mp4"), str(config.FFMPEG_THREADS)
    cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-nostats", "-progress", "pipe:1", "-threads", threads,
           "-i", str(path), "-map", "0:v:0", "-map", "0:a:0?", "-sn", "-dn", "-map_metadata", "0"]
    if v_ok:
        cmd += ["-c:v", "copy"]
    else:  # veryfast + few threads keeps RAM modest; crf 20 is visually near-lossless for web video
        cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-profile:v", "high"]
        if info["width"] % 2 or info["height"] % 2:  # yuv420p needs even sizes
            cmd += ["-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2"]
    cmd += ["-c:a", "copy"] if a_ok else ["-c:a", "aac", "-b:a", "192k", "-ac", "2"]
    cmd += ["-max_muxing_queue_size", "1024", "-movflags", "+faststart", "-f", "mp4", str(tmp)]
    try:
        async with keep_clean(path.parent):
            ok = await _ffmpeg(cmd, info["duration"], on_progress, need_mb=100 if v_ok else 250)
        if ok and tmp.exists():
            final = path.with_suffix(".mp4")
            os.replace(tmp, final)
            if final != path:
                path.unlink(missing_ok=True)
            new = await probe(final)
            return final, new if new["video"] else info
    finally:
        tmp.unlink(missing_ok=True)  # no-op after a successful rename
    return path, info
