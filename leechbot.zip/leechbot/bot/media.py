"""ffprobe / ffmpeg helpers for upload metadata and for making downloads play inside Telegram.

Every call is optional: failure just means plainer uploads, and the original file is returned untouched.

Telegram's built-in player handles: video = H.264 (8-bit, yuv420p) + AAC in .mp4 with the index (moov) at the
start of the file; audio = MP3 / AAC (.m4a) / FLAC. Everything else (webm, mkv, VP9, AV1, Opus) is shown as a
plain file, or doesn't play on some phones. These helpers copy streams when they already fit (no quality loss,
very fast) and re-encode only what doesn't."""
import asyncio
import collections
import contextlib
import json
import logging
import os
import re
from pathlib import Path

from . import config, procs
from .utils import JobError, keep_clean

log = logging.getLogger("leechbot")

VIDEO_OK_EXT = {".mp4", ".m4v", ".mov"}
_PROGRESS_LINE = re.compile(r"^(frame|fps|stream_\d+_\d+_q|bitrate|total_size|out_time\w*|dup_frames|drop_frames|speed|progress)=")
_LOSSLESS = {"flac", "alac", "wavpack", "ape", "tta"}
_NATIVE_EXT = {"aac": ".m4a", "alac": ".m4a", "mp3": ".mp3", "flac": ".flac", "opus": ".opus", "vorbis": ".ogg"}


async def _run(*args: str) -> tuple[int, bytes]:
    """Run with OOM priority and a free-RAM check. A missing binary is exit code 127 (callers treat any
    non-zero code as 'unavailable')."""
    try:
        await procs.wait_for_memory(80)
    except JobError:  # metadata is optional: no RAM to spare means a plain upload, not a failed job
        return 127, b""
    proc = await procs.spawn(list(args), stderr=asyncio.subprocess.DEVNULL)
    try:
        out, _ = await proc.communicate()
    except BaseException:  # cancelled: don't leave it running
        proc.kill()
        await proc.wait()
        raise
    return proc.returncode, out


async def probe(path: Path) -> dict:
    """One ffprobe call for everything the bot needs. Empty/zero values if ffprobe is missing or fails.

    Keys: duration (s, float), video / audio (first real stream of each kind, as ffprobe dicts or None),
    cover (the file carries cover art), width, height, title, artist, bitrate (container bits/s, 0 = unknown)."""
    info = {"duration": 0.0, "video": None, "audio": None, "cover": False,
            "width": 0, "height": 0, "title": "", "artist": "", "bitrate": 0}
    rc, out = await _run(
        "ffprobe", "-v", "error",
        "-show_entries", "stream=codec_type,codec_name,pix_fmt,width,height,bit_rate,sample_rate:stream_disposition=attached_pic"
                         ":format=duration,bit_rate:format_tags=title,artist",
        "-of", "json", str(path),
    )
    if rc != 0:
        return info
    try:
        data = json.loads(out or b"{}")
    except ValueError:
        return info
    fmt = data.get("format") or {}
    with contextlib.suppress(ValueError):  # "N/A"
        info["duration"] = float(fmt.get("duration") or 0)
    with contextlib.suppress(ValueError):
        info["bitrate"] = int(fmt.get("bit_rate") or 0)
    tags = {k.lower(): v for k, v in (fmt.get("tags") or {}).items()}  # TITLE vs title
    info["title"], info["artist"] = str(tags.get("title", ""))[:200], str(tags.get("artist", ""))[:200]
    for st in data.get("streams") or []:
        kind, pic = st.get("codec_type"), bool((st.get("disposition") or {}).get("attached_pic"))
        if kind == "video" and pic:
            info["cover"] = True
        elif kind in ("video", "audio") and info[kind] is None:
            info[kind] = st
    if info["video"]:
        info["width"], info["height"] = int(info["video"].get("width") or 0), int(info["video"].get("height") or 0)
    return info


async def _jpeg(src: Path, dst: Path, side: int, seek: int = 0, square: bool = False) -> bool:
    """One frame of `src` (a video, an image, or a file's cover art) as a JPEG no larger than side x side.

    square=True first crops the centre square: album art is square, while a site's thumbnail is usually 16:9
    (for YouTube Music tracks the square art sits in the middle of it, so the crop removes the side bars)."""
    scale = f"scale={side}:{side}:force_original_aspect_ratio=decrease"
    vf = f"crop='min(iw,ih)':'min(iw,ih)',scale='min({side},iw)':-1" if square else scale  # never enlarges
    ok = await _ffmpeg(
        ["ffmpeg", "-nostdin", "-y", "-v", "error", "-threads", "1", *(["-ss", str(seek)] if seek else []),
         "-i", str(src), "-frames:v", "1", "-vf", vf, "-q:v", "2", str(dst)],
        need_mb=80)
    return ok and dst.exists()


async def thumbnail(path: Path, duration: int) -> str | None:
    """A small JPEG frame from the video, for the chat preview. Returns its path, or None on failure."""
    thumb = path.with_suffix(".thumb.jpg")
    return str(thumb) if await _jpeg(path, thumb, 320, 3 if duration > 6 else 0) else None


def _moov_first(path: Path) -> bool:
    """True when the MP4 index ('moov') comes before the media data, so playback starts before the download ends."""
    try:
        size = path.stat().st_size
        with open(path, "rb") as f:
            pos = 0
            while pos + 8 <= size:
                f.seek(pos)
                head = f.read(16)
                length, kind = int.from_bytes(head[:4], "big"), head[4:8]
                if length == 1:  # 64-bit size follows the type
                    length = int.from_bytes(head[8:16], "big")
                elif length == 0:  # runs to the end of the file
                    length = size - pos
                if kind == b"moov":
                    return True
                if kind == b"mdat" or length < 8:
                    return False
                pos += length
    except OSError:
        pass
    return False


async def _ffmpeg(cmd: list[str], total: float = 0.0, on_progress=None, need_mb: int = 120) -> bool:
    """Run one ffmpeg job (with the bot's low-priority/OOM wrapper). True on success. Cancelling kills it."""
    try:
        await procs.wait_for_memory(need_mb)
    except JobError as e:
        log.warning("skipping conversion: %s", e)
        return False
    tail: collections.deque[str] = collections.deque(maxlen=6)
    proc = await procs.spawn(cmd)
    try:
        async for raw in proc.stdout:
            line = raw.decode(errors="replace").strip()
            if line.startswith(("out_time_us=", "out_time_ms=")):  # both are microseconds
                try:
                    done = int(line.split("=", 1)[1]) / 1e6
                except ValueError:
                    continue
                if on_progress and total > 0:
                    await on_progress(min(max(done, 0.0), total), total)
            elif line and not _PROGRESS_LINE.match(line):
                tail.append(line[:300])
        rc = await proc.wait()
    finally:
        if proc.returncode is None:  # cancelled: don't leave it running
            proc.kill()
            await proc.wait()
    if rc != 0:
        log.warning("ffmpeg failed (exit %s): %s", rc, " | ".join(tail))
    return rc == 0


def _swap_in(tmp: Path, original: Path, final: Path) -> Path:
    """Replace the original with the converted file (same disk, so a rename)."""
    os.replace(tmp, final)
    if original != final:
        original.unlink(missing_ok=True)
    return final


async def prepare_video(path: Path, on_progress=None) -> Path:
    """Return an .mp4 that Telegram plays inline: H.264 + AAC, index first. Streams that already fit are copied."""
    info = await probe(path)
    video, audio = info["video"], info["audio"]
    if not video:
        return path  # not a video (or ffprobe unavailable): leave it alone
    v_ok = video.get("codec_name") == "h264" and video.get("pix_fmt") == "yuv420p"
    a_ok = audio is None or audio.get("codec_name") in ("aac", "mp3")
    container_ok = path.suffix.lower() in VIDEO_OK_EXT and await asyncio.to_thread(_moov_first, path)
    if v_ok and a_ok and container_ok:
        return path
    if not v_ok and not config.YTDL_TRANSCODE:
        return path  # re-encoding video is switched off: it goes up as a file

    tmp = path.with_name(path.stem + ".tg.mp4")
    threads = str(config.FFMPEG_THREADS)
    cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-nostats", "-progress", "pipe:1",
           "-threads", threads, "-i", str(path),
           "-map", "0:v:0", "-map", "0:a:0?", "-sn", "-dn", "-map_metadata", "0"]
    if v_ok:
        cmd += ["-c:v", "copy"]
    else:
        # veryfast + few threads keeps RAM modest; crf 20 is visually near-lossless for web video.
        cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
                "-profile:v", "high", "-threads", threads]
        if info["width"] % 2 or info["height"] % 2:  # yuv420p needs even sizes
            cmd += ["-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2"]
    cmd += ["-c:a", "copy"] if a_ok else ["-c:a", "aac", "-b:a", "192k", "-ac", "2"]
    cmd += ["-max_muxing_queue_size", "1024", "-movflags", "+faststart", "-f", "mp4", str(tmp)]

    try:
        async with keep_clean(path.parent):
            ok = await _ffmpeg(cmd, info["duration"], on_progress, need_mb=100 if v_ok else 250)
        if ok and tmp.exists():
            return _swap_in(tmp, path, path.with_suffix(".mp4"))
    finally:
        tmp.unlink(missing_ok=True)  # no-op after a successful rename
    return path


async def prepare_audio(path: Path, cover_src: Path | None = None, on_progress=None) -> Path:
    """Return the audio as a file Telegram's music player handles, at the source's full quality.

    AAC / MP3 / FLAC are copied, not re-encoded. ALAC / WAV become FLAC (still lossless). Opus / Vorbis are
    re-encoded to AAC (AUDIO_BITRATE_K) unless AUDIO_FORMAT=original. Cover art is embedded in the file and a
    small copy is left next to it as <name>.thumb.jpg for the uploader."""
    info = await probe(path)
    audio = info["audio"]
    if not audio:
        return path
    codec = str(audio.get("codec_name") or "")
    if codec in ("aac", "mp3", "flac"):
        enc, ext = ["-c:a", "copy"], _NATIVE_EXT[codec]
    elif codec in _LOSSLESS or codec.startswith("pcm_"):
        enc, ext = ["-c:a", "flac"], ".flac"
    elif config.AUDIO_FORMAT == "original" and codec in ("opus", "vorbis"):
        enc, ext = ["-c:a", "copy"], _NATIVE_EXT[codec]
    else:
        enc, ext = ["-c:a", "aac", "-b:a", f"{config.AUDIO_BITRATE_K}k"], ".m4a"
    final = path.with_suffix(ext)
    tmp = path.with_name(path.stem + ".tg" + ext)

    # Cover art: the site's thumbnail, else art already inside the file. (Ogg can't carry it in an ffmpeg remux.)
    cover, jpg = None, path.with_name(path.stem + ".cover.jpg")
    can_embed = ext in (".m4a", ".mp3", ".flac")
    if cover_src and cover_src.exists() and await _jpeg(cover_src, jpg, 1000, square=True):
        cover = jpg  # else art already inside the file is mapped straight from the input below
    thumb = final.with_suffix(".thumb.jpg")  # what the uploader shows in the chat
    if cover or info["cover"]:
        await _jpeg(cover or path, thumb, 320, square=True)

    cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-nostats", "-progress", "pipe:1", "-i", str(path)]
    if cover and can_embed:
        cmd += ["-i", str(cover)]
    cmd += ["-map", "0:a:0"]
    if can_embed and (cover or info["cover"]):
        cmd += ["-map", "1:v:0" if cover else "0:v:0", "-c:v", "copy", "-disposition:v:0", "attached_pic"]
    cmd += [*enc, "-map_metadata", "0"]
    if ext == ".mp3":
        cmd += ["-id3v2_version", "3"]
    elif ext == ".m4a":
        cmd += ["-movflags", "+faststart"]  # index first, so the player can start before the whole file is in
    cmd.append(str(tmp))

    try:
        ok = await _ffmpeg(cmd, info["duration"], on_progress, need_mb=100)
        if ok and tmp.exists():
            return _swap_in(tmp, path, final)
    finally:
        tmp.unlink(missing_ok=True)
        jpg.unlink(missing_ok=True)
    thumb.unlink(missing_ok=True)  # conversion failed: don't leave art for a file we didn't produce
    return path
