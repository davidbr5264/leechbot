"""ffprobe / ffmpeg helpers for upload metadata and for making videos play inside Telegram.

Every call is optional: failure just means plainer uploads, and the original file is returned untouched.

Telegram's built-in player needs video = H.264 (8-bit, yuv420p) + AAC in .mp4 with the index (moov) at the start
of the file. prepare_video copies streams when they already fit (no quality loss, very fast) and re-encodes only
what doesn't. Audio is converted to MP3 by yt-dlp itself (see ytdlp.py), not here."""
import asyncio
import collections
import contextlib
import json
import logging
import os
import re
from pathlib import Path

from . import config, system
from .utils import JobError, keep_clean

log = logging.getLogger("leechbot")

VIDEO_OK_EXT = {".mp4", ".m4v", ".mov"}
_PROGRESS_LINE = re.compile(r"^(frame|fps|stream_\d+_\d+_q|bitrate|total_size|out_time\w*|dup_frames|drop_frames|speed|progress)=")


async def _run(*args: str) -> tuple[int, bytes]:
    """Run with OOM priority and a free-RAM check. A missing binary is exit code 127 (callers treat any
    non-zero code as 'unavailable')."""
    try:
        await system.wait_for_memory(80)
    except JobError:  # metadata is optional: no RAM to spare means a plain upload, not a failed job
        return 127, b""
    return await system.capture(list(args))


async def _probe(path: Path) -> dict:
    """One ffprobe call for everything the bot needs. Empty/zero values if ffprobe is missing or fails.

    Keys: duration (s, float), video / audio (first real stream of each kind, as ffprobe dicts or None; cover art
    is not a video stream), width, height, title, artist."""
    info = {"duration": 0.0, "video": None, "audio": None, "width": 0, "height": 0, "title": "", "artist": ""}
    rc, out = await _run(
        "ffprobe", "-v", "error",
        "-show_entries", "stream=codec_type,codec_name,pix_fmt,width,height:stream_disposition=attached_pic"
                         ":format=duration:format_tags=title,artist",
        "-of", "json", str(path),
    )
    if rc != 0:
        return info
    try:
        data = json.loads(out or b"{}")
    except ValueError:
        return info
    fmt = data.get("format") or {}
    with contextlib.suppress(ValueError):  # "N/A"
        info["duration"] = float(fmt.get("duration") or 0)
    tags = {k.lower(): v for k, v in (fmt.get("tags") or {}).items()}  # TITLE vs title
    info["title"], info["artist"] = str(tags.get("title", ""))[:200], str(tags.get("artist", ""))[:200]
    for st in data.get("streams") or []:
        kind = st.get("codec_type")
        if kind == "video" and (st.get("disposition") or {}).get("attached_pic"):
            continue  # cover art inside an audio file, not a video
        if kind in ("video", "audio") and info[kind] is None:
            info[kind] = st
    if info["video"]:
        info["width"], info["height"] = int(info["video"].get("width") or 0), int(info["video"].get("height") or 0)
    return info


_last_probe: tuple | None = None  # (path, size, mtime, info) of the latest probe


async def probe(path: Path) -> dict:
    """_probe, remembering the last file: the check before conversion and the uploader's look at the
    finished file are often the same file, and a second ffprobe process is wasted work."""
    global _last_probe
    try:
        st = path.stat()
    except OSError:
        return await _probe(path)
    key = (str(path), st.st_size, st.st_mtime_ns)
    if _last_probe and _last_probe[0] == key:
        return dict(_last_probe[1])
    info = await _probe(path)
    if info["video"] or info["audio"]:  # a failed probe (no RAM, no ffprobe) must be retried next time
        _last_probe = (key, info)
    return dict(info)


async def _jpeg(src: Path, dst: Path, side: int, seek: int = 0, square: bool = False) -> bool:
    """One frame of `src` (a video, an image, or a file's cover art) as a JPEG no larger than side x side.

    square=True first crops the centre square: album art is square, while a site's thumbnail is usually 16:9
    (for YouTube Music tracks the square art sits in the middle of it, so the crop removes the side bars)."""
    scale = f"scale={side}:{side}:force_original_aspect_ratio=decrease"
    vf = f"crop='min(iw,ih)':'min(iw,ih)',scale='min({side},iw)':-1" if square else scale  # never enlarges
    ok = await _ffmpeg(
        ["ffmpeg", "-nostdin", "-y", "-v", "error", "-threads", "1", *(["-ss", str(seek)] if seek else []),
         "-i", str(src), "-frames:v", "1", "-vf", vf, "-q:v", "2", str(dst)],
        need_mb=80)
    return ok and dst.exists()


async def thumbnail(path: Path, duration: int) -> str | None:
    """A small JPEG frame from the video, for the chat preview. Returns its path, or None on failure."""
    thumb = path.with_suffix(".thumb.jpg")
    return str(thumb) if await _jpeg(path, thumb, 320, 3 if duration > 6 else 0) else None


def _moov_first(path: Path) -> bool:
    """True when the MP4 index ('moov') comes before the media data, so playback starts before the download ends."""
    try:
        size = path.stat().st_size
        with open(path, "rb") as f:
            pos = 0
            while pos + 8 <= size:
                f.seek(pos)
                head = f.read(16)
                length, kind = int.from_bytes(head[:4], "big"), head[4:8]
                if length == 1:  # 64-bit size follows the type
                    length = int.from_bytes(head[8:16], "big")
                elif length == 0:  # runs to the end of the file
                    length = size - pos
                if kind == b"moov":
                    return True
                if kind == b"mdat" or length < 8:
                    return False
                pos += length
    except OSError:
        pass
    return False


async def _ffmpeg(cmd: list[str], total: float = 0.0, on_progress=None, need_mb: int = 120) -> bool:
    """Run one ffmpeg job (with the bot's low-priority/OOM wrapper). True on success. Cancelling kills it."""
    try:
        await system.wait_for_memory(need_mb)
    except JobError as e:
        log.warning("skipping conversion: %s", e)
        return False
    tail: collections.deque[str] = collections.deque(maxlen=6)
    async with system.running(cmd) as proc:
        async for raw in proc.stdout:
            line = raw.decode(errors="replace").strip()
            if line.startswith(("out_time_us=", "out_time_ms=")):  # both are microseconds
                try:
                    done = int(line.split("=", 1)[1]) / 1e6
                except ValueError:
                    continue
                if on_progress and total > 0:
                    await on_progress(min(max(done, 0.0), total), total)
            elif line and not _PROGRESS_LINE.match(line):
                tail.append(line[:300])
        rc = await proc.wait()
    if rc != 0:
        log.warning("ffmpeg failed (exit %s): %s", rc, " | ".join(tail))
    return rc == 0


def _swap_in(tmp: Path, original: Path, final: Path) -> Path:
    """Replace the original with the converted file (same disk, so a rename)."""
    os.replace(tmp, final)
    if original != final:
        original.unlink(missing_ok=True)
    return final


async def prepare_video(path: Path, on_progress=None) -> Path:
    """Return an .mp4 that Telegram plays inline: H.264 + AAC, index first. Streams that already fit are copied."""
    info = await probe(path)
    video, audio = info["video"], info["audio"]
    if not video:
        return path  # not a video (or ffprobe unavailable): leave it alone
    v_ok = video.get("codec_name") == "h264" and video.get("pix_fmt") == "yuv420p"
    a_ok = audio is None or audio.get("codec_name") in ("aac", "mp3")
    container_ok = path.suffix.lower() in VIDEO_OK_EXT and await asyncio.to_thread(_moov_first, path)
    if v_ok and a_ok and container_ok:
        return path
    if not v_ok and not config.YTDL_TRANSCODE:
        return path  # re-encoding video is switched off: it goes up as a file

    tmp = path.with_name(path.stem + ".tg.mp4")
    threads = str(config.FFMPEG_THREADS)
    cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-nostats", "-progress", "pipe:1",
           "-threads", threads, "-i", str(path),
           "-map", "0:v:0", "-map", "0:a:0?", "-sn", "-dn", "-map_metadata", "0"]
    if v_ok:
        cmd += ["-c:v", "copy"]
    else:
        # veryfast + few threads keeps RAM modest; crf 20 is visually near-lossless for web video.
        cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
                "-profile:v", "high", "-threads", threads]
        if info["width"] % 2 or info["height"] % 2:  # yuv420p needs even sizes
            cmd += ["-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2"]
    cmd += ["-c:a", "copy"] if a_ok else ["-c:a", "aac", "-b:a", "192k", "-ac", "2"]
    cmd += ["-max_muxing_queue_size", "1024", "-movflags", "+faststart", "-f", "mp4", str(tmp)]

    try:
        async with keep_clean(path.parent):
            ok = await _ffmpeg(cmd, info["duration"], on_progress, need_mb=100 if v_ok else 250)
        if ok and tmp.exists():
            return _swap_in(tmp, path, path.with_suffix(".mp4"))
    finally:
        tmp.unlink(missing_ok=True)  # no-op after a successful rename
    return path


async def cover_thumb(path: Path, cover: Path | None) -> None:
    """Square preview of a track's cover art for Telegram's player, left next to the audio as <name>.thumb.jpg.
    The audio file itself is never touched."""
    if cover and cover.is_file():
        await _jpeg(cover, path.with_suffix(".thumb.jpg"), 320, square=True)
