"""ffprobe / ffmpeg helpers for upload metadata. Every call is optional: failure just means plainer uploads."""
import asyncio
import json
from pathlib import Path

from . import procs


async def _run(*args: str) -> tuple[int, bytes]:
    """Run with OOM priority and a free-RAM check. A missing binary is exit code 127 (callers treat any
    non-zero code as 'unavailable')."""
    await procs.wait_for_memory(80)
    proc = await procs.spawn(list(args), stderr=asyncio.subprocess.DEVNULL)
    try:
        out, _ = await proc.communicate()
    except BaseException:  # cancelled: don't leave it running
        proc.kill()
        raise
    return proc.returncode, out


async def probe(path: Path) -> dict:
    """Duration/width/height and title/artist tags (zeros/empty if ffprobe is missing or fails)."""
    meta = {"duration": 0, "width": 0, "height": 0, "title": "", "artist": ""}
    rc, out = await _run(
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height:format=duration:format_tags=title,artist",
        "-of", "json", str(path),
    )
    if rc != 0:
        return meta
    try:
        data = json.loads(out or b"{}")
        stream = (data.get("streams") or [{}])[0]
        fmt = data.get("format", {})
        tags = {k.lower(): v for k, v in (fmt.get("tags") or {}).items()}  # TITLE vs title
        meta.update(width=int(stream.get("width") or 0), height=int(stream.get("height") or 0),
                    duration=int(float(fmt.get("duration") or 0)),
                    title=str(tags.get("title", ""))[:200], artist=str(tags.get("artist", ""))[:200])
    except ValueError:
        pass
    return meta


async def thumbnail(path: Path, duration: int) -> str | None:
    """Grab one small JPEG frame. Returns its path, or None on failure."""
    thumb = path.with_suffix(".thumb.jpg")
    rc, _ = await _run(
        "ffmpeg", "-y", "-threads", "1", "-ss", "3" if duration > 6 else "0", "-i", str(path),
        "-frames:v", "1", "-vf", "scale=320:-2", "-q:v", "5", str(thumb),
    )
    return str(thumb) if rc == 0 and thumb.exists() else None
