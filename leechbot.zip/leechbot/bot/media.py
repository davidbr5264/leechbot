"""ffprobe / ffmpeg helpers for upload metadata. Every call is optional: failure just means plainer uploads."""
import asyncio
import collections
import json
import logging
import os
import re
from pathlib import Path

from . import config, procs
from .utils import JobError, keep_clean

log = logging.getLogger("leechbot")


async def _run(*args: str) -> tuple[int, bytes]:
    """Run with OOM priority and a free-RAM check. A missing binary is exit code 127 (callers treat any
    non-zero code as 'unavailable')."""
    try:
        await procs.wait_for_memory(80)
    except JobError:  # metadata is optional: no RAM to spare means a plain upload, not a failed job
        return 127, b""
    proc = await procs.spawn(list(args), stderr=asyncio.subprocess.DEVNULL)
    try:
        out, _ = await proc.communicate()
    except BaseException:  # cancelled: don't leave it running
        proc.kill()
        await proc.wait()
        raise
    return proc.returncode, out


async def probe(path: Path) -> dict:
    """Duration/width/height and title/artist tags (zeros/empty if ffprobe is missing or fails)."""
    meta = {"duration": 0, "width": 0, "height": 0, "title": "", "artist": ""}
    rc, out = await _run(
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height:format=duration:format_tags=title,artist",
        "-of", "json", str(path),
    )
    if rc != 0:
        return meta
    try:
        data = json.loads(out or b"{}")
        stream = (data.get("streams") or [{}])[0]
        fmt = data.get("format", {})
        tags = {k.lower(): v for k, v in (fmt.get("tags") or {}).items()}  # TITLE vs title
        meta.update(width=int(stream.get("width") or 0), height=int(stream.get("height") or 0),
                    duration=int(float(fmt.get("duration") or 0)),
                    title=str(tags.get("title", ""))[:200], artist=str(tags.get("artist", ""))[:200])
    except ValueError:
        pass
    return meta


async def thumbnail(path: Path, duration: int) -> str | None:
    """Grab one small JPEG frame. Returns its path, or None on failure."""
    thumb = path.with_suffix(".thumb.jpg")
    rc, _ = await _run(
        "ffmpeg", "-y", "-threads", "1", "-ss", "3" if duration > 6 else "0", "-i", str(path),
        "-frames:v", "1", "-vf", "scale=320:-2", "-q:v", "5", str(thumb),
    )
    return str(thumb) if rc == 0 and thumb.exists() else None


# ---------- making downloads play inside Telegram -----------------------------------------
# Telegram's built-in player handles: video = H.264 (8-bit, yuv420p) + AAC in .mp4 with the index (moov) at the
# start of the file; audio = MP3 / AAC (.m4a) / FLAC. Everything else (webm, mkv, VP9, AV1, Opus) is shown as a
# plain file, or doesn't play on some phones. These helpers copy streams when they already fit (no quality loss,
# very fast) and re-encode only what doesn't. On any failure the original file is returned untouched.

VIDEO_OK_EXT = {".mp4", ".m4v", ".mov"}
_PROGRESS_LINE = re.compile(r"^(frame|fps|stream_\d+_\d+_q|bitrate|total_size|out_time\w*|dup_frames|drop_frames|speed|progress)=")


async def probe_streams(path: Path) -> dict:
    """First video / audio stream, whether the file carries cover art, and the duration. Empty if ffprobe fails."""
    info = {"video": None, "audio": None, "cover": False, "duration": 0.0}
    rc, out = await _run(
        "ffprobe", "-v", "error",
        "-show_entries", "stream=codec_type,codec_name,pix_fmt,width,height:stream_disposition=attached_pic:format=duration",
        "-of", "json", str(path),
    )
    if rc != 0:
        return info
    try:
        data = json.loads(out or b"{}")
        info["duration"] = float((data.get("format") or {}).get("duration") or 0)
    except ValueError:
        return info
    for st in data.get("streams") or []:
        kind, pic = st.get("codec_type"), bool((st.get("disposition") or {}).get("attached_pic"))
        if kind == "video" and pic:
            info["cover"] = True
        elif kind == "video" and info["video"] is None:
            info["video"] = st
        elif kind == "audio" and info["audio"] is None:
            info["audio"] = st
    return info


def _moov_first(path: Path) -> bool:
    """True when the MP4 index ('moov') comes before the media data, so playback starts before the download ends."""
    try:
        size = path.stat().st_size
        with open(path, "rb") as f:
            pos = 0
            while pos + 8 <= size:
                f.seek(pos)
                head = f.read(16)
                length, kind = int.from_bytes(head[:4], "big"), head[4:8]
                if length == 1:  # 64-bit size follows the type
                    length = int.from_bytes(head[8:16], "big")
                elif length == 0:  # runs to the end of the file
                    length = size - pos
                if kind == b"moov":
                    return True
                if kind == b"mdat" or length < 8:
                    return False
                pos += length
    except OSError:
        pass
    return False


async def _ffmpeg(cmd: list[str], total: float = 0.0, on_progress=None, need_mb: int = 120) -> bool:
    """Run one ffmpeg job (with the bot's low-priority/OOM wrapper). True on success. Cancelling kills it."""
    try:
        await procs.wait_for_memory(need_mb)
    except JobError as e:
        log.warning("skipping conversion: %s", e)
        return False
    tail: collections.deque[str] = collections.deque(maxlen=6)
    proc = await procs.spawn(cmd)
    try:
        async for raw in proc.stdout:
            line = raw.decode(errors="replace").strip()
            if line.startswith(("out_time_us=", "out_time_ms=")):  # both are microseconds
                try:
                    done = int(line.split("=", 1)[1]) / 1e6
                except ValueError:
                    continue
                if on_progress and total > 0:
                    await on_progress(min(max(done, 0.0), total), total)
            elif line and not _PROGRESS_LINE.match(line):
                tail.append(line[:300])
        rc = await proc.wait()
    finally:
        if proc.returncode is None:  # cancelled: don't leave it running
            proc.kill()
            await proc.wait()
    if rc != 0:
        log.warning("ffmpeg failed (exit %s): %s", rc, " | ".join(tail))
    return rc == 0


async def _finish(tmp: Path, original: Path, final: Path) -> Path:
    """Swap the converted file in for the original (same disk, so a rename)."""
    os.replace(tmp, final)
    if original != final:
        original.unlink(missing_ok=True)
    return final


async def prepare_video(path: Path, on_progress=None) -> Path:
    """Return an .mp4 that Telegram plays inline: H.264 + AAC, index first. Streams that already fit are copied."""
    info = await probe_streams(path)
    video, audio = info["video"], info["audio"]
    if not video:
        return path  # not a video (or ffprobe unavailable): leave it alone
    v_ok = video.get("codec_name") == "h264" and video.get("pix_fmt") == "yuv420p"
    a_ok = audio is None or audio.get("codec_name") in ("aac", "mp3")
    container_ok = path.suffix.lower() in VIDEO_OK_EXT and await asyncio.to_thread(_moov_first, path)
    if v_ok and a_ok and container_ok:
        return path
    if not v_ok and not config.YTDL_TRANSCODE:
        return path  # re-encoding video is switched off: it goes up as a file

    tmp = path.with_name(path.stem + ".tg.mp4")
    threads = str(config.FFMPEG_THREADS)
    cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-nostats", "-progress", "pipe:1",
           "-threads", threads, "-i", str(path),
           "-map", "0:v:0", "-map", "0:a:0?", "-sn", "-dn", "-map_metadata", "0"]
    if v_ok:
        cmd += ["-c:v", "copy"]
    else:
        # veryfast + 2 threads keeps RAM modest; crf 20 is visually near-lossless for web video.
        cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
                "-profile:v", "high", "-threads", threads]
        if int(video.get("width") or 0) % 2 or int(video.get("height") or 0) % 2:  # yuv420p needs even sizes
            cmd += ["-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2"]
    cmd += ["-c:a", "copy"] if a_ok else ["-c:a", "aac", "-b:a", "192k", "-ac", "2"]
    cmd += ["-max_muxing_queue_size", "1024", "-movflags", "+faststart", "-f", "mp4", str(tmp)]

    try:
        async with keep_clean(path.parent):
            ok = await _ffmpeg(cmd, info["duration"], on_progress, need_mb=100 if v_ok else 250)
        if ok and tmp.exists():
            return await _finish(tmp, path, path.with_suffix(".mp4"))
    finally:
        tmp.unlink(missing_ok=True)  # no-op after a successful rename
    return path


_LOSSLESS = {"flac", "alac", "wavpack", "ape", "tta"}
_NATIVE_EXT = {"aac": ".m4a", "alac": ".m4a", "mp3": ".mp3", "flac": ".flac", "opus": ".opus", "vorbis": ".ogg"}


async def _jpeg(src: Path, dst: Path, side: int) -> bool:
    """One frame of `src` (an image, or a file's cover art) as a JPEG no larger than side x side."""
    ok = await _ffmpeg(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(src), "-frames:v", "1",
                        "-vf", f"scale={side}:{side}:force_original_aspect_ratio=decrease", "-q:v", "3", str(dst)],
                       need_mb=80)
    return ok and dst.exists()


async def prepare_audio(path: Path, cover_src: Path | None = None, on_progress=None) -> Path:
    """Return the audio as a file Telegram's music player handles, at the source's full quality.

    AAC / MP3 / FLAC are copied, not re-encoded. ALAC / WAV become FLAC (still lossless). Opus / Vorbis are
    re-encoded to AAC (AUDIO_BITRATE_K) unless AUDIO_FORMAT=original. Cover art is embedded in the file and a
    small copy is left next to it as <name>.thumb.jpg for the uploader."""
    info = await probe_streams(path)
    audio = info["audio"]
    if not audio:
        return path
    codec = str(audio.get("codec_name") or "")
    if codec in ("aac", "mp3", "flac"):
        enc, ext = ["-c:a", "copy"], _NATIVE_EXT[codec]
    elif codec in _LOSSLESS or codec.startswith("pcm_"):
        enc, ext = ["-c:a", "flac"], ".flac"
    elif config.AUDIO_FORMAT == "original" and codec in ("opus", "vorbis"):
        enc, ext = ["-c:a", "copy"], _NATIVE_EXT[codec]
    else:
        enc, ext = ["-c:a", "aac", "-b:a", f"{config.AUDIO_BITRATE_K}k"], ".m4a"
    final = path.with_suffix(ext)
    tmp = path.with_name(path.stem + ".tg" + ext)

    # Cover art: the site's thumbnail, else art already inside the file. (Ogg can't carry it in an ffmpeg remux.)
    cover, jpg = None, path.with_name(path.stem + ".cover.jpg")
    can_embed = ext in (".m4a", ".mp3", ".flac")
    if cover_src and cover_src.exists() and await _jpeg(cover_src, jpg, 600):
        cover = jpg  # else art already inside the file is mapped straight from the input below
    thumb = final.with_suffix(".thumb.jpg")  # what the uploader shows in the chat
    have_art = bool(cover) or info["cover"]
    if have_art:
        await _jpeg(cover or path, thumb, 320)

    cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-nostats", "-progress", "pipe:1", "-i", str(path)]
    if cover and can_embed:
        cmd += ["-i", str(cover)]
    cmd += ["-map", "0:a:0"]
    if can_embed and (cover or info["cover"]):
        cmd += ["-map", "1:v:0" if cover else "0:v:0", "-c:v", "copy", "-disposition:v:0", "attached_pic"]
    cmd += [*enc, "-map_metadata", "0"]
    if ext == ".mp3":
        cmd += ["-id3v2_version", "3"]
    elif ext == ".m4a":
        cmd += ["-movflags", "+faststart"]  # index first, so the player can start before the whole file is in
    cmd.append(str(tmp))

    try:
        ok = await _ffmpeg(cmd, info["duration"], on_progress, need_mb=100)
        if ok and tmp.exists():
            return await _finish(tmp, path, final)
    finally:
        tmp.unlink(missing_ok=True)
        jpg.unlink(missing_ok=True)
    thumb.unlink(missing_ok=True)  # conversion failed: don't leave art for a file we didn't produce
    return path
