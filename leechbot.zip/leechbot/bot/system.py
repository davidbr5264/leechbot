"""Child processes and memory numbers for servers with very little RAM (Linux; unreadable values are skipped).

Children (yt-dlp, ffmpeg) get oom_score_adj +500, nice 10 and low I/O priority, so when memory runs out they are
killed first and the bot survives. Before starting one we wait until enough RAM is free. Jobs run one at a time,
so no extra lock is needed."""
import asyncio
import contextlib
import os
from pathlib import Path

from . import config
from .utils import JobError, human_size

OOM_MESSAGE = ("💥 The server ran out of memory and the process was killed. "
               "Try a lower resolution or audio only (see /status).")
_UNLIMITED = 1 << 60
# A tiny shell sets the OOM score and I/O priority on itself (best effort), then execs the real command (same PID).
_WRAP = 'echo 500 > /proc/self/oom_score_adj 2>/dev/null; ionice -c2 -n7 -p $$ 2>/dev/null; exec nice -n 10 "$@"'


@contextlib.asynccontextmanager
async def running(cmd: list[str], *, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
                  scratch: Path | None = None):
    """Start `cmd` at low priority; it is killed if the block is cancelled or fails.

    scratch: a folder the caller deletes after the job. The child's temp files (TMPDIR) and caches
    (XDG_CACHE_HOME, where yt-dlp keeps its own) go there, so nothing survives and nothing lands in a RAM-backed /tmp."""
    env = None
    if scratch is not None:
        scratch.mkdir(parents=True, exist_ok=True)
        env = {**os.environ, "TMPDIR": str(scratch), "XDG_CACHE_HOME": str(scratch)}
    proc = await asyncio.create_subprocess_exec("/bin/sh", "-c", _WRAP, "sh", *cmd, stdout=stdout, stderr=stderr,
                                                limit=1 << 20, env=env)
    try:
        yield proc
    finally:
        if proc.returncode is None:
            proc.kill()
            await proc.wait()


async def capture(cmd: list[str], timeout: float | None = None) -> tuple[int | None, bytes]:
    """Run to completion; returns (exit code, stdout). Raises asyncio.TimeoutError after `timeout` (child killed)."""
    async with running(cmd, stderr=asyncio.subprocess.DEVNULL) as proc:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout)
        return proc.returncode, out


def oom_killed(returncode: int | None) -> bool:
    return returncode in (-9, 137)


async def wait_for_memory(need_mb: int | None = None, timeout: float = 120, on_wait=None) -> None:
    need = (need_mb or config.MIN_FREE_RAM_MB) * 2**20
    waited = 0.0
    while (free := headroom()) < need:
        if waited >= timeout:
            raise JobError(f"Not enough free memory ({free // 2**20} MB free, need {need // 2**20} MB). "
                           "Try again in a moment (see /status).")
        if waited == 0 and on_wait:
            await on_wait(f"⏳ Low memory ({free // 2**20} MB free). Waiting for it to free up…")
        await asyncio.sleep(3)
        waited += 3


# ---------- memory numbers ------------------------------------------------------------

def _read(path) -> str:
    try:
        return Path(path).read_text()
    except OSError:
        return ""


def _kv(path) -> dict[str, int]:
    """'Key:  123 kB' lines of a /proc file as {key: bytes}."""
    out = {}
    for line in _read(path).splitlines():
        key, _, rest = line.partition(":")
        if rest.split() and rest.split()[0].isdigit():
            out[key] = int(rest.split()[0]) * 1024
    return out


def cgroup() -> tuple[int, int | None, int] | None:
    """(used, limit or None, reclaimable cache) of the systemd service this process runs in (cgroup v2)."""
    rel = next((ln[3:] for ln in _read("/proc/self/cgroup").splitlines() if ln.startswith("0::")), None)
    base = Path("/sys/fs/cgroup") / (rel or "").lstrip("/")
    used = _read(base / "memory.current").strip()
    if rel is None or not used.isdigit():
        return None
    limit = _read(base / "memory.max").strip()
    stat = dict(ln.split() for ln in _read(base / "memory.stat").splitlines() if len(ln.split()) == 2)
    return (int(used), int(limit) if limit.isdigit() and int(limit) < _UNLIMITED else None, int(stat.get("file", 0)))


def headroom() -> int:
    """Bytes still allocatable: system MemAvailable, capped by the service's limit (cache excluded: reclaimable)."""
    mi = _kv("/proc/meminfo")
    avail = mi.get("MemAvailable", mi.get("MemFree", 0))
    if (cg := cgroup()) and cg[1]:
        avail = min(avail, max(cg[1] - (cg[0] - cg[2]), 0))
    return avail


def ram_backed(path) -> bool:
    """True when `path` lives on tmpfs/ramfs: every downloaded byte would then be held in RAM."""
    target = os.path.realpath(path)
    best, fstype = "", ""
    for line in _read("/proc/self/mountinfo").splitlines():
        left, _, right = line.partition(" - ")
        fields = left.split()
        if len(fields) < 5 or not right:
            continue
        mount = fields[4].replace("\\040", " ")
        if (target == mount or target.startswith(mount.rstrip("/") + "/")) and len(mount) > len(best):
            best, fstype = mount, right.split()[0]
    return fstype in ("tmpfs", "ramfs")


def render() -> str:
    mi, me = _kv("/proc/meminfo"), _kv("/proc/self/status")
    total, avail = mi.get("MemTotal", 0), mi.get("MemAvailable", mi.get("MemFree", 0))
    swap = (f"Swap: {human_size(mi['SwapTotal'] - mi.get('SwapFree', 0))} used of {human_size(mi['SwapTotal'])}"
            if mi.get("SwapTotal") else "Swap: none")
    lines = ["🧠 Memory", f"System: {human_size(total - avail)} used of {human_size(total)} ({human_size(avail)} available)",
             swap, f"Bot process: {human_size(me.get('VmRSS', 0))} (peak {human_size(me.get('VmHWM', 0))})"]
    tight = bool(total) and avail < 0.10 * total
    if cg := cgroup():
        used, limit, cache = cg
        lines.append(f"Service: {human_size(used)}" + (f" of {human_size(limit)} cap" if limit else "")
                     + f" (cache {human_size(cache)})")
        tight = tight or bool(limit) and used - cache > 0.85 * limit
    if tight:
        lines.append("⚠️ Memory is tight: new jobs may be slow, or get killed.")
    return "\n".join(lines)
