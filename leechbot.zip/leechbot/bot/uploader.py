import io
import math
from pathlib import Path

from telethon.tl.types import DocumentAttributeAudio, DocumentAttributeVideo

from . import config, media
from .utils import keep_clean

# Only containers Telegram plays inline reliably; mkv/webm/avi go as documents.
VIDEO_EXT = {".mp4", ".m4v", ".mov"}
AUDIO_EXT = {".mp3", ".m4a", ".flac", ".ogg", ".opus", ".wav", ".aac"}


_CODEC_NAMES = {"aac": "AAC", "mp3": "MP3", "flac": "FLAC", "opus": "Opus", "vorbis": "Vorbis", "alac": "ALAC"}


def audio_caption(path: Path, meta: dict) -> str:
    """What the chat shows under a track: 'Artist - Title' and the real format, e.g. 'AAC · 256 kbps · 48 kHz'.
    (The file name carries the site's video id, which means nothing to a listener.)"""
    st = meta.get("audio") or {}
    codec = str(st.get("codec_name") or "")
    parts = [_CODEC_NAMES.get(codec, codec.upper())] if codec else []
    try:
        kbps = round(int(st.get("bit_rate") or meta.get("bitrate") or 0) / 1000)
    except (TypeError, ValueError):
        kbps = 0
    if codec != "flac" and kbps:  # FLAC's bitrate varies with the music; the sample rate says more
        parts.append(f"{kbps} kbps")
    try:
        khz = int(st.get("sample_rate") or 0) / 1000
    except (TypeError, ValueError):
        khz = 0
    if khz:
        parts.append(f"{khz:g} kHz")
    name = " - ".join(x for x in (meta.get("artist"), meta.get("title")) if x) or path.stem
    return (name + ("\n" + " · ".join(parts) if parts else ""))[:1024]


async def send(client, chat_id: int, path: Path, prog, as_document: bool = False) -> None:
    """Upload a finished file, splitting it when it is over the per-upload limit."""
    if path.stat().st_size > config.MAX_FILE_SIZE:
        await _upload_split(client, chat_id, path, prog)
    else:
        await _upload(client, chat_id, path, prog.upload, as_document)


async def _upload(client, chat_id: int, path: Path, on_progress, as_document: bool) -> None:
    ext = path.suffix.lower()
    common = {"caption": path.name[:1024], "progress_callback": on_progress}
    meta = await media.probe(path) if not as_document and ext in VIDEO_EXT | AUDIO_EXT else None
    async with keep_clean(path):  # don't let reading a big file for upload fill the page cache
        duration = int(meta["duration"]) if meta else 0
        if meta and ext in VIDEO_EXT and meta["width"]:  # an .mp4 without a video stream can't be sent as a video
            video = DocumentAttributeVideo(duration=duration, w=meta["width"], h=meta["height"],
                                           supports_streaming=True)
            await client.send_file(chat_id, str(path), attributes=[video], supports_streaming=True,
                                   thumb=await media.thumbnail(path, duration), **common)
        elif meta and ext in AUDIO_EXT:
            audio = DocumentAttributeAudio(duration=duration, title=meta["title"] or None,
                                           performer=meta["artist"] or None)
            cover = path.with_suffix(".thumb.jpg")  # written by media.prepare_audio when the track has cover art
            common["caption"] = audio_caption(path, meta)
            await client.send_file(chat_id, str(path), attributes=[audio],
                                   thumb=str(cover) if cover.is_file() else None, **common)
        else:
            await client.send_file(chat_id, str(path), force_document=True, **common)


class _Window(io.RawIOBase):
    """A read-only view of bytes [offset, offset+length) of a file, shaped like a small file of its own.

    Lets one part of a big file be uploaded straight from the original: no copy, no extra disk space,
    no extra I/O. (Telethon accepts any seekable file object with a `name` and read.)"""

    def __init__(self, path: Path, offset: int, length: int, name: str):
        super().__init__()
        self.name = name
        self._f = open(path, "rb")
        self._offset, self._length, self._pos = offset, length, 0

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return True

    def tell(self) -> int:
        return self._pos

    def seek(self, pos: int, whence: int = io.SEEK_SET) -> int:
        base = (0, self._pos, self._length)[whence]
        self._pos = max(0, min(base + pos, self._length))
        return self._pos

    def read(self, n: int = -1) -> bytes:
        left = self._length - self._pos
        n = left if n < 0 else min(n, left)
        if n <= 0:
            return b""
        self._f.seek(self._offset + self._pos)
        data = self._f.read(n)
        self._pos += len(data)
        return data

    def close(self) -> None:
        self._f.close()
        super().close()


async def _upload_split(client, chat_id: int, path: Path, prog) -> None:
    """Upload an oversized file as name.ext.001, .002, ..., each read directly from the original file."""
    size, part_size = path.stat().st_size, config.MAX_FILE_SIZE
    n = math.ceil(size / part_size)
    join_hint = f'cat "{path.name}".* > "{path.name}"'
    async with keep_clean(path):
        for i in range(n):
            name = f"{path.name}.{i + 1:03d}"
            prog.upload_label = f"⬆️ Uploading part {i + 1}/{n}"
            length = min(part_size, size - i * part_size)
            with _Window(path, i * part_size, length, name) as part:
                await client.send_file(
                    chat_id, part, force_document=True, file_size=length,
                    caption=f"{name}\nJoin: {join_hint}"[:1024], progress_callback=prog.upload,
                )
