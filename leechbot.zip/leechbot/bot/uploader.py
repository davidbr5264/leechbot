import io
import math
from pathlib import Path

from telethon.tl.types import DocumentAttributeAudio, DocumentAttributeVideo

from . import config, media
from .utils import keep_clean

# Only containers Telegram plays inline reliably; mkv/webm/avi go as documents.
VIDEO_EXT = {".mp4", ".m4v", ".mov"}
AUDIO_EXT = {".mp3", ".m4a", ".flac", ".ogg", ".opus", ".wav", ".aac"}


async def send(client, chat_id: int, path: Path, prog, as_document: bool = False, *,
               convert: bool = False, cover: Path | None = None) -> None:
    """Upload a finished file: as playable video/audio when it is one, otherwise as a document; over-size files are split.
    convert: a yt-dlp download, so videos Telegram can't play are converted first. cover: audio's cover art."""
    meta = None
    if not as_document and (convert or path.suffix.lower() in VIDEO_EXT | AUDIO_EXT):
        meta = await media.probe(path)
        if convert and meta["video"]:
            path, meta = await media.prepare_video(path, meta, prog.convert)
    size = path.stat().st_size
    async with keep_clean(path):  # don't let reading a big file for upload fill the page cache
        if size > config.MAX_FILE_SIZE:
            return await _upload_split(client, chat_id, path, size, prog)
        ext, duration = path.suffix.lower(), int(meta["duration"]) if meta else 0
        kw = {"caption": path.name[:1024], "progress_callback": prog.upload}
        if meta and ext in VIDEO_EXT and meta["width"]:  # an .mp4 without a video stream can't be sent as a video
            await client.send_file(
                chat_id, str(path), supports_streaming=True,
                attributes=[DocumentAttributeVideo(duration=duration, w=meta["width"], h=meta["height"], supports_streaming=True)],
                thumb=await media.thumb(path, path.with_suffix(".thumb.jpg"), seek=3 if duration > 6 else 0), **kw)
        elif meta and ext in AUDIO_EXT:
            kw["caption"] = (" - ".join(x for x in (meta["artist"], meta["title"]) if x) or path.stem)[:1024]
            await client.send_file(
                chat_id, str(path),
                attributes=[DocumentAttributeAudio(duration=duration, title=meta["title"] or None, performer=meta["artist"] or None)],
                thumb=await media.thumb(cover, path.with_suffix(".thumb.jpg"), square=True) if cover else None, **kw)
        else:
            await client.send_file(chat_id, str(path), force_document=True, **kw)


class _Window(io.RawIOBase):
    """A read-only view of bytes [offset, offset+length) of a file, shaped like a small file of its own, so one part
    of a big file uploads straight from the original: no copy, no extra disk space. (Telethon accepts any seekable
    file object with a `name` and read.)"""

    def __init__(self, path: Path, offset: int, length: int, name: str):
        super().__init__()
        self.name = name
        self._f = open(path, "rb")
        self._offset, self._length, self._pos = offset, length, 0

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return True

    def tell(self) -> int:
        return self._pos

    def seek(self, pos: int, whence: int = io.SEEK_SET) -> int:
        self._pos = max(0, min((0, self._pos, self._length)[whence] + pos, self._length))
        return self._pos

    def read(self, n: int = -1) -> bytes:
        n = self._length - self._pos if n < 0 else min(n, self._length - self._pos)
        if n <= 0:
            return b""
        self._f.seek(self._offset + self._pos)
        data = self._f.read(n)
        self._pos += len(data)
        return data

    def close(self) -> None:
        self._f.close()
        super().close()


async def _upload_split(client, chat_id: int, path: Path, size: int, prog) -> None:
    """Upload an oversized file as name.ext.001, .002, ..., each read directly from the original file."""
    part_size = config.MAX_FILE_SIZE
    n = math.ceil(size / part_size)
    for i in range(n):
        name = f"{path.name}.{i + 1:03d}"
        prog.upload_label = f"⬆️ Uploading part {i + 1}/{n}"
        length = min(part_size, size - i * part_size)
        with _Window(path, i * part_size, length, name) as part:
            await client.send_file(chat_id, part, force_document=True, file_size=length, progress_callback=prog.upload,
                                   caption=f'{name}\nJoin: cat "{path.name}".* > "{path.name}"'[:1024])
