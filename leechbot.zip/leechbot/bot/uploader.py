import io
import math
from pathlib import Path

from . import config, media
from .utils import keep_clean

# Only containers Telegram plays inline reliably; mkv/webm/avi go as documents.
VIDEO_EXT = {".mp4", ".m4v", ".mov"}
AUDIO_EXT = {".mp3", ".m4a", ".flac", ".ogg", ".opus", ".wav", ".aac"}


async def send(client, chat_id: int, path: Path, prog, as_document: bool = False) -> None:
    """Upload a finished file, splitting it when it is over the per-upload limit."""
    if path.stat().st_size > config.MAX_FILE_SIZE:
        await _upload_split(client, chat_id, path, prog)
    else:
        await _upload(client, chat_id, path, prog.upload, as_document)


async def _upload(client, chat_id: int, path: Path, on_progress, as_document: bool) -> None:
    ext = path.suffix.lower()
    common = {"chat_id": chat_id, "caption": path.name[:1024], "progress": on_progress}
    meta = await media.probe(path) if not as_document and ext in VIDEO_EXT | AUDIO_EXT else None
    async with keep_clean(path):  # don't let reading a big file for upload fill the page cache
        if meta and ext in VIDEO_EXT and meta["width"]:  # an .mp4 without a video stream can't be sent as a video
            await client.send_video(
                video=str(path), duration=meta["duration"], width=meta["width"], height=meta["height"],
                thumb=await media.thumbnail(path, meta["duration"]), supports_streaming=True, **common,
            )
        elif meta and ext in AUDIO_EXT:
            await client.send_audio(
                audio=str(path), duration=meta["duration"],
                title=meta["title"] or None, performer=meta["artist"] or None, **common,
            )
        else:
            await client.send_document(document=str(path), force_document=True, **common)


class _Window(io.RawIOBase):
    """A read-only view of bytes [offset, offset+length) of a file, shaped like a small file of its own.

    Lets one part of a big file be uploaded straight from the original: no copy, no extra disk space,
    no extra I/O. (Pyrogram accepts any file object with a `name` and seek/tell/read.)"""

    def __init__(self, path: Path, offset: int, length: int, name: str):
        super().__init__()
        self.name = name
        self._f = open(path, "rb")
        self._offset, self._length, self._pos = offset, length, 0

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return True

    def tell(self) -> int:
        return self._pos

    def seek(self, pos: int, whence: int = io.SEEK_SET) -> int:
        base = (0, self._pos, self._length)[whence]
        self._pos = max(0, min(base + pos, self._length))
        return self._pos

    def read(self, n: int = -1) -> bytes:
        left = self._length - self._pos
        n = left if n < 0 else min(n, left)
        if n <= 0:
            return b""
        self._f.seek(self._offset + self._pos)
        data = self._f.read(n)
        self._pos += len(data)
        return data

    def close(self) -> None:
        self._f.close()
        super().close()


async def _upload_split(client, chat_id: int, path: Path, prog) -> None:
    """Upload an oversized file as name.ext.001, .002, ..., each read directly from the original file."""
    size, part_size = path.stat().st_size, config.MAX_FILE_SIZE
    n = math.ceil(size / part_size)
    join_hint = f'cat "{path.name}".* > "{path.name}"'
    async with keep_clean(path):
        for i in range(n):
            name = f"{path.name}.{i + 1:03d}"
            prog.upload_label = f"⬆️ Uploading part {i + 1}/{n}"
            with _Window(path, i * part_size, min(part_size, size - i * part_size), name) as part:
                await client.send_document(
                    chat_id=chat_id, document=part, file_name=name,
                    caption=f"{name}\nJoin: {join_hint}"[:1024], progress=prog.upload,
                )
