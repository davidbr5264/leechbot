"""Settings from the environment (systemd loads .env) or from the .env file when run by hand.
Required values stop the bot with a clear message; a bad optional value falls back to its default.
What each option does is documented in .env.example."""
import os
import re
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"
MiB = 1 << 20

try:
    for _line in ENV_FILE.read_text().splitlines():
        _k, _eq, _v = _line.partition("=")
        if _eq and _k.strip() and not _k.strip().startswith("#"):
            os.environ.setdefault(_k.strip(), _v)  # real environment variables win
except OSError:
    pass


def _get(name: str) -> str:
    return os.environ.get(name, "").strip().strip("\"'").strip()


def _required(name: str, pattern: str) -> str:
    value = _get(name)
    if not re.fullmatch(pattern, value):
        sys.exit(f"{'Missing' if not value else 'Invalid'} {name}. Set it in {ENV_FILE} (or run: leechbot settings).")
    return value


def _number(name: str, default: int, low: int, high: int) -> int:
    raw = _get(name)
    if raw:
        try:
            if low <= int(raw) <= high:
                return int(raw)
        except ValueError:
            pass
        print(f"warning: {name}={raw!r} is not a whole number from {low} to {high}; using {default}", file=sys.stderr)
    return default


API_ID = int(_required("API_ID", r"\d{1,15}"))
API_HASH = _required("API_HASH", r"[0-9a-fA-F]{32}")
BOT_TOKEN = _required("BOT_TOKEN", r"\d{5,}:[A-Za-z0-9_-]{30,}")
OWNER_ID = int(_required("OWNER_ID", r"\d{1,15}"))

DOWNLOAD_DIR = Path(_get("DOWNLOAD_DIR") or "/var/tmp/leechbot")
MAX_FILE_SIZE = _number("MAX_FILE_SIZE_MB", 1990, 50, 4000) * MiB      # one Telegram upload; bigger files are split
MAX_DOWNLOAD = _number("MAX_DOWNLOAD_MB", 8000, 100, 1_000_000) * MiB  # a whole download, before splitting
MIN_FREE_SPACE = _number("MIN_FREE_MB", 300, 0, 100_000) * MiB         # never push free disk below this
MIN_FREE_RAM_MB = _number("MIN_FREE_RAM_MB", 150, 0, 8000)             # wait for this much RAM before yt-dlp/ffmpeg
MAX_QUEUE = _number("MAX_QUEUE", 20, 1, 100)
YTDL_MAX_HEIGHT = _number("YTDL_MAX_HEIGHT", 1080, 144, 4320)
MAX_PLAYLIST_ITEMS = _number("MAX_PLAYLIST_ITEMS", 50, 1, 500)
FFMPEG_THREADS = _number("FFMPEG_THREADS", 2, 1, 16)
MAX_URLS_PER_MESSAGE = 5

COOKIES_FILE = Path(_get("COOKIES_FILE") or BASE_DIR / "cookies.txt")  # managed with /cookies
YTDL_SORT = _get("YTDL_SORT")  # optional extra yt-dlp format sort, e.g. "res:720"
if not re.fullmatch(r"[A-Za-z0-9:,+~*._-]*", YTDL_SORT):
    print(f"warning: YTDL_SORT={YTDL_SORT!r} has unsupported characters; ignoring it", file=sys.stderr)
    YTDL_SORT = ""
# VP9/AV1/HEVC videos are re-encoded to H.264 (what Telegram plays inline) unless this is 0.
YTDL_TRANSCODE = _get("YTDL_TRANSCODE").lower() not in ("0", "no", "off", "false")

SESSION = BASE_DIR / "leechbot-tl"          # Telethon appends .session
PROGRESS_INTERVAL = 7                       # seconds between progress edits (Telegram flood limits)
STATE_FILE = BASE_DIR / ".active_job.json"  # exists while a job runs, so a crash can name what was interrupted
PREFS_FILE = BASE_DIR / ".prefs.json"       # choices made in Telegram (/mode)
