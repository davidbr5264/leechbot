"""Settings, read once from the environment (systemd loads .env) or from the .env file when run by hand.

Required values stop the bot with a clear message. Malformed optional numbers fall back to their default
instead of crashing the service in a restart loop."""
import os
import re
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"
MiB = 1 << 20


def _load_env() -> None:
    try:
        lines = ENV_FILE.read_text().splitlines()
    except OSError:
        return
    for line in lines:
        key, sep, value = line.partition("=")
        key = key.strip()
        if sep and key and not key.startswith("#"):
            os.environ.setdefault(key, value)  # real environment variables win


def _get(name: str) -> str:
    return os.environ.get(name, "").strip().strip("\"'").strip()


def _warn(message: str) -> None:
    print(f"warning: {message}", file=sys.stderr)


def _required(name: str, pattern: str) -> str:
    value = _get(name)
    if not value:
        sys.exit(f"Missing {name}. Set it in {ENV_FILE} (or run: leechbot settings).")
    if not re.fullmatch(pattern, value):
        sys.exit(f"{name} in {ENV_FILE} doesn't look valid. Fix it (or run: leechbot settings).")
    return value


def _number(name: str, default: int, low: int, high: int) -> int:
    raw = _get(name)
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        _warn(f"{name}={raw!r} is not a whole number; using {default}")
        return default
    if not low <= value <= high:
        _warn(f"{name}={value} is outside {low}..{high}; using {default}")
        return default
    return value


_load_env()

API_ID = int(_required("API_ID", r"\d{1,15}"))
API_HASH = _required("API_HASH", r"[0-9a-fA-F]{32}")
BOT_TOKEN = _required("BOT_TOKEN", r"\d{5,}:[A-Za-z0-9_-]{30,}")
OWNER_ID = int(_required("OWNER_ID", r"\d{1,15}"))

DOWNLOAD_DIR = Path(_get("DOWNLOAD_DIR") or "/var/tmp/leechbot")
MAX_FILE_SIZE = _number("MAX_FILE_SIZE_MB", 1990, 50, 4000) * MiB    # one Telegram upload; bigger files are split
MAX_DOWNLOAD = _number("MAX_DOWNLOAD_MB", 8000, 100, 1_000_000) * MiB  # a whole download, before splitting
MIN_FREE_SPACE = _number("MIN_FREE_MB", 300, 0, 100_000) * MiB       # never push free disk below this
MIN_FREE_RAM_MB = _number("MIN_FREE_RAM_MB", 150, 0, 8000)           # wait for this much RAM before yt-dlp/ffmpeg
MAX_QUEUE = _number("MAX_QUEUE", 20, 1, 100)                         # jobs waiting at once
YTDL_MAX_HEIGHT = _number("YTDL_MAX_HEIGHT", 1080, 144, 4320)        # streams of unknown height are still allowed
MAX_PLAYLIST_ITEMS = _number("MAX_PLAYLIST_ITEMS", 50, 1, 500)
MAX_URLS_PER_MESSAGE = 5

COOKIES_FILE = Path(_get("COOKIES_FILE") or BASE_DIR / "cookies.txt")  # managed with /cookies
_sort = _get("YTDL_SORT")  # optional yt-dlp format sort, e.g. "vcodec:h264"
YTDL_SORT = _sort if re.fullmatch(r"[A-Za-z0-9:,+~*._-]+", _sort) else ""
if _sort and not YTDL_SORT:
    _warn(f"YTDL_SORT={_sort!r} has unsupported characters; ignoring it")

SESSION = BASE_DIR / "leechbot-tl"  # Telethon appends .session (not compatible with the old Pyrogram file)
PROGRESS_INTERVAL = 7  # seconds between progress edits (Telegram flood limits)
STATE_FILE = BASE_DIR / ".active_job.json"  # exists while a job runs, so a crash can name what was interrupted
PREFS_FILE = BASE_DIR / ".prefs.json"       # choices made in Telegram (/mode)
