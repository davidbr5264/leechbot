"""Give freed heap memory back to the OS after a job (a little: ~1 MB measured, but never negative)."""
import ctypes
import gc

_libc = None


def trim() -> None:
    global _libc
    gc.collect()
    try:
        if _libc is None:
            _libc = ctypes.CDLL("libc.so.6")
        _libc.malloc_trim(0)
    except (OSError, AttributeError):
        pass  # not glibc (e.g. Alpine/musl): nothing to trim
