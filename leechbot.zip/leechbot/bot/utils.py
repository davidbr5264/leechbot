"""Small helpers shared by every module."""
import asyncio
import contextlib
import ctypes
import gc
import ipaddress
import os
import re
import shutil
import socket
from pathlib import Path
from urllib.parse import urlparse


class JobError(Exception):
    """A user-facing error: the message is shown in the chat. fatal=True means the same failure would hit every
    remaining playlist item (disk full, out of memory, login wall), so playlist jobs stop."""

    def __init__(self, message: str, *, fatal: bool = False):
        super().__init__(message)
        self.fatal = fatal


async def safe_edit(msg, text: str, **kw) -> None:
    with contextlib.suppress(Exception):  # not-modified, flood wait, deleted message: never fail a job over an edit
        await msg.edit(text, **kw)


def human_size(n: float) -> str:
    if n < 1024:
        return f"{int(n)} B"
    for unit in ("KB", "MB", "GB"):
        n /= 1024
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}"


def human_time(seconds: float) -> str:
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h}h {m}m" if h else f"{m}m {s}s" if m else f"{s}s"


def safe_filename(name: str, default: str = "file") -> str:
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", name).strip(" .")
    limit = 180  # filesystems cap names at 255 *bytes*; the bot adds ".thumb.jpg" / ".001" next to the file
    if len(name.encode()) > limit:
        ext = Path(name).suffix
        ext = ext if len(ext.encode()) <= 10 else ""
        stem = name[: len(name) - len(ext)].encode()[: limit - len(ext.encode())].decode(errors="ignore")
        name = stem.rstrip(" .") + ext
    return name or default


_STAND_INS = str.maketrans({"⧸": "-", "⧹": "-", "｜": "-", "＂": "'", "＊": "", "＜": "", "＞": ""})


def pretty_filename(name: str) -> str:
    """yt-dlp writes forbidden characters as full-width look-alikes; turn them back into plain punctuation.
    Full-width ？ and ： are only touched after ASCII text, so genuine Japanese/Chinese punctuation survives."""
    p = Path(name)
    stem = p.stem.translate(_STAND_INS)
    stem = re.sub(r"(?<=[\x20-\x7e])：\s*", " - ", stem)
    stem = re.sub(r"(?<=[A-Za-z0-9])？", "", stem)
    if " " not in stem:
        stem = stem.replace("_", " ")
    stem = re.sub(r"\s{2,}", " ", stem).strip(" .-")
    return stem + p.suffix if stem else name


def free_space(path: Path) -> int:
    p = Path(path)
    while not p.exists() and p != p.parent:
        p = p.parent
    return shutil.disk_usage(p).free


def atomic_write(path: Path, data: str, mode: int = 0o644) -> None:
    tmp = path.with_name(path.name + ".tmp")
    with os.fdopen(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode), "w") as f:
        os.fchmod(f.fileno(), mode)  # O_CREAT's mode is ignored if a stale .tmp already exists
        f.write(data)
    os.replace(tmp, path)


def wipe(path: Path) -> None:
    """Delete a file or directory tree. Never raises: cleanup must not fail a job."""
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path, ignore_errors=True)
    else:
        path.unlink(missing_ok=True)


def trim_memory() -> None:
    """Give freed heap back to the OS after a job (glibc only; elsewhere this is a no-op)."""
    gc.collect()
    with contextlib.suppress(OSError, AttributeError):
        ctypes.CDLL("libc.so.6").malloc_trim(0)


# ---------- page cache ----------------------------------------------------------------
# The kernel caches every byte a transfer reads or writes; on a small server that fills RAM and the service's
# memory cap throttles everything. Once data is on disk, telling the kernel to forget it loses nothing.

def drop_cache(fd: int) -> None:
    with contextlib.suppress(AttributeError, OSError):
        os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)


def _flush_and_drop(target: Path) -> None:
    """Flush and drop the cached pages of a file, or of every file directly inside a directory."""
    try:
        with os.scandir(target) as entries:
            paths = [e.path for e in entries if e.is_file(follow_symlinks=False)]
    except NotADirectoryError:
        paths = [str(target)]
    except OSError:
        return
    for p in paths:
        with contextlib.suppress(OSError):  # vanished meanwhile, or the filesystem refuses
            fd = os.open(p, os.O_RDONLY)
            try:
                os.fdatasync(fd)  # dirty pages can't be dropped until they are on disk
                drop_cache(fd)
            finally:
                os.close(fd)


@contextlib.asynccontextmanager
async def keep_clean(target: Path, interval: float = 0.5):
    """While the block runs, flush and drop `target`'s cached pages every `interval` seconds (and once at the end)."""

    async def loop() -> None:
        while True:
            await asyncio.sleep(interval)
            await asyncio.to_thread(_flush_and_drop, target)

    task = asyncio.create_task(loop())
    try:
        yield
    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        await asyncio.to_thread(_flush_and_drop, target)


# ---------- SSRF protection -----------------------------------------------------------

def resolve_public(url: str) -> tuple[str, int, list[str]]:
    """Blocking. Validate an http(s) URL and resolve it; every address must be public. Returns (host, port, ips) so
    callers connect to the *validated* IP, which closes the DNS-rebinding gap between "check" and "connect"."""
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise JobError("Only http(s) URLs are supported.")
    try:
        port = p.port or (443 if p.scheme == "https" else 80)
    except ValueError:
        raise JobError("That URL has an invalid port.") from None
    try:
        infos = socket.getaddrinfo(p.hostname, port, type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise JobError("Could not resolve that host.") from None
    ips: list[str] = []
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if ip.version == 6 and ip.ipv4_mapped:  # ::ffff:127.0.0.1 must be judged as 127.0.0.1
            ip = ip.ipv4_mapped
        if not ip.is_global:
            raise JobError("Blocked: URL points to a private or local address.")
        if str(ip) not in ips:
            ips.append(str(ip))
    return p.hostname, port, ips


async def assert_safe_url(url: str) -> None:
    await asyncio.get_running_loop().run_in_executor(None, resolve_public, url)
