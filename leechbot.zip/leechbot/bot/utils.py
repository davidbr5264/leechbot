import asyncio
import contextlib
import ipaddress
import os
import re
import shutil
import socket
from pathlib import Path
from urllib.parse import urlparse


class JobError(Exception):
    """A user-facing error: the message is shown in the chat.

    fatal=True means the same failure would hit every remaining item of a playlist (disk full, out of
    memory, login wall), so playlist jobs stop instead of failing 50 times."""

    def __init__(self, message: str, *, fatal: bool = False):
        super().__init__(message)
        self.fatal = fatal


def human_size(n: float) -> str:
    if n < 1024:
        return f"{int(n)} B"
    units, i, n = ("KB", "MB", "GB"), 0, n / 1024
    while n >= 1024 and i < len(units) - 1:
        n, i = n / 1024, i + 1
    return f"{n:.1f} {units[i]}"


def human_time(seconds: float) -> str:
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h}h {m}m" if h else f"{m}m {s}s" if m else f"{s}s"


def safe_filename(name: str, default: str = "file") -> str:
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", name).strip(" .")
    # Filesystems limit names to 255 *bytes*, not characters (Cyrillic/CJK take 2-4 each). Stay well under:
    # the bot adds ".thumb.jpg" or ".001" next to the file.
    limit = 180
    if len(name.encode()) > limit:
        ext = Path(name).suffix
        ext = ext if len(ext.encode()) <= 10 else ""
        stem = name[: len(name) - len(ext)].encode()[: limit - len(ext.encode())].decode(errors="ignore")
        name = stem.rstrip(" .") + ext
    return name or default


def free_space(path: Path) -> int:
    """Free bytes on the filesystem holding `path` (or its nearest existing parent)."""
    p = Path(path)
    while not p.exists() and p != p.parent:
        p = p.parent
    return shutil.disk_usage(p).free


def atomic_write(path: Path, data: str, mode: int = 0o644) -> None:
    """Write via a temp file + rename, so a crash can't leave a half-written file."""
    tmp = path.with_name(path.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    with os.fdopen(fd, "w") as f:
        os.fchmod(f.fileno(), mode)  # O_CREAT's mode is ignored if a stale .tmp already exists
        f.write(data)
    os.replace(tmp, path)


def trim_memory() -> None:
    """Give freed heap back to the OS after a job. glibc's malloc_trim releases free pages even from the
    middle of a fragmented heap, which neither Python nor MALLOC_TRIM_THRESHOLD_ does."""
    import ctypes
    import gc

    gc.collect()
    with contextlib.suppress(OSError, AttributeError):  # not glibc (e.g. Alpine/musl): nothing to trim
        ctypes.CDLL("libc.so.6").malloc_trim(0)


# ---------- page cache and cleanup ---------------------------------------------------
# Linux caches every byte a file reads or writes. On a small server a multi-GB transfer fills RAM with that
# cache and the service's memory cap throttles everything. Once data is on disk, telling the kernel to forget
# it is safe: nothing is lost.

def drop_cache(fd: int, offset: int = 0, length: int = 0) -> None:
    with contextlib.suppress(AttributeError, OSError):  # unsupported platform/filesystem: harmless
        os.posix_fadvise(fd, offset, length, os.POSIX_FADV_DONTNEED)


def _drop_path(target: Path) -> None:
    """Flush and drop the cached pages of a file, or of every file directly inside a directory."""
    try:
        with os.scandir(target) as entries:
            paths = [e.path for e in entries if e.is_file(follow_symlinks=False)]
    except NotADirectoryError:
        paths = [str(target)]
    except OSError:
        return
    for p in paths:
        try:
            fd = os.open(p, os.O_RDONLY)
        except OSError:
            continue  # vanished meanwhile
        try:
            os.fdatasync(fd)  # dirty pages can't be dropped until they are on disk
            drop_cache(fd)
        except OSError:
            pass
        finally:
            os.close(fd)


@contextlib.asynccontextmanager
async def keep_clean(target: Path, interval: float = 0.5):
    """While the block runs, flush and drop `target`'s cached pages every `interval` seconds (and once at the end)."""

    async def loop() -> None:
        while True:
            await asyncio.sleep(interval)
            await asyncio.to_thread(_drop_path, target)

    task = asyncio.create_task(loop())
    try:
        yield
    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        await asyncio.to_thread(_drop_path, target)


def wipe(path: Path) -> None:
    """Delete a file or a whole directory tree. Never raises: cleanup must not fail a job."""
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path, ignore_errors=True)
    else:
        path.unlink(missing_ok=True)


# ---------- SSRF protection ----------------------------------------------------------

def resolve_public(url: str) -> tuple[str, int, list[str]]:
    """Blocking. Validate an http(s) URL and resolve it; every address must be public.

    Returns (host, port, ips) so callers can connect to the *validated* IP itself,
    which closes the DNS-rebinding gap between "check" and "connect"."""
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise JobError("Only http(s) URLs are supported.")
    try:
        port = p.port or (443 if p.scheme == "https" else 80)
    except ValueError:
        raise JobError("That URL has an invalid port.") from None
    try:
        infos = socket.getaddrinfo(p.hostname, port, type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise JobError("Could not resolve that host.") from None

    ips: list[str] = []
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if ip.version == 6 and ip.ipv4_mapped:  # ::ffff:127.0.0.1 must be judged as 127.0.0.1
            ip = ip.ipv4_mapped
        if not ip.is_global:
            raise JobError("Blocked: URL points to a private or local address.")
        if str(ip) not in ips:
            ips.append(str(ip))
    return p.hostname, port, ips


async def assert_safe_url(url: str) -> None:
    await asyncio.get_running_loop().run_in_executor(None, resolve_public, url)
