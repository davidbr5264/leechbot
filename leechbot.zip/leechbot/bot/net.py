"""Finding links in messages, deciding how to handle each, and the direct-URL downloader.

The downloader uses the standard library only (no aiohttp: it costs ~13 MB of RAM). The blocking transfer runs in
one worker thread; the async side polls its counters once a second for progress and can abort it. Features:
per-hop SSRF checks, connecting to the *validated* IP, Range-based resume, size/disk limits."""
import asyncio
import functools
import http.client
import mimetypes
import os
import re
import socket
import ssl
import threading
from dataclasses import dataclass
from email.message import Message
from pathlib import Path, PurePosixPath
from urllib.parse import quote, unquote, urljoin, urlsplit

from . import config
from .utils import JobError, drop_cache, free_space, human_size, pretty_filename, resolve_public, safe_filename

UA = "Mozilla/5.0 (X11; Linux x86_64) leechbot/0.1"
CHUNK = 128 * 1024
MAX_RETRIES = 5
BACKOFF = 3  # seconds * attempt number, capped at 15
FLUSH_EVERY = 16 << 20  # bytes written between flush + page-cache drops
DISK_CHECK_EVERY = 64 << 20  # bytes between free-space checks
REDIRECTS = (301, 302, 303, 307, 308)
_SAFE = "/%:@!$&'()*+,;=-._~"


class _Cancelled(Exception):
    pass


class _State:
    """Shared between the worker thread and the async side."""

    def __init__(self):
        self.done = self.total = 0
        self.cancel = threading.Event()
        self.sock = None

    def abort(self):
        self.cancel.set()
        if self.sock is not None:  # wake a thread blocked in recv()
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass


@dataclass
class Head:
    status: int
    content_type: str
    size: int  # 0 = unknown
    filename: str | None


# ---------- HTTP plumbing -----------------------------------------------------------------

def _target(parts) -> str:
    path = quote(parts.path or "/", safe=_SAFE)
    if not path.startswith("/"):
        path = "/" + path
    return path + ("?" + quote(parts.query, safe=_SAFE + "?") if parts.query else "")


def _cd_filename(value: str | None) -> str | None:
    if not value:
        return None
    msg = Message()
    msg["content-disposition"] = value
    name = msg.get_filename()
    if name:
        try:  # http.client decodes headers as latin-1, so a raw UTF-8 filename arrives as mojibake
            name = name.encode("latin-1").decode("utf-8")
        except UnicodeError:
            pass  # already proper text (e.g. from filename*=UTF-8''...)
    return name


def _filename(resp, final_url: str) -> str | None:
    """What the server (or the URL) calls the file."""
    return _cd_filename(resp.getheader("Content-Disposition")) or unquote(Path(urlsplit(final_url).path).name) or None


@functools.cache
def _tls() -> ssl.SSLContext:
    return ssl.create_default_context()  # loads the CA bundle once, not for every redirect hop


def _connect(url: str, st: _State):
    parts = urlsplit(url)
    host, port, ips = resolve_public(url)  # SSRF check on every hop
    try:
        header_host = host.encode("idna").decode("ascii")  # http.client needs an ASCII Host header
    except UnicodeError:
        raise JobError("That link has an invalid hostname.") from None
    sock, last = None, None
    for ip in ips:  # connect to the validated address, not whatever DNS says next time
        if st.cancel.is_set():
            raise _Cancelled
        try:
            sock = socket.create_connection((ip, port), timeout=30)
            break
        except OSError as e:
            last = e
    if sock is None:
        raise last or OSError("could not connect")
    sock.settimeout(60)
    if parts.scheme == "https":
        sock = _tls().wrap_socket(sock, server_hostname=host)
    conn = (http.client.HTTPSConnection if parts.scheme == "https" else http.client.HTTPConnection)(header_host, port, timeout=60)
    conn.sock = sock  # pre-connected: http.client won't resolve/connect again
    st.sock = sock
    return conn, parts


def _open(url: str, headers: dict, st: _State):
    """GET with manual redirects so every hop is validated. Returns (connection, response, final url)."""
    for _ in range(6):
        conn, parts = _connect(url, st)
        try:
            conn.request("GET", _target(parts),
                         headers={"User-Agent": UA, "Accept": "*/*", "Accept-Encoding": "identity", **headers})
            resp = conn.getresponse()
        except BaseException:
            conn.close()
            raise
        if resp.status not in REDIRECTS:
            return conn, resp, url
        loc = resp.getheader("Location")
        resp.close()
        conn.close()
        if not loc:
            raise JobError("Redirect without a Location header.")
        url = urljoin(url, loc)
    raise JobError("Too many redirects.")


# ---------- downloading -------------------------------------------------------------------

def _prepare(resp, final_url: str, name: str | None, dest_dir: Path) -> tuple[Path, int]:
    """First response only: check the limits and decide the file's name. Returns (path, total size or 0)."""
    cl = resp.getheader("Content-Length")
    total = int(cl) if cl and cl.isdigit() else 0
    if total > config.MAX_DOWNLOAD:
        raise JobError(f"File is {human_size(total)}; limit is {human_size(config.MAX_DOWNLOAD)}.")
    if total and free_space(dest_dir) < total + config.MIN_FREE_SPACE:
        raise JobError("Not enough free disk space for this file.", fatal=True)
    filename = name or _filename(resp, final_url) or "file"
    if not Path(filename).suffix:
        ctype = (resp.getheader("Content-Type") or "").split(";")[0].strip()
        filename += mimetypes.guess_extension(ctype) or ""
    filename = safe_filename(filename)
    return dest_dir / (filename if name else pretty_filename(filename)), total


def _write(resp, path: Path, mode: str, total: int, dest_dir: Path, st: _State) -> None:
    """Stream the body into `path`, keeping st.done current so a dropped connection can resume from it."""
    try:
        f = open(path, mode)
    except OSError as e:
        raise JobError(f"Can't write the download: {e.strerror or e}") from e
    with f:
        unflushed = since_disk_check = 0
        while chunk := resp.read1(CHUNK):
            try:
                f.write(chunk)
                unflushed += len(chunk)
                if unflushed >= FLUSH_EVERY:  # keep the page cache small (see utils.drop_cache)
                    f.flush()
                    os.fdatasync(f.fileno())
                    drop_cache(f.fileno())
                    unflushed = 0
            except OSError as e:
                raise JobError(f"Disk write failed: {e.strerror or e}", fatal=True) from e
            st.done += len(chunk)
            since_disk_check += len(chunk)
            if st.done > config.MAX_DOWNLOAD:
                raise JobError("Download exceeded the size limit; aborted.")
            if since_disk_check >= DISK_CHECK_EVERY:  # servers that don't announce a size can fill the disk
                since_disk_check = 0
                if free_space(dest_dir) < config.MIN_FREE_SPACE // 2:
                    raise JobError("The disk is almost full, so the download was stopped.", fatal=True)
            if st.cancel.is_set():
                raise _Cancelled
    if total and st.done < total:
        raise http.client.IncompleteRead(b"", total - st.done)


def _worker(url: str, dest_dir: Path, name: str | None, st: _State) -> Path:
    path: Path | None = None
    total = retries = 0
    while True:
        if st.cancel.is_set():
            raise _Cancelled
        progress_before = st.done
        conn = None
        try:
            conn, resp, final_url = _open(url, {"Range": f"bytes={st.done}-"} if st.done else {}, st)
            if resp.status == 206 and st.done:
                m = re.match(r"bytes (\d+)-", resp.getheader("Content-Range") or "")
                if not m or int(m.group(1)) != st.done:  # server resumed at the wrong offset
                    st.done = 0
                    continue
                mode = "ab"
            elif resp.status == 200:
                st.done, mode = 0, "wb"  # fresh start, or the server ignored Range
            else:
                raise JobError(f"Server returned HTTP {resp.status}.")
            if path is None:
                path, total = _prepare(resp, final_url, name, dest_dir)
                st.total = total
            _write(resp, path, mode, total, dest_dir, st)
            return path
        except ssl.SSLCertVerificationError as e:  # a bad certificate won't fix itself: no retry
            raise JobError(f"TLS certificate check failed: {e.verify_message or e}") from e
        except (http.client.HTTPException, OSError) as e:
            if st.cancel.is_set():
                raise _Cancelled from e
            if st.done > progress_before:
                retries = 0  # it moved forward before dropping: a long download may drop many times
            retries += 1
            if retries > MAX_RETRIES:
                raise JobError(f"Connection failed repeatedly ({type(e).__name__}).") from e
            st.cancel.wait(min(BACKOFF * retries, 15))  # back off, then resume with a Range request
        finally:
            if conn is not None:
                conn.close()
            st.sock = None


async def download(url: str, dest_dir: Path, name: str | None, on_progress) -> Path:
    st = _State()
    fut = asyncio.get_running_loop().run_in_executor(None, _worker, url, dest_dir, name, st)
    try:
        while True:
            finished, _ = await asyncio.wait({fut}, timeout=1.0)
            if finished:
                path = fut.result()
                await on_progress(st.done, st.total)
                return path
            await on_progress(st.done, st.total)
    except asyncio.CancelledError:
        st.abort()
        await asyncio.wait({fut}, timeout=5)  # let the thread stop before the caller deletes files
        if fut.done() and not fut.cancelled():
            fut.exception()  # mark retrieved
        raise


def _probe_blocking(url: str, st: _State) -> Head:
    conn, resp, final_url = _open(url, {"Range": "bytes=0-0"}, st)  # GET 0-0: works where HEAD is blocked
    try:
        ctype = (resp.getheader("Content-Type") or "").split(";")[0].strip().lower()
        size = 0
        if m := re.match(r"bytes \d+-\d+/(\d+)", resp.getheader("Content-Range") or ""):
            size = int(m.group(1))
        elif resp.status == 200:
            cl = resp.getheader("Content-Length")
            size = int(cl) if cl and cl.isdigit() else 0
        return Head(resp.status, ctype, size, _filename(resp, final_url))
    finally:
        conn.close()


async def probe(url: str) -> Head:
    """What does this URL serve? (content type, size, filename). Raises JobError for unsafe/unreachable URLs."""
    st = _State()
    fut = asyncio.get_running_loop().run_in_executor(None, _probe_blocking, url, st)
    try:
        return await asyncio.wait_for(fut, 45)
    except asyncio.TimeoutError:  # a different class from the builtin before Python 3.11
        st.abort()
        raise JobError("That server didn't answer in time.") from None
    except (http.client.HTTPException, OSError) as e:
        raise JobError(f"Couldn't reach that link ({type(e).__name__}).") from e
    except asyncio.CancelledError:
        st.abort()
        raise


# ---------- finding and classifying links ---------------------------------------------------

_URL_RE = re.compile(r"https?://[^\s<>\"'`]+", re.IGNORECASE)
_TRAILING = ".,;:!?)]}>'\"”’»…"
_NAME_RE = re.compile(r"^\s*(https?://\S+)\s*\|\s*(.+?)\s*$", re.DOTALL | re.IGNORECASE)

# Streams: yt-dlp understands these, a plain download would just fetch a tiny playlist.
STREAM_EXT = {".m3u8", ".mpd"}
# A URL ending in one of these is a file: download it as-is.
FILE_EXT = set(
    ".mp4 .m4v .mkv .webm .avi .mov .wmv .flv .ts .mpg .mpeg .3gp .ogv "
    ".mp3 .m4a .aac .flac .wav .ogg .opus .wma .aiff .alac "
    ".zip .rar .7z .tar .gz .tgz .bz2 .xz .zst .iso .img .dmg "
    ".pdf .epub .mobi .azw3 .doc .docx .xls .xlsx .ppt .pptx .txt .csv .json "
    ".apk .exe .msi .deb .rpm .appimage .bin .torrent "
    ".jpg .jpeg .png .gif .webp .bmp .tiff .svg .heic".split())
_HTML = ("text/html", "application/xhtml+xml")
# Playlist/manifest files served without a telltale extension: yt-dlp understands them, a plain download wouldn't.
_STREAM_TYPES = ("application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl", "audio/x-mpegurl",
                 "application/dash+xml")


@dataclass
class Verdict:
    kind: str  # "direct" | "ytdl"
    head: Head | None = None  # what the server said (links probed over the network)


def _trim(url: str) -> str:
    """Drop punctuation that belongs to the sentence, but keep a ')' that closes a '(' inside the URL."""
    while url and url[-1] in _TRAILING:
        if url[-1] == ")" and "(" in url:
            break
        url = url[:-1]
    return url


def extract_urls(text: str, entities=None) -> list[tuple[str, str | None]]:
    """[(url, custom_name)] in order of appearance. Handles hidden hyperlinks and `url | new_name.ext`."""
    found = [_trim(m.group(0)) for m in _URL_RE.finditer(text)]
    for e in entities or []:  # "text link" entities hide the URL behind words
        u = getattr(e, "url", None)
        if isinstance(u, str) and u.lower().startswith(("http://", "https://")):
            found.append(u)
    urls = list(dict.fromkeys(u for u in found if len(u) > 8))[: config.MAX_URLS_PER_MESSAGE]

    name = None
    if len(urls) == 1:
        m = _NAME_RE.match(text)
        if m and _trim(m.group(1)) == urls[0]:
            name = m.group(2).splitlines()[0].strip() or None
    return [(u, name if i == 0 else None) for i, u in enumerate(urls)]


async def classify(url: str) -> Verdict:
    """Cheapest check first: the file extension, then one tiny request to see what the server serves.

    A web page (HTML) goes to yt-dlp, which finds the video. This replaces matching every link against
    yt-dlp's ~1,800 extractors in a throwaway process, which cost ~48 MB and ~0.3 s per link."""
    ext = PurePosixPath(urlsplit(url).path).suffix.lower()
    if ext in STREAM_EXT:
        return Verdict("ytdl")
    if ext in FILE_EXT:
        return Verdict("direct")

    head = await probe(url)  # also rejects private/local addresses
    if head.status in (404, 410):
        raise JobError(f"That link returned HTTP {head.status}.")
    # Other errors (403, 429, 999...) are what video sites often answer to a bare request: let yt-dlp judge.
    if head.status >= 400 or head.content_type in _HTML + _STREAM_TYPES:
        return Verdict("ytdl", head=head)
    return Verdict("direct", head=head)
