import contextlib
import time

from . import config
from .utils import human_size, human_time


async def safe_edit(msg, text: str, **kw) -> None:
    with contextlib.suppress(Exception):  # not-modified, flood wait, deleted message: never fail a job over an edit
        await msg.edit(text, **kw)


def _bar(pct: float, width: int = 12) -> str:
    filled = int(width * pct / 100)
    return "█" * filled + "░" * (width - filled)


class Progress:
    """Edits one Telegram message with throttled progress updates."""

    def __init__(self, msg):
        self.msg = msg
        self.prefix = ""  # e.g. "📃 3/12: title\n" while working through a playlist
        self.upload_label = "⬆️ Uploading"
        self._stage = None
        self._t0 = self._last = 0.0
        self._prev = 0

    def begin_item(self, prefix: str) -> None:
        """Start a new playlist item: new heading, and speed/ETA restart from zero."""
        self.prefix, self.upload_label, self._stage = prefix, "⬆️ Uploading", None

    async def edit(self, text: str) -> None:
        await safe_edit(self.msg, self.prefix + text)

    async def _update(self, label: str, current: int, total: int) -> None:
        now = time.monotonic()
        # A new stage, or the counter dropping back (yt-dlp fetches video and audio as two streams): restart
        # the speed/ETA clock so it doesn't average over the previous stream.
        if label != self._stage or current < self._prev:
            self._stage, self._t0, self._last = label, now, 0.0
        self._prev = current
        if now - self._last < config.PROGRESS_INTERVAL and current != total:
            return
        self._last = now

        elapsed = now - self._t0
        speed = current / elapsed if elapsed >= 1 else 0  # too early for a meaningful speed
        lines = [label]
        if total:
            pct = min(current * 100 / total, 100)
            lines += [f"{_bar(pct)} {pct:.1f}%", f"{human_size(current)} / {human_size(total)}"]
            if speed:
                lines.append(f"{human_size(speed)}/s · ETA {human_time((total - current) / speed)}")
        else:
            lines.append(human_size(current) + (f" · {human_size(speed)}/s" if speed else ""))
        await self.edit("\n".join(lines))

    async def download(self, current: int, total: int) -> None:
        await self._update("⬇️ Downloading", current, total)

    async def convert(self, done: float, total: float) -> None:
        """Progress of the ffmpeg step that makes a download playable in Telegram (seconds of media done / total)."""
        now = time.monotonic()
        if self._stage != "convert":  # first update of this step: show it right away
            self._stage, self._last = "convert", 0.0
        elif now - self._last < config.PROGRESS_INTERVAL and done < total:
            return
        self._last = now
        pct = min(done * 100 / total, 100) if total else 0
        await self.edit(f"🎚 Converting for Telegram\n{_bar(pct)} {pct:.1f}%")

    async def upload(self, current: int, total: int) -> None:
        await self._update(self.upload_label, current, total)
