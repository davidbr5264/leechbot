"""Find URLs in a message and decide how to handle each one (no commands needed)."""
import re
from dataclasses import dataclass
from pathlib import PurePosixPath
from urllib.parse import urlsplit

from . import config
from .downloaders import direct
from .utils import JobError

_URL_RE = re.compile(r"https?://[^\s<>\"'`]+", re.IGNORECASE)
_TRAILING = ".,;:!?)]}>'\"”’»…"
_NAME_RE = re.compile(r"^\s*(https?://\S+)\s*\|\s*(.+?)\s*$", re.DOTALL | re.IGNORECASE)

# Streams: yt-dlp understands these, a plain download would just fetch a tiny playlist.
STREAM_EXT = {".m3u8", ".mpd"}
# A URL ending in one of these is a file: download it as-is.
FILE_EXT = {
    ".mp4", ".m4v", ".mkv", ".webm", ".avi", ".mov", ".wmv", ".flv", ".ts", ".mpg", ".mpeg", ".3gp", ".ogv",
    ".mp3", ".m4a", ".aac", ".flac", ".wav", ".ogg", ".opus", ".wma", ".aiff", ".alac",
    ".zip", ".rar", ".7z", ".tar", ".gz", ".tgz", ".bz2", ".xz", ".zst", ".iso", ".img", ".dmg",
    ".pdf", ".epub", ".mobi", ".azw3", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".csv", ".json",
    ".apk", ".exe", ".msi", ".deb", ".rpm", ".appimage", ".bin", ".torrent",
    ".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tiff", ".svg", ".heic",
}
_HTML = ("text/html", "application/xhtml+xml")
# Playlist/manifest files served without a telltale extension: yt-dlp understands them, a plain download wouldn't.
_STREAM_TYPES = ("application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl", "audio/x-mpegurl",
                 "application/dash+xml")


@dataclass
class Verdict:
    kind: str  # "direct" | "ytdl"
    head: direct.Head | None = None  # what the server said (links probed over the network)


def _trim(url: str) -> str:
    """Drop punctuation that belongs to the sentence, but keep a ')' that closes a '(' inside the URL."""
    while url and url[-1] in _TRAILING:
        if url[-1] == ")" and "(" in url:
            break
        url = url[:-1]
    return url


def extract_urls(text: str, entities=None) -> list[tuple[str, str | None]]:
    """[(url, custom_name)] in order of appearance. Handles hidden hyperlinks and `url | new_name.ext`."""
    found = [_trim(m.group(0)) for m in _URL_RE.finditer(text)]
    for e in entities or []:  # "text link" entities hide the URL behind words
        u = getattr(e, "url", None)
        if isinstance(u, str) and u.lower().startswith(("http://", "https://")):
            found.append(u)
    urls = list(dict.fromkeys(u for u in found if len(u) > 8))[: config.MAX_URLS_PER_MESSAGE]

    name = None
    if len(urls) == 1:
        m = _NAME_RE.match(text)
        if m and _trim(m.group(1)) == urls[0]:
            name = m.group(2).splitlines()[0].strip() or None
    return [(u, name if i == 0 else None) for i, u in enumerate(urls)]


async def classify(url: str) -> Verdict:
    """Cheapest check first: the file extension, then one tiny request to see what the server serves.

    A web page (HTML) goes to yt-dlp, which finds the video. This replaces matching every link against
    yt-dlp's ~1,800 extractors in a throwaway process, which cost ~48 MB and ~0.3 s per link."""
    ext = PurePosixPath(urlsplit(url).path).suffix.lower()
    if ext in STREAM_EXT:
        return Verdict("ytdl")
    if ext in FILE_EXT:
        return Verdict("direct")

    head = await direct.probe(url)  # also rejects private/local addresses
    if head.status in (404, 410):
        raise JobError(f"That link returned HTTP {head.status}.")
    # Other errors (403, 429, 999...) are what video sites often answer to a bare request: let yt-dlp judge.
    if head.status >= 400 or head.content_type in _HTML + _STREAM_TYPES:
        return Verdict("ytdl", head=head)
    return Verdict("direct", head=head)
