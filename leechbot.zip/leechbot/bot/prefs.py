"""Tiny persistent preference: what video-site links do.

"ask" shows Video / Audio buttons for every link; "video" and "audio" skip the question."""
import json

from . import config
from .utils import atomic_write

MODES = ("ask", "video", "audio")


def get_mode() -> str:
    try:
        mode = json.loads(config.PREFS_FILE.read_text()).get("mode")
    except (OSError, ValueError, AttributeError):
        return MODES[0]
    return mode if mode in MODES else MODES[0]


def set_mode(mode: str) -> None:
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}")
    atomic_write(config.PREFS_FILE, json.dumps({"mode": mode}))
