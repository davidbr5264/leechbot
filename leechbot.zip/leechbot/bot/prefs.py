"""Tiny persistent preferences, so a choice made in Telegram survives restarts.

Right now there is one: what video-site links do. "ask" shows Video / Audio buttons for every link,
"video" and "audio" skip the question and always download that kind."""
import json
import os

from . import config

MODES = ("ask", "video", "audio")
DEFAULT_MODE = "ask"


def _read() -> dict:
    try:
        data = json.loads(config.PREFS_FILE.read_text())
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def get_mode() -> str:
    mode = _read().get("mode")
    return mode if mode in MODES else DEFAULT_MODE


def set_mode(mode: str) -> str:
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}")
    data = _read()
    data["mode"] = mode
    tmp = config.PREFS_FILE.with_name(config.PREFS_FILE.name + ".tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, config.PREFS_FILE)  # atomic: a crash can't leave a half-written file
    return mode


def toggle_mode() -> str:
    return set_mode(MODES[(MODES.index(get_mode()) + 1) % len(MODES)])
