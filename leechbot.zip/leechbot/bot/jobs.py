"""The job queue. One job runs at a time, which is what keeps memory use flat."""
import asyncio
import contextlib
import itertools
import json
import logging
from dataclasses import dataclass
from pathlib import Path

from . import config, procs, uploader
from .downloaders import direct, ytdlp
from .progress import Progress, safe_edit
from .utils import JobError, trim_memory, wipe

log = logging.getLogger("leechbot")


@dataclass
class Job:
    id: int
    kind: str  # "leech" (direct file) | "ytdl"
    url: str
    chat_id: int
    msg: object  # the status message we keep editing
    name: str | None = None
    as_document: bool = False
    audio: bool = False  # ytdl only: best audio instead of video
    playlist: ytdlp.PlaylistInfo | None = None  # ytdl only: download all of these, one at a time


queue: asyncio.Queue[Job] = asyncio.Queue()
active: Job | None = None
_task: asyncio.Task | None = None  # the running job
_worker: asyncio.Task | None = None
_stopping = False
_ids = itertools.count(1)


def is_full() -> bool:
    return queue.qsize() >= config.MAX_QUEUE


def queue_text() -> str:
    ahead = queue.qsize() + (active is not None)
    return f"🕐 Queued (position {ahead + 1})" if ahead else "🚀 Starting…"


def submit(kind: str, url: str, chat_id: int, msg, **options) -> None:
    queue.put_nowait(Job(next(_ids), kind, url, chat_id, msg, **options))


async def cancel(clear_queue: bool) -> tuple[bool, int]:
    """Stop the running job and optionally drop the waiting ones. Returns (stopped a job, dropped count)."""
    dropped = 0
    while clear_queue and not queue.empty():
        await safe_edit(queue.get_nowait().msg, "❌ Cancelled")
        dropped += 1
    running = _task is not None and not _task.done()
    if running:
        _task.cancel()
    return running, dropped


# ---------- doing the work -----------------------------------------------------------

async def _fetch(job: Job, url: str, dest: Path, prog: Progress, scratch: Path) -> tuple[Path, bool]:
    """Download one item into `dest`. Returns (file, the link turned out to be a playlist)."""
    if job.kind != "ytdl":
        return await direct.download(url, dest, job.name, prog.download), False
    got = await ytdlp.download(url, dest, prog.download, on_wait=prog.edit, audio=job.audio,
                               convert=not job.as_document, on_convert=prog.convert, scratch=scratch)
    return got.path, got.was_playlist


async def _process_playlist(client, job: Job, workdir: Path, prog: Progress) -> str:
    """Download and upload the videos one at a time (one item on disk at once), skipping any that fail."""
    info = job.playlist
    n = len(info.entries)
    sent, failed, stopped = 0, [], ""
    for i, (title, url) in enumerate(info.entries, 1):
        prog.begin_item(f"📃 {i}/{n}: {title[:60]}\n")
        item_dir = workdir / f"{i:03d}"
        item_dir.mkdir(parents=True, exist_ok=True)
        try:
            path, _ = await _fetch(job, url, item_dir, prog, workdir / ".scratch")
            await uploader.send(client, job.chat_id, path, prog, job.as_document)
            sent += 1
        except Exception as e:  # one bad video (download or upload) must not sink the rest
            if not isinstance(e, JobError):
                log.exception("playlist item %s failed", i)
            failed.append((title, str(e) or type(e).__name__))
            if getattr(e, "fatal", False):
                stopped = f"\nStopped after video {i} of {n}, because the next ones would fail the same way."
                break
        finally:
            wipe(item_dir)  # free the disk before the next video
    prog.begin_item("")
    head = info.title[:60]
    text = f"✅ Playlist done: {sent} of {n} sent ({head})" if sent else f"❌ Playlist failed: nothing was sent ({head})"
    if info.truncated:
        text += f"\nThe playlist has more videos; only the first {n} were taken (MAX_PLAYLIST_ITEMS)."
    if failed:
        text += f"\n\n{len(failed)} failed:\n" + "\n".join(f"- {t[:50]}: {e.splitlines()[0][:100]}" for t, e in failed[:5])
        if len(failed) > 5:
            text += f"\n…and {len(failed) - 5} more"
    return (text + stopped)[:4000]


async def _process(client, job: Job) -> None:
    """Run one job. Everything it creates (downloads, converted files, thumbnails, temp files, yt-dlp's
    cache) lives under one folder, which is deleted however the job ends: done, failed or cancelled."""
    workdir = config.DOWNLOAD_DIR / f"job_{job.id}"
    workdir.mkdir(parents=True, exist_ok=True)
    prog = Progress(job.msg)
    try:
        if job.playlist:
            await prog.edit(await _process_playlist(client, job, workdir, prog))
            return
        path, was_playlist = await _fetch(job, job.url, workdir, prog, workdir / ".scratch")
        await uploader.send(client, job.chat_id, path, prog, job.as_document)
        note = "\n(That link is a playlist: only its first video was downloaded.)" if was_playlist else ""
        await prog.edit(f"✅ Done: {path.name}{note}")
    except asyncio.CancelledError:
        await prog.edit("♻️ The bot is restarting. Send the link again." if _stopping else "❌ Cancelled")
    except JobError as e:
        await prog.edit(f"❌ {e}")
    except MemoryError:
        await prog.edit(procs.OOM_MESSAGE)
    except Exception as e:
        log.exception("job %s failed", job.id)
        await prog.edit(f"❌ {type(e).__name__}: {str(e)[:300]}")
    finally:
        wipe(workdir)  # always free the disk


async def _run_worker(client) -> None:
    global active, _task
    while True:
        job = await queue.get()
        active = job
        _mark(job)
        _task = asyncio.create_task(_process(client, job))
        try:
            await _task
        except Exception:
            log.exception("worker error")
        finally:
            active = _task = None
            _unmark()
            queue.task_done()
            trim_memory()  # the job's folder is already gone; now hand freed heap back to the OS too


def start(client) -> None:
    global _worker
    _worker = asyncio.create_task(_run_worker(client))


async def stop() -> None:
    """Shutting down: let the running job say 'restarting' and clean its files."""
    global _stopping
    _stopping = True
    if _task is not None:
        _task.cancel()
        await asyncio.wait({_task}, timeout=5)
    if _worker is not None:
        _worker.cancel()


# ---------- crash notice and cleanup -------------------------------------------------

def _mark(job: Job) -> None:
    """Exists while a job runs, so a crash/restart can tell you what was interrupted."""
    with contextlib.suppress(OSError):
        config.STATE_FILE.write_text(json.dumps({"url": job.url}))


def _unmark() -> None:
    with contextlib.suppress(OSError):
        config.STATE_FILE.unlink(missing_ok=True)


async def notify_interrupted(app) -> None:
    """If the last run died mid-job (crash, OOM kill, reboot), say so instead of failing silently."""
    try:
        data = json.loads(config.STATE_FILE.read_text())
    except (OSError, ValueError):
        return
    _unmark()
    text = (
        "♻️ I was restarted while working on:\n"
        f"{str(data.get('url', '?'))[:200]}\n"
        "If it didn't finish, send the link again. If this keeps happening, check /status for memory."
    )
    try:
        await app.send_message(config.OWNER_ID, text)
    except Exception:
        log.warning("couldn't notify the owner about the interrupted job", exc_info=True)


_OWN_FILES = ("job_*", "cookies_upload_*", "*.cookies")  # what this bot creates in DOWNLOAD_DIR


def sweep_orphans() -> None:
    """Leftovers from a crashed run. Only our own names are touched: DOWNLOAD_DIR may be a shared folder."""
    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    for pattern in _OWN_FILES:
        for p in config.DOWNLOAD_DIR.glob(pattern):
            wipe(p)
