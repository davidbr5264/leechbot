"""The job queue. One job runs at a time, which is what keeps memory use flat."""
import asyncio
import itertools
import json
import logging
import shutil
import time
from dataclasses import dataclass
from pathlib import Path

from pyrogram import Client

from . import config, procs, uploader
from .downloaders import direct, ytdlp
from .progress import Progress, safe_edit
from .utils import JobError, trim_memory

log = logging.getLogger("leechbot")


@dataclass
class Job:
    id: int
    kind: str  # "leech" (direct file) | "ytdl"
    url: str
    chat_id: int
    msg: object  # the status message we keep editing
    name: str | None = None
    as_document: bool = False
    audio: bool = False  # ytdl only: best audio instead of video
    playlist: ytdlp.PlaylistInfo | None = None  # ytdl only: download all of these, one at a time


queue: asyncio.Queue[Job] = asyncio.Queue()
active: Job | None = None
_task: asyncio.Task | None = None  # the running job
_worker: asyncio.Task | None = None
_stopping = False
_ids = itertools.count(1)


def is_full() -> bool:
    return queue.qsize() >= config.MAX_QUEUE


def queue_text() -> str:
    ahead = queue.qsize() + (active is not None)
    return f"🕐 Queued (position {ahead + 1})" if ahead else "🚀 Starting…"


def submit(kind: str, url: str, chat_id: int, msg, **options) -> None:
    queue.put_nowait(Job(next(_ids), kind, url, chat_id, msg, **options))


async def cancel(clear_queue: bool) -> tuple[bool, int]:
    """Stop the running job and optionally drop the waiting ones. Returns (stopped a job, dropped count)."""
    dropped = 0
    while clear_queue and not queue.empty():
        await safe_edit(queue.get_nowait().msg, "❌ Cancelled")
        dropped += 1
    running = _task is not None and not _task.done()
    if running:
        _task.cancel()
    return running, dropped


# ---------- doing the work -----------------------------------------------------------

def _fatal_for_playlist(msg: str) -> bool:
    """Errors that would just repeat for every remaining video: stop instead of failing 50 times."""
    return msg == procs.OOM_MESSAGE or "disk" in msg.lower() or "🍪" in msg


async def _process_playlist(client: Client, job: Job, workdir: Path, prog: Progress) -> str:
    """Download and upload the videos one at a time (one item on disk at once), skipping any that fail."""
    info = job.playlist
    n = len(info.entries)
    sent, failed, stopped = 0, [], ""
    for i, (title, url) in enumerate(info.entries, 1):
        prog.begin_item(f"📃 {i}/{n}: {title[:60]}\n")
        item_dir = workdir / f"{i:03d}"
        item_dir.mkdir(parents=True, exist_ok=True)
        try:
            got = await ytdlp.download(url, item_dir, prog.download, on_wait=prog.edit, audio=job.audio)
            await uploader.send(client, job.chat_id, got.path, prog, job.as_document)
            sent += 1
        except JobError as e:
            failed.append((title, str(e)))
            if _fatal_for_playlist(str(e)):
                stopped = f"\nStopped after video {i} of {n}, because the next ones would fail the same way."
                break
        finally:
            shutil.rmtree(item_dir, ignore_errors=True)  # free the disk before the next video
    prog.begin_item("")
    head = info.title[:60]
    text = f"✅ Playlist done: {sent} of {n} sent ({head})" if sent else f"❌ Playlist failed: nothing was sent ({head})"
    if info.truncated:
        text += f"\nThe playlist has more videos; only the first {n} were taken (MAX_PLAYLIST_ITEMS)."
    if failed:
        text += f"\n\n{len(failed)} failed:\n" + "\n".join(f"- {t[:50]}: {e.splitlines()[0][:100]}" for t, e in failed[:5])
        if len(failed) > 5:
            text += f"\n…and {len(failed) - 5} more"
    return (text + stopped)[:4000]


async def _process(client: Client, job: Job) -> None:
    workdir = config.DOWNLOAD_DIR / f"job_{job.id}"
    workdir.mkdir(parents=True, exist_ok=True)
    prog = Progress(job.msg)
    try:
        if job.playlist:
            await prog.edit(await _process_playlist(client, job, workdir, prog))
            return
        note = ""
        if job.kind == "ytdl":
            got = await ytdlp.download(job.url, workdir, prog.download, on_wait=prog.edit, audio=job.audio)
            path = got.path
            if got.was_playlist:
                note = "\n(That link is a playlist: only its first video was downloaded.)"
        else:
            path = await direct.download(job.url, workdir, job.name, prog.download)
        await uploader.send(client, job.chat_id, path, prog, job.as_document)
        await prog.edit(f"✅ Done: {path.name}{note}")
    except asyncio.CancelledError:
        await prog.edit("♻️ The bot is restarting. Send the link again." if _stopping else "❌ Cancelled")
    except JobError as e:
        await prog.edit(f"❌ {e}")
    except MemoryError:
        await prog.edit(procs.OOM_MESSAGE)
    except Exception as e:
        log.exception("job %s failed", job.id)
        await prog.edit(f"❌ {type(e).__name__}: {str(e)[:300]}")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)  # always free the disk


async def _run_worker(client: Client) -> None:
    global active, _task
    while True:
        job = await queue.get()
        active = job
        _mark(job)
        _task = asyncio.create_task(_process(client, job))
        try:
            await _task
        except Exception:
            log.exception("worker error")
        finally:
            active = _task = None
            _unmark()
            queue.task_done()
            trim_memory()


def start(client: Client) -> None:
    global _worker
    _worker = asyncio.create_task(_run_worker(client))


async def stop() -> None:
    """Shutting down: let the running job say 'restarting' and clean its files."""
    global _stopping
    _stopping = True
    if _task is not None:
        _task.cancel()
        await asyncio.wait({_task}, timeout=5)
    if _worker is not None:
        _worker.cancel()


# ---------- crash notice and cleanup -------------------------------------------------

def _mark(job: Job) -> None:
    """Exists while a job runs, so a crash/restart can tell you what was interrupted."""
    try:
        config.STATE_FILE.write_text(json.dumps({"url": job.url, "t": time.time()}))
    except OSError:
        pass


def _unmark() -> None:
    try:
        config.STATE_FILE.unlink(missing_ok=True)
    except OSError:
        pass


async def notify_interrupted(app: Client) -> None:
    """If the last run died mid-job (crash, OOM kill, reboot), say so instead of failing silently."""
    try:
        data = json.loads(config.STATE_FILE.read_text())
    except (OSError, ValueError):
        return
    _unmark()
    text = (
        "♻️ I was restarted while working on:\n"
        f"{str(data.get('url', '?'))[:200]}\n"
        "If it didn't finish, send the link again. If this keeps happening, check /status for memory."
    )
    try:
        await app.send_message(config.OWNER_ID, text)
    except Exception:
        log.warning("couldn't notify the owner about the interrupted job")


def sweep_orphans() -> None:
    """Leftovers from a crashed run."""
    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    for p in config.DOWNLOAD_DIR.iterdir():
        shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True)
