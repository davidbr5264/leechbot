"""The job queue (one job at a time keeps memory flat) and the progress messages."""
import asyncio
import contextlib
import itertools
import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path

from . import config, net, system, uploader, ytdlp
from .utils import JobError, human_size, human_time, safe_edit, trim_memory, wipe

log = logging.getLogger("leechbot")


# ---------- progress messages ---------------------------------------------------------

def _bar(pct: float, width: int = 12) -> str:
    filled = int(width * pct / 100)
    return "█" * filled + "░" * (width - filled)


def _transfer_text(label: str, current: int, total: int, elapsed: float) -> str:
    speed = current / elapsed if elapsed >= 1 else 0  # too early for a meaningful speed
    if not total:
        return f"{label}\n{human_size(current)}" + (f" · {human_size(speed)}/s" if speed else "")
    pct = min(current * 100 / total, 100)
    lines = [label, f"{_bar(pct)} {pct:.1f}%", f"{human_size(current)} / {human_size(total)}"]
    if speed:
        lines.append(f"{human_size(speed)}/s · ETA {human_time((total - current) / speed)}")
    return "\n".join(lines)


class Progress:
    """Edits one Telegram message with throttled progress updates."""

    def __init__(self, msg):
        self.msg = msg
        self.prefix = ""  # e.g. "📃 3/12: title\n" while working through a playlist
        self.upload_label = "⬆️ Uploading"
        self._stage = None
        self._t0 = self._last = 0.0
        self._prev = 0

    def begin_item(self, prefix: str) -> None:
        """Start a new playlist item: new heading, and speed/ETA restart from zero."""
        self.prefix, self.upload_label, self._stage = prefix, "⬆️ Uploading", None

    async def edit(self, text: str) -> None:
        await safe_edit(self.msg, self.prefix + text)

    async def _tick(self, stage: str, current: float, total: float, render) -> None:
        """Send render(elapsed) unless this stage updated less than PROGRESS_INTERVAL ago (first and final updates
        always go out). A new stage, or the counter dropping back (yt-dlp fetches video and audio as two streams),
        restarts the speed/ETA clock."""
        now = time.monotonic()
        if stage != self._stage or current < self._prev:
            self._stage, self._t0, self._last = stage, now, 0.0
        self._prev = current
        if now - self._last >= config.PROGRESS_INTERVAL or current == total:
            self._last = now
            await self.edit(render(now - self._t0))

    async def download(self, current: int, total: int) -> None:
        await self._tick("down", current, total, lambda e: _transfer_text("⬇️ Downloading", current, total, e))

    async def upload(self, current: int, total: int) -> None:
        await self._tick(self.upload_label, current, total, lambda e: _transfer_text(self.upload_label, current, total, e))

    async def convert(self, done: float, total: float) -> None:
        """ffmpeg step that makes a download playable in Telegram (seconds of media done / total)."""
        pct = min(done * 100 / total, 100) if total else 0
        await self._tick("convert", done, total, lambda _: f"🎚 Converting for Telegram\n{_bar(pct)} {pct:.1f}%")


@dataclass
class Job:
    id: int
    kind: str  # "leech" (direct file) | "ytdl"
    url: str
    chat_id: int
    msg: object  # the status message we keep editing
    name: str | None = None
    as_document: bool = False
    audio: bool = False  # ytdl only: best audio instead of video
    playlist: ytdlp.PlaylistInfo | None = None  # ytdl only: download all of these, one at a time


queue: asyncio.Queue[Job] = asyncio.Queue()
active: Job | None = None
_task: asyncio.Task | None = None  # the running job
_worker: asyncio.Task | None = None
_stopping = False
_ids = itertools.count(1)


def is_full() -> bool:
    return queue.qsize() >= config.MAX_QUEUE


def queue_text() -> str:
    ahead = queue.qsize() + (active is not None)
    return f"🕐 Queued (position {ahead + 1})" if ahead else "🚀 Starting…"


def submit(kind: str, url: str, chat_id: int, msg, **options) -> None:
    queue.put_nowait(Job(next(_ids), kind, url, chat_id, msg, **options))


async def cancel(clear_queue: bool) -> tuple[bool, int]:
    """Stop the running job and optionally drop the waiting ones. Returns (stopped a job, dropped count)."""
    dropped = 0
    while clear_queue and not queue.empty():
        await safe_edit(queue.get_nowait().msg, "❌ Cancelled")
        dropped += 1
    running = _task is not None and not _task.done()
    if running:
        _task.cancel()
    return running, dropped


# ---------- doing the work ------------------------------------------------------------

async def _deliver(client, job: Job, url: str, dest: Path, prog: Progress, scratch: Path) -> bool:
    """Download one item into `dest` and upload it. Returns True when the link turned out to be a playlist."""
    if job.kind != "ytdl":
        await uploader.send(client, job.chat_id, await net.download(url, dest, job.name, prog.download), prog, job.as_document)
        return False
    path, cover, was_playlist = await ytdlp.download(url, dest, prog.download, on_status=prog.edit, audio=job.audio, scratch=scratch)
    await uploader.send(client, job.chat_id, path, prog, job.as_document, convert=True, cover=cover)
    return was_playlist


async def _process_playlist(client, job: Job, workdir: Path, prog: Progress) -> str:
    """Download and upload the videos one at a time (one item on disk at once), skipping any that fail."""
    info = job.playlist
    n = len(info.entries)
    sent, failed, stopped = 0, [], ""
    for i, (title, url) in enumerate(info.entries, 1):
        prog.begin_item(f"📃 {i}/{n}: {title[:60]}\n")
        item_dir = workdir / f"{i:03d}"
        item_dir.mkdir(parents=True, exist_ok=True)
        try:
            await _deliver(client, job, url, item_dir, prog, workdir / ".scratch")
            sent += 1
        except Exception as e:  # one bad video (download or upload) must not sink the rest
            if not isinstance(e, JobError):
                log.exception("playlist item %s failed", i)
            failed.append((title, str(e) or type(e).__name__))
            if getattr(e, "fatal", False):
                stopped = f"\nStopped after video {i} of {n}, because the next ones would fail the same way."
                break
        finally:
            wipe(item_dir)  # free the disk before the next video
    prog.begin_item("")
    if sent == n and not info.truncated:
        return ""  # everything arrived: nothing to report
    head = info.title[:60]
    text = (f"{'⚠️' if failed else 'ℹ️'} Playlist: {sent} of {n} sent ({head})" if sent
            else f"❌ Playlist failed: nothing was sent ({head})")
    if info.truncated:
        text += f"\nThe playlist has more videos; only the first {n} were taken (MAX_PLAYLIST_ITEMS)."
    if failed:
        text += f"\n\n{len(failed)} failed:\n" + "\n".join(f"- {t[:50]}: {e.splitlines()[0][:100]}" for t, e in failed[:5])
        if len(failed) > 5:
            text += f"\n…and {len(failed) - 5} more"
    return (text + stopped)[:4000]


async def _process(client, job: Job) -> None:
    """Run one job. Everything it creates lives under one folder, deleted however the job ends."""
    workdir = config.DOWNLOAD_DIR / f"job_{job.id}"
    workdir.mkdir(parents=True, exist_ok=True)
    prog = Progress(job.msg)
    try:
        if job.playlist:
            report = await _process_playlist(client, job, workdir, prog)
        else:
            was_playlist = await _deliver(client, job, job.url, workdir, prog, workdir / ".scratch")
            report = "ℹ️ That link is a playlist: only its first video was downloaded." if was_playlist else ""
        if report:
            await prog.edit(report)
        else:  # success needs no message: remove the progress one
            with contextlib.suppress(Exception):
                await job.msg.delete()
    except asyncio.CancelledError:
        await prog.edit("♻️ The bot is restarting. Send the link again." if _stopping else "❌ Cancelled")
    except JobError as e:
        await prog.edit(f"❌ {e}")
    except MemoryError:
        await prog.edit(system.OOM_MESSAGE)
    except Exception as e:
        log.exception("job %s failed", job.id)
        await prog.edit(f"❌ {type(e).__name__}: {str(e)[:300]}")
    finally:
        wipe(workdir)


async def _run_worker(client) -> None:
    global active, _task
    while True:
        job = await queue.get()
        active = job
        with contextlib.suppress(OSError):  # exists while a job runs, so a restart can tell you what was interrupted
            config.STATE_FILE.write_text(json.dumps({"url": job.url}))
        _task = asyncio.create_task(_process(client, job))
        try:
            await _task
        except Exception:
            log.exception("worker error")
        finally:
            active = _task = None
            config.STATE_FILE.unlink(missing_ok=True)
            queue.task_done()
            trim_memory()  # the job's folder is already gone; hand freed heap back to the OS too


def start(client) -> None:
    global _worker
    _worker = asyncio.create_task(_run_worker(client))


async def stop() -> None:
    """Shutting down: let the running job say 'restarting' and clean its files."""
    global _stopping
    _stopping = True
    if _task is not None:
        _task.cancel()
        await asyncio.wait({_task}, timeout=5)
    if _worker is not None:
        _worker.cancel()


# ---------- crash notice and cleanup --------------------------------------------------

async def notify_interrupted(client) -> None:
    """If the last run died mid-job (crash, OOM kill, reboot), say so instead of failing silently."""
    try:
        url = json.loads(config.STATE_FILE.read_text()).get("url", "?")
    except (OSError, ValueError, AttributeError):
        return
    config.STATE_FILE.unlink(missing_ok=True)
    try:
        await client.send_message(config.OWNER_ID, f"♻️ I was restarted while working on:\n{str(url)[:200]}\n"
                                  "If it didn't finish, send the link again. If this keeps happening, check /status for memory.")
    except Exception:
        log.warning("couldn't notify the owner about the interrupted job", exc_info=True)


def sweep_orphans() -> None:
    """Leftovers from a crashed run. Only our own names are touched: DOWNLOAD_DIR may be a shared folder."""
    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    for pattern in ("job_*", "cookies_upload_*", "*.cookies"):
        for p in config.DOWNLOAD_DIR.glob(pattern):
            wipe(p)
