"""The job queue (one job runs at a time, which is what keeps memory use flat) and the progress messages."""
import asyncio
import contextlib
import itertools
import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path

from . import config, net, system, uploader, ytdlp
from .utils import JobError, human_size, human_time, trim_memory, wipe

log = logging.getLogger("leechbot")


# ---------- progress messages --------------------------------------------------------

async def safe_edit(msg, text: str, **kw) -> None:
    with contextlib.suppress(Exception):  # not-modified, flood wait, deleted message: never fail a job over an edit
        await msg.edit(text, **kw)


def _bar(pct: float, width: int = 12) -> str:
    filled = int(width * pct / 100)
    return "█" * filled + "░" * (width - filled)


def _transfer_text(label: str, current: int, total: int, elapsed: float) -> str:
    speed = current / elapsed if elapsed >= 1 else 0  # too early for a meaningful speed
    lines = [label]
    if total:
        pct = min(current * 100 / total, 100)
        lines += [f"{_bar(pct)} {pct:.1f}%", f"{human_size(current)} / {human_size(total)}"]
        if speed:
            lines.append(f"{human_size(speed)}/s · ETA {human_time((total - current) / speed)}")
    else:
        lines.append(human_size(current) + (f" · {human_size(speed)}/s" if speed else ""))
    return "\n".join(lines)


class Progress:
    """Edits one Telegram message with throttled progress updates."""

    def __init__(self, msg):
        self.msg = msg
        self.prefix = ""  # e.g. "📃 3/12: title\n" while working through a playlist
        self.upload_label = "⬆️ Uploading"
        self._stage = None
        self._t0 = self._last = 0.0
        self._prev = 0

    def begin_item(self, prefix: str) -> None:
        """Start a new playlist item: new heading, and speed/ETA restart from zero."""
        self.prefix, self.upload_label, self._stage = prefix, "⬆️ Uploading", None

    async def edit(self, text: str) -> None:
        await safe_edit(self.msg, self.prefix + text)

    async def _tick(self, stage: str, current: float, total: float, render) -> None:
        """Send render(elapsed) unless this stage updated less than PROGRESS_INTERVAL ago (the first update of a
        stage and the final one always go out)."""
        now = time.monotonic()
        # A new stage, or the counter dropping back (yt-dlp fetches video and audio as two streams): restart
        # the speed/ETA clock so it doesn't average over the previous stream.
        if stage != self._stage or current < self._prev:
            self._stage, self._t0, self._last = stage, now, 0.0
        self._prev = current
        if now - self._last < config.PROGRESS_INTERVAL and current != total:
            return
        self._last = now
        await self.edit(render(now - self._t0))

    async def _transfer(self, label: str, current: int, total: int) -> None:
        await self._tick(label, current, total, lambda elapsed: _transfer_text(label, current, total, elapsed))

    async def download(self, current: int, total: int) -> None:
        await self._transfer("⬇️ Downloading", current, total)

    async def upload(self, current: int, total: int) -> None:
        await self._transfer(self.upload_label, current, total)

    async def convert(self, done: float, total: float) -> None:
        """Progress of the ffmpeg step that makes a download playable in Telegram (seconds of media done / total)."""
        pct = min(done * 100 / total, 100) if total else 0
        await self._tick("convert", done, total, lambda _: f"🎚 Converting for Telegram\n{_bar(pct)} {pct:.1f}%")


@dataclass
class Job:
    id: int
    kind: str  # "leech" (direct file) | "ytdl"
    url: str
    chat_id: int
    msg: object  # the status message we keep editing
    name: str | None = None
    as_document: bool = False
    audio: bool = False  # ytdl only: best audio instead of video
    playlist: ytdlp.PlaylistInfo | None = None  # ytdl only: download all of these, one at a time


queue: asyncio.Queue[Job] = asyncio.Queue()
active: Job | None = None
_task: asyncio.Task | None = None  # the running job
_worker: asyncio.Task | None = None
_stopping = False
_ids = itertools.count(1)


def is_full() -> bool:
    return queue.qsize() >= config.MAX_QUEUE


def queue_text() -> str:
    ahead = queue.qsize() + (active is not None)
    return f"🕐 Queued (position {ahead + 1})" if ahead else "🚀 Starting…"


def submit(kind: str, url: str, chat_id: int, msg, **options) -> None:
    queue.put_nowait(Job(next(_ids), kind, url, chat_id, msg, **options))


async def cancel(clear_queue: bool) -> tuple[bool, int]:
    """Stop the running job and optionally drop the waiting ones. Returns (stopped a job, dropped count)."""
    dropped = 0
    while clear_queue and not queue.empty():
        await safe_edit(queue.get_nowait().msg, "❌ Cancelled")
        dropped += 1
    running = _task is not None and not _task.done()
    if running:
        _task.cancel()
    return running, dropped


# ---------- doing the work -----------------------------------------------------------

async def _fetch(job: Job, url: str, dest: Path, prog: Progress, scratch: Path) -> tuple[Path, bool]:
    """Download one item into `dest`. Returns (file, the link turned out to be a playlist)."""
    if job.kind != "ytdl":
        return await net.download(url, dest, job.name, prog.download), False
    return await ytdlp.download(url, dest, prog.download, on_status=prog.edit, audio=job.audio,
                                convert=not job.as_document, on_convert=prog.convert, scratch=scratch)


async def _process_playlist(client, job: Job, workdir: Path, prog: Progress) -> str:
    """Download and upload the videos one at a time (one item on disk at once), skipping any that fail."""
    info = job.playlist
    n = len(info.entries)
    sent, failed, stopped = 0, [], ""
    for i, (title, url) in enumerate(info.entries, 1):
        prog.begin_item(f"📃 {i}/{n}: {title[:60]}\n")
        item_dir = workdir / f"{i:03d}"
        item_dir.mkdir(parents=True, exist_ok=True)
        try:
            path, _ = await _fetch(job, url, item_dir, prog, workdir / ".scratch")
            await uploader.send(client, job.chat_id, path, prog, job.as_document)
            sent += 1
        except Exception as e:  # one bad video (download or upload) must not sink the rest
            if not isinstance(e, JobError):
                log.exception("playlist item %s failed", i)
            failed.append((title, str(e) or type(e).__name__))
            if getattr(e, "fatal", False):
                stopped = f"\nStopped after video {i} of {n}, because the next ones would fail the same way."
                break
        finally:
            wipe(item_dir)  # free the disk before the next video
    prog.begin_item("")
    if sent == n and not info.truncated:
        return ""  # everything arrived: nothing to report
    head = info.title[:60]
    icon = "⚠️" if failed else "ℹ️"
    text = f"{icon} Playlist: {sent} of {n} sent ({head})" if sent else f"❌ Playlist failed: nothing was sent ({head})"
    if info.truncated:
        text += f"\nThe playlist has more videos; only the first {n} were taken (MAX_PLAYLIST_ITEMS)."
    if failed:
        text += f"\n\n{len(failed)} failed:\n" + "\n".join(f"- {t[:50]}: {e.splitlines()[0][:100]}" for t, e in failed[:5])
        if len(failed) > 5:
            text += f"\n…and {len(failed) - 5} more"
    return (text + stopped)[:4000]


async def _process(client, job: Job) -> None:
    """Run one job. Everything it creates (downloads, converted files, thumbnails, temp files, yt-dlp's
    cache) lives under one folder, which is deleted however the job ends: done, failed or cancelled."""
    workdir = config.DOWNLOAD_DIR / f"job_{job.id}"
    workdir.mkdir(parents=True, exist_ok=True)
    prog = Progress(job.msg)
    try:
        if job.playlist:
            report = await _process_playlist(client, job, workdir, prog)
        else:
            path, was_playlist = await _fetch(job, job.url, workdir, prog, workdir / ".scratch")
            await uploader.send(client, job.chat_id, path, prog, job.as_document)
            report = "ℹ️ That link is a playlist: only its first video was downloaded." if was_playlist else ""
        if report:
            await prog.edit(report)
        else:  # success needs no message: remove the progress one
            with contextlib.suppress(Exception):
                await job.msg.delete()
    except asyncio.CancelledError:
        await prog.edit("♻️ The bot is restarting. Send the link again." if _stopping else "❌ Cancelled")
    except JobError as e:
        await prog.edit(f"❌ {e}")
    except MemoryError:
        await prog.edit(system.OOM_MESSAGE)
    except Exception as e:
        log.exception("job %s failed", job.id)
        await prog.edit(f"❌ {type(e).__name__}: {str(e)[:300]}")
    finally:
        wipe(workdir)  # always free the disk


async def _run_worker(client) -> None:
    global active, _task
    while True:
        job = await queue.get()
        active = job
        _mark(job)
        _task = asyncio.create_task(_process(client, job))
        try:
            await _task
        except Exception:
            log.exception("worker error")
        finally:
            active = _task = None
            _unmark()
            queue.task_done()
            trim_memory()  # the job's folder is already gone; now hand freed heap back to the OS too


def start(client) -> None:
    global _worker
    _worker = asyncio.create_task(_run_worker(client))


async def stop() -> None:
    """Shutting down: let the running job say 'restarting' and clean its files."""
    global _stopping
    _stopping = True
    if _task is not None:
        _task.cancel()
        await asyncio.wait({_task}, timeout=5)
    if _worker is not None:
        _worker.cancel()


# ---------- crash notice and cleanup -------------------------------------------------

def _mark(job: Job) -> None:
    """Exists while a job runs, so a crash/restart can tell you what was interrupted."""
    with contextlib.suppress(OSError):
        config.STATE_FILE.write_text(json.dumps({"url": job.url}))


def _unmark() -> None:
    with contextlib.suppress(OSError):
        config.STATE_FILE.unlink(missing_ok=True)


async def notify_interrupted(app) -> None:
    """If the last run died mid-job (crash, OOM kill, reboot), say so instead of failing silently."""
    try:
        data = json.loads(config.STATE_FILE.read_text())
    except (OSError, ValueError):
        return
    _unmark()
    text = (
        "♻️ I was restarted while working on:\n"
        f"{str(data.get('url', '?'))[:200]}\n"
        "If it didn't finish, send the link again. If this keeps happening, check /status for memory."
    )
    try:
        await app.send_message(config.OWNER_ID, text)
    except Exception:
        log.warning("couldn't notify the owner about the interrupted job", exc_info=True)


_OWN_FILES = ("job_*", "cookies_upload_*", "*.cookies")  # what this bot creates in DOWNLOAD_DIR


def sweep_orphans() -> None:
    """Leftovers from a crashed run. Only our own names are touched: DOWNLOAD_DIR may be a shared folder."""
    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    for pattern in _OWN_FILES:
        for p in config.DOWNLOAD_DIR.glob(pattern):
            wipe(p)
